#include"cutter/CutterUtils.h"
using namespace std;

bool checkLDKOrthogonal(Contour ldkContour, HoughSupportLine sl) {
        int checkLineTh = 35;
        classifyLines(ldkContour, sl.getClusterValues(), 0);
        vector<Line> ldkLines = ldkContour.getLines();
        vector<Line> filterLines;
        for(int i=0;i<ldkLines.size();i++){
            if(ldkLines[i].getCluster() == -1){
                filterLines.push_back(ldkLines[i]);
            }
        }
        if (filterLines.size() > 0) {
            return false;
        }
        vector<double> ldkLineAngles;
        for(int i=0;i<ldkLines.size();i++){
            if(ldkLines[i].length() > checkLineTh){
                ldkLineAngles.push_back(((int)sl.getClusterValues()[ldkLines[i].getCluster()] + 180) % 90);
            }
        }
        vector<double> filteredAngles;
        for(int i=0;i<ldkLineAngles.size();i++){
            if((ldkLineAngles[i] < 10) || (ldkLineAngles[i] > 80)){
                filteredAngles.push_back(ldkLineAngles[i]);
            }
        }

        if (ldkLineAngles.size() == filteredAngles.size()) {
            return true;
        } else {
            return false;
        }
    }