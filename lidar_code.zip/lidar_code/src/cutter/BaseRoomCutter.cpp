#include"cutter/BaseRoomCutter.h"
using namespace std;
using namespace cv;

vector<Polygon*> build_raw_polygon(vector<cv::Point> cnt, Mat floor_mask) {

        Mat zero_mask = Mat::zeros(floor_mask.rows, floor_mask.cols, CV_8UC1);
        Mat room_mask = zero_mask;
        vector<vector<cv::Point>> cnt_to_list;
        cnt_to_list.push_back(cnt);
        drawContours(room_mask, cnt_to_list, -1,Scalar(255), FILLED);
        Mat new_room_mask = room_mask.mul(floor_mask);
        vector<vector<cv::Point>> rc;
        Mat hierarchy =Mat();
        findContours(new_room_mask, rc, hierarchy, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

        vector<vector<cv::Point>> room_contours;
        if (countNonZero(new_room_mask)==0)
            room_contours = cnt_to_list;
        else {
            vector<vector<cv::Point>> tmp_room_contours;
            for (vector<cv::Point> i : rc) {
                vector<cv::Point2f> i2f =vector<cv::Point2f>();
                for(int j=0;j<i.size();j++){
                    i2f.push_back(Point2f(static_cast<float>(i[j].x),static_cast<float>(i[j].y)));
                }
                vector<cv::Point2f> approxCurve =vector<cv::Point2f>();
                approxPolyDP(i2f, approxCurve, 6, true);
                vector<cv::Point> dst =vector<cv::Point>();
                for(int j=0;j<approxCurve.size();j++){
                    dst.push_back(Point2f(static_cast<double>(approxCurve[j].x),static_cast<double>(approxCurve[j].y)));
                }
                tmp_room_contours.push_back(dst);
            }
            double max_area = 0;
            int max_index = 0;
            for (int i = 0; i < tmp_room_contours.size(); i++) {
                try {
                    Polygon* polygon = points2Poly(tmp_room_contours[i]);
                    double area = polygon->getArea();
                    if (area > max_area) {
                        max_area = area;
                        max_index = i;
                    }
                } catch (Exception e) {
                    continue;
                }
            }
            room_contours.push_back(tmp_room_contours[max_index]);
        }
        vector<Polygon*> list;
        for (vector<cv::Point> i : room_contours) {
            Polygon* poly = points2Poly(i);
            list.push_back(poly);
        }

        return list;
    }

    vector<Polygon*> build_external_lines(vector<Polygon*> polygons) {
        Geometry* dilated_polygon_collection = polygons[0]->buffer(1).release();

        for (Polygon* polygon : polygons) {
            Geometry* dilated_polygon = polygon->buffer(1).release();
            dilated_polygon_collection = dilated_polygon_collection->Union(dilated_polygon).release();
        }
        vector<LineString*> ext_wall_line_list = geometryCollection2Lines(dilated_polygon_collection);
        vector<Polygon*> dilated_list;
        for (int i = 0; i < ext_wall_line_list.size(); i++) {
            LineString* ext_wall_line = ext_wall_line_list[i];
            Polygon* dilated_poly = (Polygon*) ext_wall_line->buffer(1).release();
            dilated_list.insert(dilated_list.begin()+i, dilated_poly);
        }
        return dilated_list;
    }

    std::unique_ptr<LineString> affinity_scale(LineString* line) {
        double infinity = 10000;
        CoordinateSequence* coordinates = line->getCoordinates().release();
        double x0 = (*coordinates)[0].x;
        double x1 = (*coordinates)[1].x;
        double y0 = (*coordinates)[0].y;
        double y1 = (*coordinates)[1].y;
        if (x0 == x1) {
            if (y0 > y1) {
                y0 = infinity;
                y1 = -infinity;
            } else {
                y0 = -infinity;
                y1 = infinity;
            }
        } else {
            if (x0 > x1) {
                x0 = infinity;
                x1 = -infinity;
            } else {
                x0 = -infinity;
                x1 = infinity;
            }
        }
        (*coordinates)[0] =Coordinate(x0, y0);
        (*coordinates)[1] =Coordinate(x1, y1);

        unique_ptr<LineString> newline = createLineStringUnique((*coordinates));
        return newline;
    }

    Polygon* approximate(Polygon* polygon) {
        vector<LineString*> lines = polygon2Lines(polygon);
        vector<mPoint> pointList;
        for (LineString* line : lines) {
            CoordinateSequence* c = line->getCoordinates().release();
            Coordinate sp = (*c)[0];
            Coordinate ep = (*c)[1];
            mPoint start_point_x =mPoint((int) sp.x, (int) sp.y);
            mPoint end_point_x =mPoint((int) ep.x, (int) ep.y);
            pointList.push_back(start_point_x);
            pointList.push_back(end_point_x);
        }
        vector<cv::Point> mat = Contour::getContourFromPoints(pointList);

        vector<cv::Point2f> i2f =vector<cv::Point2f>();
        for(int j=0;j<mat.size();j++){
                    i2f.push_back(Point2f(static_cast<float>(mat[j].x),static_cast<float>(mat[j].y)));
                }
        vector<cv::Point2f> approxCurve =vector<cv::Point2f>();
        approxPolyDP(i2f, approxCurve, 6, true);
        vector<cv::Point> dst =vector<cv::Point>();
                for(int j=0;j<approxCurve.size();j++){
                    dst.push_back(Point2f(static_cast<double>(approxCurve[j].x),static_cast<double>(approxCurve[j].y)));
                }
        polygon = points2Poly(dst);

        return polygon;
    }