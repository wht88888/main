#include"cutter/CornerCutter.h"
using namespace std;
using namespace cv;


    vector<Contour> CornerCutter(vector<Contour> contours, Mat floorMask, HoughSupportLine sl) {
        vector<vector<cv::Point>> contourMats;
        Mat hierarchy =Mat();
        findContours(floorMask, contourMats, hierarchy, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
        sort(contourMats.begin(),contourMats.end(),[](vector<cv::Point> v1,vector<cv::Point> v2){return contourArea(v1)>contourArea(v2);});
        if (contourMats.size() == 0) {
            return contours;
        }
        Polygon* floorPoly = createPolygon(Contour::getPointList(contourMats[0]));
        floorPoly = makeValidRoom(floorPoly).second;

        vector<pair<Polygon*, Contour>> polyAndContours = getRoomPolygons(contours);
        vector<pair<Polygon*, Contour>> ldkPolyAndContour;
        for(int i=0;i<polyAndContours.size();i++){
            if(polyAndContours[i].second.getLabel()=="LDK"){
                ldkPolyAndContour.push_back(polyAndContours[i]);
            }
        }
        if (ldkPolyAndContour.size() == 0) {
            vector<Contour> result;
            for(int i=0;i<polyAndContours.size();i++){
                result.push_back(polyAndContours[i].second);
            }
            return result;
        }
        Contour ldkContour = ldkPolyAndContour[0].second;
        Polygon* ldkPoly = ldkPolyAndContour[0].first;
        ldkPoly = makeValidRoom(ldkPoly).second;
        Polygon* ldkRawPoly = buildRawPolygon(ldkContour, floorMask);

        vector<Polygon*> otherRoomPolys;
        for(int i=0;i<polyAndContours.size();i++){
            if(polyAndContours[i].second.getLabel()!="LDK"){
                otherRoomPolys.push_back(polyAndContours[i].first);
            }
        }
        vector<Contour> otherRoomContours;
        for(int i=0;i<polyAndContours.size();i++){
            if(polyAndContours[i].second.getLabel()!="LDK"){
                otherRoomContours.push_back(polyAndContours[i].second);
            }
        }
        if (!checkLDKOrthogonal(ldkContour, sl)) {
            vector<Contour> result;
            for(int i=0;i<polyAndContours.size();i++){
                result.push_back(polyAndContours[i].second);
            }
            return result;
        }
        Polygon* rotatedLDKPoly = makePolygonCCW(ldkPoly);
        vector<int> targetIdxs = getCornerIdxs(rotatedLDKPoly, ldkRawPoly, otherRoomPolys);
        Polygon* cuttedLDK = cutRectFromCorner(rotatedLDKPoly, ldkRawPoly, targetIdxs, floorMask, sl, floorPoly);
        Contour newLDKContour = buildResolvedContour(cuttedLDK, ldkContour);
        otherRoomContours.insert(otherRoomContours.begin(), newLDKContour);
        return otherRoomContours;
    }

    vector<int> getCornerIdxs(Polygon* ldkFitPoly, Polygon* ldkRawPoly, vector<Polygon*> otherPolys) {
        Geometry* ldkConvexhull = ldkFitPoly->convexHull().release();
        double pointRoomDistTh = 50.0;
        double pointRawDistTh = 55.0;
        CoordinateSequence* roomCoords = ldkFitPoly->getExteriorRing()->getCoordinates().release();
        CoordinateSequence* hullCoords = ldkConvexhull->getCoordinates().release();

        vector<int> cornerIdxs;
        for (int i = 0; i < roomCoords->size() - 1; i++) {
            Coordinate currentCoord = (*roomCoords)[i];
            double minDist = 10000;
            for (int k = 0; k < hullCoords->size(); k++) {
                Coordinate hullCoord = (*hullCoords)[k];
                double dist = sqrt((hullCoord.x - currentCoord.x) * (hullCoord.x - currentCoord.x) + (hullCoord.y - currentCoord.y) * (hullCoord.y - currentCoord.y));
                if (dist < minDist) {
                    minDist = dist;
                }
            }

            if (minDist > 20) {
                continue;
            }
            gPoint* currentPoint = createPoint(currentCoord);
            if (currentPoint->distance(ldkRawPoly) < pointRawDistTh) {
                continue;
            }

            vector<double> point2RoomDists;
            for (int k = 0; k < otherPolys.size(); k++) {
                double dist = currentPoint->distance(otherPolys[k]);
                point2RoomDists.push_back(dist);
            }
            double minPoint=10000;
            for(int i=0;i<point2RoomDists.size();i++){
                if(point2RoomDists[i]<minPoint){
                    minPoint=point2RoomDists[i];
                }
            }
            if (otherPolys.size() == 0 || minPoint > pointRoomDistTh) {
                cornerIdxs.push_back(i);
            }
        }
        return cornerIdxs;
    }

    bool isRectOverlapWithRawLidar(CoordinateSequence* rectCoords, Mat floorMask) {
        double overlapThreshold = 0.00;
        double x1 = (*rectCoords)[0].x, x2 = (*rectCoords)[2].x, y1 = (*rectCoords)[0].y, y2 = (*rectCoords)[2].y;
        int rowStart = (int) min(y1, y2);
        int rowEnd = (int) max(y1, y2) + 1;
        int colStart = (int) min(x1, x2);
        int colEnd = (int) max(x1, x2) + 1;
        int area = (rowEnd - rowStart + 1) * (colEnd - colStart + 1);
        int nonZeroArea = countNonZero(floorMask(Range(rowStart, rowEnd), Range(colStart, colEnd)));

        return ((float)nonZeroArea / area) > overlapThreshold;
    }

    Geometry* getRectFromCorner(gPoint* cornerPoint, Polygon* ldkPoly, Polygon* ldkRawPoly, Mat floorMask, Polygon* floorPoly) {
        double cornerPointCoordX = cornerPoint->getCoordinate()->x;
        double cornerPointCoordY = cornerPoint->getCoordinate()->y;
        double direction[4][2];
        int h = floorMask.rows;
        int w = floorMask.cols;
        direction[0][0] = 5.0;
        direction[0][1] = 5.0;

        direction[1][0] = -5.0;
        direction[1][1] = 5.0;

        direction[2][0] = -5.0;
        direction[2][1] = -5.0;

        direction[3][0] = 5.0;
        direction[3][1] = -5.0;

        double cutRectAreaTh = 8000;
        double rectMinWidthTh = 45;

        for (int i = 0; i < 4; i++) {
            double x_dir = direction[i][0];
            double y_dir = direction[i][1];
            Coordinate tmpCoord =Coordinate(cornerPointCoordX + x_dir, cornerPointCoordY + y_dir);
            gPoint* tmpPoint = createPoint(tmpCoord);
            if (ldkPoly->contains(tmpPoint)) {
                double maxArea = 0;
                Polygon* maxPoly = NULL;
                for (int m = 10; m < 100; m++) {
                    double rectPointX = cornerPointCoordX + m * x_dir;
                    if (rectPointX < 0 || rectPointX >= w) {
                        break;
                    }

                    for (int n = 10; n < 100; n++) {
                        double rectPointY = cornerPointCoordY + n * y_dir;
                        if (rectPointY < 0 || rectPointY >= h) {
                            continue;
                        }

                        CoordinateSequence currentRect(5);
                        currentRect[0] =Coordinate(cornerPointCoordX, cornerPointCoordY);
                        currentRect[1] =Coordinate(rectPointX, cornerPointCoordY);
                        currentRect[2] =Coordinate(rectPointX, rectPointY);
                        currentRect[3] =Coordinate(cornerPointCoordX, rectPointY);
                        currentRect[4] =Coordinate(cornerPointCoordX, cornerPointCoordY);
                        Polygon* rectPoly = createPolygon(currentRect);

                        gPoint* diagonalPoint = createPoint(currentRect[2]);
                        if (!ldkPoly->contains(diagonalPoint) || isRectOverlapWithRawLidar(&currentRect, floorMask)) {
                            break;
                        }
                        if (rectPoly->getArea() > maxArea) {
                            maxArea = rectPoly->getArea();
                            maxPoly = rectPoly;
                        }
                    }
                }

                if (maxArea > cutRectAreaTh) {
                    return maxPoly;
                }

            }
        }
        return createEmptyPolygon();

    }

    Polygon* cutRectFromCorner(Polygon* ldkPoly, Polygon* ldkRawPoly, vector<int> targetCornerIdxs, Mat floorMask, HoughSupportLine sl, Polygon* floorPoly) {
        Geometry* dilatedRawPoly = ldkRawPoly->buffer(10).release();
        Geometry* freeGeometry = ldkPoly->difference(dilatedRawPoly).release();
        CoordinateSequence* ldkCoords = ldkPoly->getExteriorRing()->getCoordinates().release();
        double point2PolyTh = 10;
        vector<gPoint*> targetPoints;
        for(int i=0;i<targetCornerIdxs.size();i++){
            targetPoints.push_back(createPoint((*ldkCoords)[targetCornerIdxs[i]]));
        }
        for (int i = 0; i < targetPoints.size(); i++) {
            gPoint* cornerPoint = targetPoints[i];
            if (cornerPoint->distance(freeGeometry) < point2PolyTh) {
                Geometry* cutRect = getRectFromCorner(cornerPoint, ldkPoly, ldkRawPoly, floorMask, floorPoly);
                if (!cutRect->isEmpty() && cutRect->getArea() > 0) {
                    Geometry* cuttedLdk = ldkPoly->difference(cutRect).release();
                    pair<bool, Polygon*> validInfo = makeValidRoom(cuttedLdk);
                    if (validInfo.first) {
                        ldkPoly = validInfo.second;
                    }
                }
            }
        }
        return ldkPoly;
    }
