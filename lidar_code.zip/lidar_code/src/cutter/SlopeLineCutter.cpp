#include"cutter/SlopeLineCutter.h"
using namespace std;
using namespace cv;

    int lineWeightTh = 85;
    int ldkCutTh = 1500;
    int rectLDKCutTh = 5000;

    vector<Contour> SlopeLineCutter(vector<Contour> contours, Mat floorMask, HoughSupportLine sl, SegmentInfo segmentInfo) {

        vector<pair<Polygon*, Contour>> polyAndContours = getRoomPolygons(contours);
        vector<pair<Polygon*, Contour>> ldkPolyAndContour;
        for(int i=0;i<polyAndContours.size();i++){
            if(polyAndContours[i].second.getLabel()=="LDK"){
                ldkPolyAndContour.push_back(polyAndContours[i]);
            }
        }
        if (ldkPolyAndContour.size() == 0) {
            vector<Contour> result;
            for(int i=0;i<polyAndContours.size();i++){
                result.push_back(polyAndContours[i].second);
            }
            return result;
        }

        Contour ldkContour = ldkPolyAndContour[0].second;
        Polygon* ldkPoly = ldkPolyAndContour[0].first;
        if (!checkLDKOrthogonal(ldkContour, sl)) {
            vector<Contour> result;
            for(int i=0;i<polyAndContours.size();i++){
                result.push_back(polyAndContours[i].second);
            }
            return result;
        }
        Polygon* ldkRawPoly = buildRawPolygon(ldkContour, floorMask);
        double ldkArea = ldkPoly->getArea();
        double ldkRawArea = ldkRawPoly->getArea();


        vector<Contour> otherRoomContours;
        for(int i=0;i<polyAndContours.size();i++){
            if(polyAndContours[i].second.getLabel()!="LDK"){
                otherRoomContours.push_back(polyAndContours[i].second);
            }
        }
        vector<int> selectLineIdxs;
        for (int i = 0; i < sl.getLineAngles().size(); i++) {
            double lineAngle = ((int)sl.getLineAngles()[i] + 180) % 90;
            if (lineAngle > 30 && lineAngle < 60) {
                Line line = sl.getLineCoords()[i];
                int lineWeight = computeLineWeight(floorMask.rows, floorMask.cols, line, ldkRawPoly, 8);
                if (lineWeight > lineWeightTh) {
                    selectLineIdxs.push_back(i);
                }
            }
        }
        vector<Geometry*> cuttedPolys;
        for (int i = 0; i < selectLineIdxs.size(); i++) {
            int selectIdx = selectLineIdxs[i];
            Line selectLine = sl.getLineCoords()[selectIdx];
            LineString* selectLineString = extendLine(floorMask.rows, floorMask.cols, selectLine);
            LineString* adjustLine1 = adjustLine(selectLineString, ldkRawPoly);
            Geometry* ldkRawCut = ldkRawPoly->difference(adjustLine1->buffer(0.01).release()).release();
            Geometry* ldkCut = ldkPoly->difference(adjustLine1->buffer(0.01).release()).release();
            pair<bool, Polygon*> ldkRawValidInfo = makeValidRoom(ldkRawCut);
            pair<bool, Polygon*> ldkValidInfo = makeValidRoom(ldkCut);
            if (ldkRawValidInfo.first && ldkValidInfo.first) {
                Polygon* ldkRawCutPoly = ldkRawValidInfo.second;
                Polygon* ldkCutPoly = ldkValidInfo.second;

                if (ldkArea - ldkCutPoly->getArea() > rectLDKCutTh && ldkRawArea - ldkRawCutPoly->getArea() < ldkCutTh) {
                    Geometry* cuttedGeomety = ldkPoly->difference(ldkCutPoly).release();
                    cuttedPolys.push_back(cuttedGeomety);
                }
            }

        }
        Geometry* cuttedLdk = ldkPoly;
        for (int i = 0; i < cuttedPolys.size(); i++) {
            cuttedLdk = cuttedLdk->difference(cuttedPolys[i]).release();
        }

        //drawPolygon(floorMask.rows, floorMask.cols, cuttedLdk, "cutldk.png");

        Contour newLDKContour = buildResolvedContour(cuttedLdk, ldkContour);
        otherRoomContours.insert(otherRoomContours.begin(), newLDKContour);

        return otherRoomContours;
    }

    LineString* adjustLine(LineString* line, Polygon* ldkPoly) {
        for (int offset = 1; offset < 40; offset += 2) {
            CoordinateSequence* offsetLineCoord = geos::operation::buffer::OffsetCurve::rawOffset(*line, offset).release();
            LineString* offsetLine = createLineString(*offsetLineCoord);
            Geometry* dilatedLine = offsetLine->buffer(1).release();
            if (dilatedLine->intersection(ldkPoly)->getArea() < 0.0001) {
                return offsetLine;
            }

            offsetLineCoord = geos::operation::buffer::OffsetCurve::rawOffset(*line, -offset).release();
            offsetLine = createLineString(*offsetLineCoord);
            dilatedLine = offsetLine->buffer(1).release();
            if (dilatedLine->intersection(ldkPoly)->getArea() < 0.0001) {
                return offsetLine;
            }

        }
        return line;
    }
