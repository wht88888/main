#include"cutter/RoomCutterByWalls.h"
using namespace std;
using namespace cv;

    int inter_part_area_th = 50;
    int small_part_area_th = 300;
    double inter_perimeter_th = 0.05;
    vector<LineString*> global_cut_lines;

    template <typename ClassType,typename ObjectType>
    bool instanceof(ObjectType* obj){
        return dynamic_cast<ClassType*>(obj);
    }

     vector<Contour> RoomCutterBywalls(vector<Contour> contours, Mat floor_mask) {
        global_cut_lines.clear();
        int n = contours.size();
        if (n <= 1) {
            return contours;
        }
        vector<pair<Polygon*, Contour>> polyAndContours = getRoomPolygons(contours);
        vector<pair<Polygon*, Contour>> ldkPolyAndContour;
        for(int i=0;i<polyAndContours.size();i++){
            if(polyAndContours[i].second.getLabel()=="LDK"){
                ldkPolyAndContour.push_back(polyAndContours[i]);
            }
        }
        Contour ldkContour = ldkPolyAndContour[0].second;
        Polygon* ldk_poly = ldkPolyAndContour[0].first;
        ldk_poly = makeValidRoom(ldk_poly).second;
        Polygon* ldkRawPoly = buildRawPolygon(ldkContour, floor_mask);

        vector<Polygon*> allPolys;
        for(int i=0;i<polyAndContours.size();i++){
            allPolys.push_back(polyAndContours[i].first);
        }
        vector<Polygon*> otherRoomPolys;
        for(int i=0;i<polyAndContours.size();i++){
            if(polyAndContours[i].second.getLabel()!="LDK"){
                otherRoomPolys.push_back(polyAndContours[i].first);
            }
        }
        vector<Contour> otherRoomContours;
        for(int i=0;i<polyAndContours.size();i++){
            if(polyAndContours[i].second.getLabel()!="LDK"){
                otherRoomContours.push_back(polyAndContours[i].second);
            }
        }
        get_global_cut_lines(allPolys);
        global_cut_lines = check_line_len_l1(global_cut_lines);
        vector<double> global_cut_line_angles;
        for (LineString* cut_line : global_cut_lines) {
            double line_angle = compute_lines_angle(cut_line);
            global_cut_line_angles.push_back(line_angle);
        }
        vector<double> ldk_wall_angles = get_ldk_wall_angles(ldk_poly);
        global_cut_lines = filter_cut_line(global_cut_lines, global_cut_line_angles, ldk_wall_angles);

        int max_th = 10;
        int loop_cnt = 0;
        double origLDKArea = ldk_poly->getArea();
        Polygon* origLDKPoly = (Polygon*) ldk_poly->clone().release();
        Polygon* finalCutPoly = origLDKPoly;
        while (true) {
            if (loop_cnt > max_th)
                break;
            double orig_area = ldk_poly->getArea();
            vector<Polygon*> polygon_list;
            for(int i=0;i<otherRoomPolys.size();i++){
                polygon_list.push_back(otherRoomPolys[i]);
            }
            polygon_list.push_back(ldk_poly);
            pair<bool, Polygon*> cutInfo = cut_main_room(polygon_list, ldkRawPoly, ldk_poly);
            bool has_change = cutInfo.first;
            Polygon* cutPoly = cutInfo.second;

            if (!has_change) {
                break;
            }
            finalCutPoly = cutPoly;
            ldk_poly = cutPoly;
            loop_cnt += 1;

        }
        int cutTh = 2500;
        if (origLDKArea - finalCutPoly->getArea() > cutTh) {
            Contour newLDKContour = buildResolvedContour(finalCutPoly, ldkContour);
            otherRoomContours.insert(otherRoomContours.begin(), newLDKContour);
            return otherRoomContours;
        } else {
            return contours;
        }

    }

    void get_global_cut_lines(vector<Polygon*> polygons) {
        for (Polygon* poly : polygons) {
            vector<LineString*> cl = geometryCollection2Lines(poly);
            for(int i=0;i<cl.size();i++)
                global_cut_lines.push_back(cl[i]);
        }
    }

    pair<bool, Polygon*> cut_main_room(vector<Polygon*> polygons, Polygon* raw_poly, Polygon* ldk_poly) {
        int cutTH = 350;
        vector<Polygon*> ext_lines = build_external_lines(polygons);
        Polygon* ldk_cut_poly = (Polygon*) ldk_poly->clone().release();
        vector<LineString*> cut_lines = global_cut_lines;
        ldk_cut_poly = cut_by_walls_strategy(ldk_cut_poly, raw_poly, cut_lines, ext_lines);

        if (ldk_poly->getArea() - ldk_cut_poly->getArea() > cutTH) {
            return pair<bool, Polygon*>(true, ldk_cut_poly);
        } else {
            return pair<bool, Polygon*>(false, ldk_poly);
        }

    }

    Polygon* cut_by_walls_strategy(Polygon* poly, Polygon* raw_poly, vector<LineString*> cut_lines, vector<Polygon*> ext_wall_lines) {

        double epsilon = 1e-3;
        vector<unique_ptr<LineString>> new_cut_lines;

        for (int i = 0; i < cut_lines.size(); i++) {
            LineString* cl = cut_lines[i];
            new_cut_lines.push_back(affinity_scale(cl));
        }
        Geometry* totalCutLines = (Geometry*)createMultiLineString(move(new_cut_lines))->buffer(epsilon, 8, 3).release();

        Geometry* parted_poly = poly;
        parted_poly = parted_poly->difference(totalCutLines).release();

        vector<Polygon*> new_parted_poly;
        vector<Geometry*> parts;
        vector<Geometry*> filtered_parts;
        if (instanceof<MultiPolygon>(parted_poly)) {
            vector<Polygon*> geometryCollection2PolygonsResult=geometryCollection2Polygons((GeometryCollection*) parted_poly);
            for(int i=0;i<geometryCollection2PolygonsResult.size();i++){
                new_parted_poly.push_back(geometryCollection2PolygonsResult[i]);
            }
            for (Polygon* pl : new_parted_poly) {
                if (filter_room_part(pl, raw_poly, ext_wall_lines)) {
                    parts.push_back(pl);
                } else {
                    filtered_parts.push_back(pl);
                }
            }
        }
        vector<Geometry*> filter_removed_parts_result = filter_removed_parts(filtered_parts);
        for(int i=0;i<filter_removed_parts_result.size();i++){
            parts.push_back(filter_removed_parts_result[i]);
        }

        Geometry* cutted_poly;
        if (parts.size() != 0) {
            cutted_poly = parts[0]->buffer(4 * epsilon, 8, 3).release();
            for (int i = 0; i < parts.size(); i++) {
                Geometry* pl = parts[i];
                if (pl->getArea() > 0) {
                    Geometry* dialated_poly = pl->buffer(4 * epsilon, 8, 3).release();
                    cutted_poly = cutted_poly->Union(dialated_poly).release();
                }
            }
        } else {
            cutted_poly = poly;
        }

        if (cutted_poly != NULL) {
            pair<bool, Polygon*> validInfo = makeValidRoom(cutted_poly->buffer(-2 * epsilon, 8, 3).release());
            if (validInfo.first) {
                return validInfo.second;
            }
        }
        return poly;

    }

    vector<Geometry*> filter_removed_parts(vector<Geometry*> parts) {

        if (parts.size() == 0)
            return parts;
        double epsilon = 1e-3;

        Geometry* poly = parts[0]->buffer(2 * epsilon, 8, 3).release();

        for (int i = 1; i < parts.size(); i++) {

            Geometry* dialated_poly = parts[i]->buffer(2 * epsilon, 8, 3).release();
            poly = dialated_poly->Union(poly).release();
        }
        vector<Geometry*> groups;
        if ( instanceof<MultiPolygon>(poly) || instanceof<GeometryCollection>(poly)) {
            for (int i = 0; i < poly->getNumGeometries(); i++) {
                groups.push_back((Geometry*)poly->getGeometryN(i));
            }
        } else {
            groups.push_back(poly);
        }


        vector<Geometry*> new_groups;
        for (Geometry* pl : groups) {
            pl = pl->buffer(-2 * epsilon, 8, 3).release();
            if (pl->getArea() < small_part_area_th) {
                new_groups.push_back(pl);
            }

        }

        return new_groups;
    }

    bool filter_room_part(Polygon* part_poly, Polygon* raw_poly, vector<Polygon*> ext_wall_lines) {
        double part_area = 0;
        try {
            part_area = raw_poly->intersection(part_poly)->getArea();
        } catch (Exception e) {
        }

        bool is_acc_to_rules = true;
        if (part_area < inter_part_area_th)
            is_acc_to_rules = false;
        Polygon* dilated_poly = (Polygon*) part_poly->buffer(1, 8, 3).release();
        double max_inter_area = 0.0;
        double max_inter_ratio = 0.0;
        double inter_length = 0.0;

        if (!is_acc_to_rules) {
            for (Polygon* line : ext_wall_lines) {
                double inter_area = line->intersection(dilated_poly)->getArea();
                double inter_ratio = inter_area / line->getArea();

                inter_length += inter_area;
                max_inter_area = max(max_inter_area, inter_area);
                max_inter_ratio = max(max_inter_ratio, inter_ratio);
            }
        }
        double inter_perimeter = inter_length / part_poly->getLength();
        if (inter_perimeter < inter_perimeter_th)
            is_acc_to_rules = true;
        return is_acc_to_rules;
    }

    vector<LineString*> check_line_len_l1(vector<LineString*> lines) {
        vector<LineString*> new_line;
        for (LineString* line : lines) {
            CoordinateSequence* line_coord = line->getCoordinates().release();
            double l1_th = 10;
            Coordinate start_point = (*line_coord)[0];
            Coordinate end_point = (*line_coord)[1];
            double dx = end_point.x - start_point.x;
            double dy = end_point.y - start_point.y;
            if (fabs(dx) + fabs(dy) >= l1_th) {
                new_line.push_back(line);
            }
        }
        return new_line;
    }

    double compute_lines_angle(LineString* line) {
        Coordinate start_point = (*line->getCoordinates())[0];
        Coordinate end_point = (*line->getCoordinates())[1];
        double dx = fabs(end_point.x - start_point.x);
        double dy = fabs(end_point.y - start_point.y);
        double angle = ((int)(atan(dy / dx)*(180/M_PI)) + 180) % 90;
        return angle;
    }

    vector<double> get_ldk_wall_angles(Polygon* poly) {
        vector<LineString*> poly_coords = polygon2Lines(poly);
        vector<double> ldk_wall_angles;
        for (int i = 0; i < poly_coords.size(); i++) {
            double wall_angle = compute_lines_angle(poly_coords[i]);
            ldk_wall_angles.push_back(wall_angle);
        }

        return ldk_wall_angles;
    }

    vector<LineString*> filter_cut_line(vector<LineString*> cut_lines, vector<double> cut_line_angles, vector<double> ldk_wall_angles) {
        vector<LineString*> res_cut_lines;

        for (int i = 0; i < ldk_wall_angles.size(); i++) {
            if (ldk_wall_angles[i] > 15 && ldk_wall_angles[i] < 75) {
                return res_cut_lines;
            }
        }
        for (int i = 0; i < cut_line_angles.size(); i++) {
            double cut_line_angle = cut_line_angles[i];
            for (double ldk_wall_angle : ldk_wall_angles) {
                double angle_diff = (int)(ldk_wall_angle - cut_line_angle + 90) % 90;
                if (angle_diff < 10 || angle_diff > 80) {
                    res_cut_lines.push_back(cut_lines[i]);
                    break;
                }
            }
        }

        return res_cut_lines;
    }
