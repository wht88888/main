#include "geom/Contour.h"
using namespace std;

Contour::Contour(string connection, vector<cv::Point> contour, string label, int groupId, int shapeId)
{
    this->connection = connection;
    this->contourPoints = getPointList(contour);
    this->label = label;
    this->groupId = groupId;
    this->shapeId = shapeId;
    buildLines(this->contourPoints);
}

Contour::Contour()
{
    this->contourPoints = std::vector<mPoint>();
}

string Contour::getLabel()
{
    return label;
}

int Contour::getGroupId()
{
    return groupId;
}

int Contour::getShapeId()
{
    return shapeId;
}

void Contour::setLabel(string label)
{
    this->label = label;
}

void Contour::setConnection(string connection)
{
    this->connection = connection;
}

void Contour::setPointId2LineIdDict(unordered_map<int, vector<int>> pointId2LineIdDict)
{
    this->pointId2LineIdDict = pointId2LineIdDict;
}

void Contour::setGroupId(int groupId)
{
    this->groupId = groupId;
}

void Contour::setShapeId(int shapeId)
{
    this->shapeId = shapeId;
}

Contour Contour::copy()
{
    Contour contour = Contour();
    contour.setConnection(connection);
    contour.setLabel(label);
    contour.setGroupId(groupId);
    contour.setShapeId(shapeId);
    vector<mPoint> copyPoints;
    for (int i = 0; i < contourPoints.size(); i++)
    {
        copyPoints.push_back(mPoint(contourPoints[i].x, contourPoints[i].y));
    }
    contour.setContourPoints(copyPoints);

    vector<Line> copyLines;
    for (int i = 0; i < lines.size(); i++)
    {
        copyLines.push_back(lines[i].copy());
    }
    contour.setLines(copyLines);

    unordered_map<int, vector<int>> copyDict;
    std::copy(pointId2LineIdDict.begin(), pointId2LineIdDict.end(), std::inserter(copyDict, copyDict.end()));

    contour.setPointId2LineIdDict(copyDict);
    return contour;
}

vector<Line> Contour::getLines()
{
    return this->lines;
}

void Contour::setLines(vector<Line> lines)
{
    this->lines = lines;
}

vector<mPoint> Contour::getContourPoints()
{
    return this->contourPoints;
}

void Contour::setContourPoints(vector<mPoint> points)
{
    this->contourPoints = points;
}

vector<mPoint> Contour::getPointList(vector<cv::Point> contour)
{
    vector<cv::Point> contourCVPoints = contour;
    vector<mPoint> contourPoints;
    for (int i = 0; i < contourCVPoints.size(); i++)
    {
        cv::Point pt = contourCVPoints[i];
        contourPoints.push_back(mPoint((int)round(pt.x), (int)round(pt.y)));
    }
    return contourPoints;
}

vector<cv::Point> Contour::getContourFromPoints(vector<mPoint> pointList)
{
    vector<cv::Point> contour;
    for (int i = 0; i < pointList.size(); i++)
    {
        mPoint point = pointList[i];
        contour.push_back(cv::Point(point.x, point.y));
    }
    return contour;
}


void Contour::buildLines(vector<mPoint> contourPoints)
{
    pointId2LineIdDict.clear();
    vector<Line> newLines;
    int n = contourPoints.size();
    for (int i = 0; i < n; i++)
    {
        vector<int> tmp;
        pointId2LineIdDict.insert({i, tmp});
    }
    for (int i = 0; i < n; i++)
    {
        int j = (i + 1) % n;
        mPoint u = contourPoints[i];
        mPoint v = contourPoints[j];
        int lineId = i;
        pointId2LineIdDict[i].push_back(lineId);
        pointId2LineIdDict[j].push_back(lineId);
        Line line = Line(this, lineId, u, v, i, j);
        newLines.push_back(line);
    }
    if (lines.size() == newLines.size())
    {
        for (int i = 0; i < lines.size(); i++)
        {
            newLines[i].setSelected(lines[i].isSelected());
            newLines[i].setChanged(lines[i].isChanged());
        }
    }
    lines = newLines;
}

void Contour::updateIndex()
{
    int n = lines.size();
    pointId2LineIdDict.clear();
    for (int i = 0; i < n; i++)
    {
        vector<int> tmp;
        pointId2LineIdDict.insert({i, tmp});
    }
    vector<mPoint> pointList;
    for (int i = 0; i < n; i++)
    {
        int j = (i + 1) % n;
        pointList.push_back(lines[i].getU());
        lines[i].setId(i);
        lines[i].setUid(i);
        lines[i].setVid(j);
        pointId2LineIdDict[i].push_back(i);
        pointId2LineIdDict[j].push_back(i);
    }
    contourPoints = pointList;
}

void Contour::updateLines()
{
    buildLines(contourPoints);
}

void Contour::updateByFixPoints(Line line)
{
    updateByFixPoint(line.getU(), line.getUid());
    updateByFixPoint(line.getV(), line.getVid());
}

void Contour::updateByFixPoint(mPoint point, int pointId)
{

    vector<int> lineIds = pointId2LineIdDict[pointId];
    for (int i = 0; i < lineIds.size(); i++)
    {
        Line &targetLine = lines[i];
        if (targetLine.getUid() == pointId)
        {
            targetLine.setU(point);
        }
        else if (targetLine.getVid() == pointId)
        {
            targetLine.setV(point);
        }
    }
    contourPoints[pointId] = point;
}

void Contour::updateByFixAngles(Line line)
{
    updateByFixAngle(line.getU(), line.getUid(), line);
    updateByFixAngle(line.getV(), line.getVid(), line);
}

void Contour::updateByFixAngle(mPoint point, int pointId, Line line)
{
    int lineId = line.getId();
    vector<int> lineIds = pointId2LineIdDict[pointId];
    // assert lineIds.size() == 2;
    // assert lineIds.contains(lineId);

    Line kl = line;

    // vector<int> slIds = lineIds.stream().filter(i->i != lineId).collect(Collectors.toList());
    vector<int> slIds;
    copy_if(lineIds.begin(), lineIds.end(), back_inserter(slIds), [lineId](int n)
                 { return n != lineId; });
    // assert slIds.size() == 1;

    Line sl = lines[slIds[0]];
    std::pair<mPoint, bool> intersectInfo = getIntersection(kl, sl);
    if (!intersectInfo.second)
    {
        updateByFixPoint(point, pointId);
        return;
    }
    mPoint intersectPoint = intersectInfo.first;

    double origL = kl.length();
    double endL = 0;
    if (pointId == kl.getUid())
    {
        endL = getNorm(kl.getV().x - intersectPoint.x, kl.getV().y - intersectPoint.y);
    }
    else
    {
        endL = getNorm(kl.getU().x - intersectPoint.x, kl.getU().y - intersectPoint.y);
    }
    if (endL / origL > 1.5 && origL > 200)
    {
        updateByFixPoint(point, pointId);
        return;
    }

    for (int i = 0; i < lineIds.size(); i++)
    {
        Line &targetLine = lines[lineIds[i]];
        if (targetLine.getUid() == pointId)
        {
            targetLine.setU(intersectPoint);
        }
        else if (targetLine.getVid() == pointId)
        {
            targetLine.setV(intersectPoint);
        }
    }
    contourPoints[pointId] = intersectPoint;
}

void Contour::update(Line line)
{
    line.setChanged(false);
    if (connection == FIX_POINT)
    {
        updateByFixPoints(line);
    }
    else
    {
        updateByFixAngles(line);
    }
}

double Contour::angle(Line line)
{
    mPoint u = line.getU();
    mPoint v = line.getV();
    return atan2(v.y - u.y, v.x - u.x) * 180.0 / M_PI;
}

double Contour::norm(double x)
{
    double y = ((int)(x + 360) % 360 - 180);
    return y;
}

void Contour::commit(int clusterNum, string connection, int minAngle, int maxAngle, int quantization)
{
    this->connection = connection;
    // lines = lines.stream().filter(line->line.length() > quantization).collect(Collectors.toList());
    vector<Line> temp_lines;
    copy_if(lines.begin(), lines.end(), back_inserter(temp_lines), [quantization](Line line)
            { return line.length() > quantization; });
    lines.clear();
    std::copy(temp_lines.begin(), temp_lines.end(), back_inserter(lines));
    int n = lines.size();

    unordered_set<int> lineIdSet;
    vector<Line> newLines;
    bool needStop = false;
    int i = 0;
    while (!needStop)
    {
        if (i >= lines.size())
        {
            break;
        }
        double ai = angle(lines[i]);
        int j = (i + 1) % n;
        while (j != i)
        {
            double aj = angle(lines[j]);
            double d = fabs(norm(ai - aj));
            if (j == 0)
            {
                if (lineIdSet.find(lines[i].getId()) != lineIdSet.end())
                {
                    needStop = true;
                    break;
                }
                lines[i].setV(lines[n - 1].getV());
                newLines.push_back(lines[i]);
                lineIdSet.insert(lines[i].getId());
                needStop = true;
                break;
            }
            if (d >= minAngle && d <= maxAngle)
            {
                if (lineIdSet.find(lines[i].getId()) != lineIdSet.end())
                {
                    needStop = true;
                    break;
                }
                if (j != ((i + 1) % n))
                {
                    lines[i].setV(lines[j].getU());
                }
                newLines.push_back(lines[i]);
                lineIdSet.insert(lines[i].getId());
                i = j;
                break;
            }
            j = (j + 1) % n;
        }
        if (i == 0)
        {
            break;
        }
    }
    if (newLines.size() > 1)
    {
        double a0 = angle(newLines[0]);
        double an = angle(newLines[newLines.size() - 1]);
        double d = fabs(norm(a0 - an));
        if (d < 5 || d > 175)
        {
            newLines[0].setU(newLines[newLines.size() - 1].getU());
            newLines.erase(newLines.begin() + newLines.size() - 1);
        }
    }

    lines = newLines;
    updateIndex();

    for (int k = 0; k < clusterNum; k++)
    {
        for (i = 0; i < lines.size(); i++)
        {
            Line line = lines[i];
            if (line.getCluster() == k && line.isChanged())
            {
                update(line);
            }
        }
    }

    for (i = 0; i < lines.size(); i++)
    {
        Line line = lines[i];
        if (i % 2 == 0 && line.isChanged())
        {
            update(line);
        }
    }

    for (i = 0; i < lines.size(); i++)
    {
        Line line = lines[i];
        if (i % 2 != 0 && line.isChanged())
        {
            update(line);
        }
    }
}

geos::geom::Polygon* Contour::getPoly()
{
    vector<mPoint> points;
    for (int i = 0; i < lines.size(); i++)
    {
        mPoint point = lines[i].getU();
        points.push_back(point);
    }
    return createPolygon(points);
}