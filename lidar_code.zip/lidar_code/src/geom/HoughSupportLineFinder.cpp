#include<geom/HoughSupportLineFinder.h>
using namespace std;
using namespace cv;

    HoughSupportLineFinder::HoughSupportLineFinder(int maxPoint2LineDist, int minLineLength, int maxLineGap,float eps,int min_num) {
        this->maxPoint2LineDist = maxPoint2LineDist;
        this->minLineLength = minLineLength;
        this->maxLineGap = maxLineGap;
        this->eps=eps;
        this->min_num=min_num;
    }

    HoughSupportLine HoughSupportLineFinder::run(Mat floormask) {
        vector<vector<cv::Point>> contours;
        Mat hierarchy = Mat();
        findContours(floormask, contours, hierarchy, RETR_TREE, CHAIN_APPROX_NONE);
        Mat mask = Mat(floormask.rows, floormask.cols, CV_8UC1, Scalar(0));
        drawContours(mask, contours, -1, Scalar(255), 1);
        blur(mask, mask, Size(3, 3));
        threshold(mask, mask, 40, 255, THRESH_BINARY);
        vector<Line> lines = getLinesByMask(mask, minLineLength, maxLineGap);
        vector<int> lineWeights;
        vector<int> clusterId;
        vector<double> lineAngles;
        vector<double> clusterValues;
        if (lines.size() == 0) {
            return HoughSupportLine(lines, lineWeights, clusterId, lineAngles, clusterValues);
        }
        lineWeights = computeLineWeight(lines, contours, maxPoint2LineDist);
        lineAngles = computeLineAngle(lines);
        pair<vector<int>, vector<double>> angleClusterResult = cluster(lineAngles, lineWeights,eps,min_num);

        vector<Line> filterLines;
        vector<int> filterLineWeights;
        vector<int> filterClusterId;
        vector<double> filterLineAngles;
        vector<double> filterClusterValues;
        for (int i = 0; i < angleClusterResult.first.size(); i++) {
            if (angleClusterResult.first[i] != UNCLUSTER_LABEL) {
                filterLines.push_back(lines[i]);
                filterLineWeights.push_back(lineWeights[i]);
                filterClusterId.push_back(angleClusterResult.first[i]);
                filterLineAngles.push_back(lineAngles[i]);
            }
        }
        filterClusterValues = angleClusterResult.second;

        for (int i = 0; i < filterLines.size(); i++) {
            Line line = filterLines[i];
            line = transformLine(line, filterClusterValues[filterClusterId[i]] - filterLineAngles[i]);

            filterLines[i] = line;
        }
        vector<int> filterIdxList = filterLinesIdxByWeight(filterLines, filterLineWeights, contours, maxPoint2LineDist, 10);
        lines.clear();
        lineAngles.clear();
        lineWeights.clear();
        clusterId.clear();

        for (int i = 0; i < filterIdxList.size(); i++) {
            int idx = filterIdxList[i];
            lines.push_back(filterLines[idx]);
            lineAngles.push_back(filterLineAngles[idx]);
            lineWeights.push_back(filterLineWeights[idx]);
            clusterId.push_back(filterClusterId[idx]);
        }

        HoughSupportLine hsl = HoughSupportLine(lines, lineWeights, clusterId, lineAngles, angleClusterResult.second);
        return mergeSupportLine(hsl, contours);
//        return hsl;
    }

    vector<Line> HoughSupportLineFinder::getLinesByMask(Mat maskMat, int minLineLength, int maxLineGap) {
        Mat lines = Mat();
        vector<Line> resLines;
        double rad = M_PI/180.0;
        HoughLinesP(maskMat, lines, 1, rad, 50, minLineLength, maxLineGap);
        for (int i = 0; i < lines.rows; i++) {
            Vec4i detectLine = lines.at<Vec4i>(i, 0);
            mPoint pt1 = mPoint((int) detectLine[0], (int) detectLine[1]);
            mPoint pt2 = mPoint((int) detectLine[2], (int) detectLine[3]);
            Line line = Line(NULL, -1, pt1, pt2, -1, -1);
            resLines.push_back(line);
        }
        return resLines;
    }

    vector<double> HoughSupportLineFinder::computeLineAngle(vector<Line> lines) {
        vector<double> angles;
        for (int i = 0; i < lines.size(); i++) {
            int dx = 0;
            int dy = 0;
            mPoint pointU = lines[i].getU();
            mPoint pointV = lines[i].getV();
            dx = pointV.x - pointU.x;
            dy = pointV.y - pointU.y;

            double angleDegree = atan2(dy, dx)*180/M_PI;
            angles.push_back(angleDegree);

        }
        return angles;
    }

    Line HoughSupportLineFinder::transformLine(Line line, double angle) {
        line.rotate(angle);
        return line;
    }

    vector<int> HoughSupportLineFinder::filterLinesIdxByWeight(vector<Line> lines, vector<int> weights, vector<vector<cv::Point>> contours, int maxDist, int thresh) {
        vector<int> filterIdx;
        vector<int> origIdxList;

        vector<mPoint> points;
        for (int i = 0; i < contours.size(); i++) {
            vector<mPoint> vec = Contour::getPointList(contours[i]);
            for(int j=0;j<vec.size();j++){
                points.push_back(vec[j]);
            }
        }

        for (int i = 0; i < lines.size(); i++) {
            origIdxList.push_back(i);
        }
        sort(origIdxList.begin(),origIdxList.end(),[weights](int a,int b){return weights[a]>weights[b];});
        for (int i = 0; i < origIdxList.size(); i++) {
            Line line = lines[origIdxList[i]];
            mPoint s1 = line.getU();
            mPoint s2 = line.getV();
            int weight = 0;
            vector<mPoint> pointSubList;
            for (int k = 0; k < points.size(); k++) {
                mPoint mPoint = points[k];
                double val = fabs(det(s2.subtract(s1), mPoint.subtract(s1)) / getPointDist(s2, s1));
                if (val < maxDist) {
                    weight++;
                } else {
                    pointSubList.push_back(mPoint);
                }
            }
            if (weight > thresh) {
                filterIdx.push_back(origIdxList[i]);
            }
            points = pointSubList;


        }
        return filterIdx;

    }

    pair<Mat, Mat> HoughSupportLineFinder::getDebugImage(HoughSupportLine sl, Mat floorMask) {
        // Mat mask = binary2Show(floorMask);
        Mat mask = floorMask;
        Mat debugMat = Mat();
        cvtColor(mask, debugMat, COLOR_GRAY2BGR);
        Mat debugMat2 = debugMat.clone();
        vector<Scalar> colors;
        colors.push_back(Scalar(255, 0, 0));
        colors.push_back(Scalar(0, 255, 0));
        colors.push_back(Scalar(0, 0, 255));
        colors.push_back(Scalar(0, 255, 255));
        colors.push_back(Scalar(255, 255, 0));
        colors.push_back(Scalar(255, 0, 255));
        colors.push_back(Scalar(100, 255, 200));
        colors.push_back(Scalar(100, 200, 255));
        colors.push_back(Scalar(255, 100, 200));
        for (int i = 0; i < sl.getLineCoords().size(); i++) {
            Line line = sl.getLineCoords()[i];
            mPoint pt1 = line.getU();
            mPoint pt2 = line.getV();
            cv::line(debugMat, Point(pt1.x, pt1.y), Point(pt2.x, pt2.y), colors[sl.getClusterId()[i]], 3);
            double vx = pt1.x - pt2.x;
            double vy = pt1.y - pt2.y;
            double x0 = (pt1.x + pt2.x) / 2.0;
            double y0 = (pt1.y + pt2.y) / 2.0;
            line = vector2PointLine(vx, vy, x0, y0, mask.cols, mask.rows);
            pt1 = line.getU();
            pt2 = line.getV();
            cv::line(debugMat2, Point(pt1.x, pt1.y), Point(pt2.x, pt2.y), colors[sl.getClusterId()[i]], 3);

        }
        return pair<Mat, Mat>(debugMat, debugMat2);

    }