#include "geom/Line.h"
int Line::getCluster()
{
    return cluster;
}

void Line::setId(int id)
{
    this->id = id;
}

int Line::getId()
{
    return this->id;
}

void Line::setCluster(int cluster)
{
    this->cluster = cluster;
}

bool Line::isChanged()
{
    return changed;
}

void Line::setChanged(bool changed)
{
    this->changed = changed;
}

bool Line::isSelected()
{
    return selected;
}

void Line::setSelected(bool selected)
{
    this->selected = selected;
}

bool Line::isHasDoor()
{
    return hasDoor;
}

void Line::setHasDoor(bool hasDoor)
{
    this->hasDoor = hasDoor;
}

Line::Line(Contour *contour, int id, mPoint u, mPoint v, int uId, int vId)
{
    this->contour = contour;
    this->id = id;
    this->pointU = u;
    this->pointV = v;
    this->pointUId = uId;
    this->pointVId = vId;

    this->changed = false;
    this->selected = false;
    this->cluster = -1;
}

Line::Line(){
    this->contour = NULL;
    this->id = -1;
    this->pointU = mPoint(0,0);
    this->pointV = mPoint(0,0);
    this->pointUId = -1;
    this->pointVId = -1;

    this->changed = false;
    this->selected = false;
    this->cluster = -1;
}

void Line::move(int dx, int dy)
{
    pointU.move(dx, dy);
    pointV.move(dx, dy);
    changed = true;
}

void Line::rotate(double angle)
{
    mPoint pt = center();
    double angleRadian = angle * M_PI / 180.0;
    double angleCos = cos(angleRadian);
    double angleSin = sin(angleRadian);
    int x0 = pt.x;
    int y0 = pt.y;
    int x1 = pointU.x;
    int y1 = pointU.y;
    int x2 = pointV.x;
    int y2 = pointV.y;
    double newX1 = (x1 - x0) * angleCos - (y1 - y0) * angleSin + x0;
    double newY1 = (x1 - x0) * angleSin + (y1 - y0) * angleCos + y0;

    double newX2 = (x2 - x0) * angleCos - (y2 - y0) * angleSin + x0;
    double newY2 = (x2 - x0) * angleSin + (y2 - y0) * angleCos + y0;
    pointU.x = (int)round(newX1);
    pointU.y = (int)round(newY1);

    pointV.x = (int)round(newX2);
    pointV.y = (int)round(newY2);

    changed = true;
}

mPoint Line::center()
{
    return mPoint((pointU.x + pointV.x) / 2, (pointU.y + pointV.y) / 2);
}

double Line::angle()
{
    int dx = 0;
    int dy = 0;
    if (getNorm(pointU.x, pointU.y) > getNorm(pointV.x, pointV.y))
    {
        dx = pointU.x - pointV.x;
        dy = pointU.y - pointV.y;
    }
    else
    {
        dx = pointV.x - pointU.x;
        dy = pointV.y - pointU.y;
    }
    double angleDegree = atan2(dy, dx) * 180.0 / M_PI;
    if (angleDegree < 0)
    {
        angleDegree += 180;
    }
    return angleDegree;
}

mPoint Line::getU()
{
    return pointU;
}

void Line::setU(mPoint point)
{
    pointU = point;
    changed = true;
}

mPoint Line::getV()
{
    return pointV;
}

void Line::setV(mPoint point)
{
    pointV = point;
    changed = true;
}

int Line::getUid()
{
    return pointUId;
}

void Line::setUid(int pointId)
{
    pointUId = pointId;
}

int Line::getVid()
{
    return pointVId;
}

void Line::setVid(int pointId)
{
    pointVId = pointId;
}

double Line::length()
{
    return getNorm(pointU.x - pointV.x, pointU.y - pointV.y);
}

Line Line::copy()
{
    Line line = Line(contour, id, mPoint(pointU.x, pointU.y), mPoint(pointV.x, pointV.y), pointUId, pointVId);
    line.setChanged(changed);
    line.setCluster(cluster);
    line.setSelected(selected);
    line.setHasDoor(hasDoor);
    return line;
}

std::string Line::toString(){
    return this->pointU.toString()+' '+this->pointV.toString();
}
