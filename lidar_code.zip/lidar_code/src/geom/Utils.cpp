#include "geom/Utils.h"
using namespace std;
typedef geos::geom::Geometry Geometry;
typedef geos::geom::Polygon Polygon;
typedef geos::geom::Coordinate Coordinate;
typedef geos::geom::CoordinateSequence CoordinateSequence;

double getNorm(int x, int y)
{
    return sqrt(x * x + y * y);
}

double getNorm(double x, double y)
{
    return sqrt(x * x + y * y);
}

double getNorm(mPoint point)
{
    return getNorm(point.x, point.y);
}

double det(double x1, double y1, double x2, double y2)
{
    return x1 * y2 - y1 * x2;
}

double det(mPoint p1, mPoint p2)
{
    return det(p1.x, p1.y, p2.x, p2.y);
}

double getPointDist(mPoint p1, mPoint p2)
{
    return getNorm(p2.x - p1.x, p2.y - p1.y);
}

double getPointDist(pair<double, double> p1, pair<double, double> p2)
{
    return getNorm(p2.first - p1.first, p2.second - p1.second);
}

double pointDot(mPoint p1, mPoint p2)
{
    return p1.x * p2.x + p1.y * p2.y;
}

double pointDot(pair<double, double> p1, pair<double, double> p2)
{
    return p1.first * p2.first + p1.second * p2.second;
}

pair<double, double> normPoint(pair<double, double> pt)
{
    double len = getNorm(pt.first, pt.second);
    return pair<double, double>(pt.first / len, pt.second / len);
}

bool samePoint(mPoint p1, mPoint p2)
{
    if (p1.x == p2.x && p1.y == p2.y)
        return true;
    return false;
}

double lineIntersectionAngle(Line line1, Line line2)
{
    // if 2 lines have same point, return the angle between this 2 lines
    mPoint A, B, C;
    if (samePoint(line1.getU(), line2.getU()))
    {
        A = line1.getU();
        B = line1.getV();
        C = line2.getV();
    }
    else if (samePoint(line1.getU(), line2.getV()))
    {
        A = line1.getU();
        B = line1.getV();
        C = line2.getU();
    }
    else if (samePoint(line1.getV(), line2.getU()))
    {
        A = line1.getV();
        B = line1.getU();
        C = line2.getV();
    }
    else if (samePoint(line1.getV(), line2.getV()))
    {
        A = line1.getV();
        B = line1.getU();
        C = line2.getU();
    }
    else
        return 0;
    int x1 = A.x;
    int y1 = A.y;
    int x2 = B.x;
    int y2 = B.y;
    int x3 = C.x;
    int y3 = C.y;
    double cosA = ((x2 - x1) * (x3 - x1) + (y2 - y1) * (y3 - y1)) / (getPointDist(A, B) * getPointDist(A, C));
    double diff = acos(cosA) * 180.0 / M_PI;
    return diff;
}

pair<mPoint, bool> getIntersection(Line line1, Line line2)
{
    int x1 = line1.getU().x;
    int y1 = line1.getU().y;
    int x2 = line1.getV().x;
    int y2 = line1.getV().y;

    int x3 = line2.getU().x;
    int y3 = line2.getU().y;

    int x4 = line2.getV().x;
    int y4 = line2.getV().y;

    double xdiff1 = x1 - x2;
    double xdiff2 = x3 - x4;
    double ydiff1 = y1 - y2;
    double ydiff2 = y3 - y4;
    double div = det(xdiff1, xdiff2, ydiff1, ydiff2);
    if (fabs(div) < 0.0000001)
    {
        return pair<mPoint, bool>(mPoint(0, 0), false);
    }
    double d1 = det(x1, y1, x2, y2);
    double d2 = det(x3, y3, x4, y4);

    double x = det(d1, d2, xdiff1, xdiff2) / div;
    double y = det(d1, d2, ydiff1, ydiff2) / div;

    return pair<mPoint, bool>(mPoint((int)round(x), (int)round(y)), true);
}

mPoint projPointOnLine(int px, int py, int p1x, int p1y, int p2x, int p2y)
{
    double eps = 0.000001;
    int apx = px - p1x;
    int apy = py - p1y;

    int abx = p2x - p1x;
    int aby = p2y - p1y;

    double abapDot = apx * abx + apy * aby;
    double ababDot = abx * abx + aby * aby;

    double ppx = p1x + abapDot / (ababDot + eps) * abx;
    double ppy = p1y + abapDot / (ababDot + eps) * aby;

    return mPoint((int)round(ppx), (int)round(ppy));
}

mPoint projPointOnLine(mPoint point, mPoint p1, mPoint p2)
{
    return projPointOnLine(point.x, point.y, p1.x, p1.y, p2.x, p2.y);
}

mPoint projPointOnLine(mPoint point, Line line)
{
    return projPointOnLine(point, line.getU(), line.getV());
}

bool isPointProjectOnInnerSegment(mPoint point, Line line, int boundaryTh)
{
    return isPointProjectOnInnerSegment(point, line.getU(), line.getV(), boundaryTh);
}

double point2LineDistance(mPoint point, Line line)
{
    mPoint projPoint = projPointOnLine(point, line);
    return getNorm(point.subtract(projPoint));
}

bool isPointProjectOnInnerSegment(mPoint point, mPoint p1, mPoint p2, int boundaryTh)
{
    mPoint projectPoint = projPointOnLine(point, p1, p2);
    mPoint tmp1 = p1.subtract(projectPoint);
    mPoint tmp2 = p2.subtract(projectPoint);
    if (pointDot(tmp1, tmp2) >= 0)
    {
        return false;
    }

    double cu = getNorm(tmp1.x, tmp1.y);
    double cv = getNorm(tmp2.x, tmp2.y);
    double uv = getNorm(tmp1.x - tmp2.x, tmp1.y - tmp2.y);
    if (uv < 0.00001)
    {
        return false;
    }
    if (cu > boundaryTh && cv > boundaryTh)
    {
        return true;
    }
    return false;
}

bool isLineBoundaryIntersect(Line line1, Line line2, int boundaryTh)
{
    mPoint line1U = line1.getU();
    mPoint line1V = line1.getV();
    mPoint projU = projPointOnLine(line1U, line2);
    mPoint projV = projPointOnLine(line1V, line2);

    mPoint tmp1 = line2.getV().subtract(line2.getU());
    mPoint tmp2 = projV.subtract(projU);

    if ((getNorm(projU.subtract(line2.getU())) < boundaryTh || getNorm(projV.subtract(line2.getV())) < boundaryTh) && pointDot(tmp1, tmp2) < 0)
    {
        return true;
    }

    if ((getNorm(projU.subtract(line2.getV())) < boundaryTh || getNorm(projV.subtract(line2.getU())) < boundaryTh) && pointDot(tmp1, tmp2) > 0)
    {
        return true;
    }
    return false;
}

Line shrinkLine(Line line, double shrinkPercent)
{
    mPoint point1 = line.getU();
    mPoint point2 = line.getV();
    mPoint direction1 = point2.subtract(point1);
    mPoint direction2 = point1.subtract(point2);
    mPoint newPoint2 = mPoint(point1.x + (int)(shrinkPercent * direction1.x), point1.y + (int)(shrinkPercent * direction1.y));
    mPoint newPoint1 = mPoint(point2.x + (int)(shrinkPercent * direction2.x), point2.y + (int)(shrinkPercent * direction2.y));
    return Line(NULL, -1, newPoint1, newPoint2, -1, -1);
}

Line getPerpendicularLine(double x0, double y0, double vx, double vy, int distance)
{
    int dx = distance;
    int dy = distance;
    double xa1 = 0;
    double xa2 = 0;
    double ya1 = 0;
    double ya2 = 0;
    if (fabs(vx) < fabs(vy))
    {
        xa1 = x0 - dx;
        xa2 = x0 + dx;
        ya1 = -vx / vy * (xa1 - x0) + y0;
        ya2 = -vx / vy * (xa2 - x0) + y0;
    }
    else
    {
        ya1 = y0 - dy;
        ya2 = y0 + dy;
        xa1 = -vy / vx * (ya1 - y0) + x0;
        xa2 = -vy / vx * (ya2 - y0) + x0;
    }
    return Line(NULL, -1, mPoint((int)round(xa1), (int)round(ya1)), mPoint((int)round(xa2), (int)round(ya2)), -1, -1);
}

Line vector2PointLine(double vx, double vy, double x, double y, int ww, int hh)
{
    // use line slope, line center and increment of x and y to build line segment
    int xb1 = 0;
    int yb1 = 0;
    int xb2 = 0;
    int yb2 = 0;

    if (fabs(vx) > fabs(vy))
    {
        xb1 = (int)round(x - ww / 2);
        yb1 = (int)round((xb1 - x) * vy / vx + y);
        xb2 = (int)round(x + ww / 2 + 1);
        yb2 = (int)round((xb2 + 1 - x) * vy / vx + y);
    }
    else
    {
        yb1 = (int)round(y - hh / 2);
        xb1 = (int)round((yb1 - y) * vx / vy + x);
        yb2 = (int)round(y + hh / 2 + 1);
        xb2 = (int)round((yb2 + 1 - y) * vx / vy + x);
    }
    return Line(NULL, -1, mPoint(xb1, yb1), mPoint(xb2, yb2), -1, -1);
}

double getBboxDiagonal(vector<Line> lines)
{
    vector<int> coordX;
    vector<int> coordY;
    for (int i = 0; i < lines.size(); i++)
    {
        mPoint pointU = lines[i].getU();
        mPoint pointV = lines[i].getV();
        coordX.push_back(pointU.x);
        coordX.push_back(pointV.x);
        coordY.push_back(pointU.y);
        coordY.push_back(pointV.y);
    }
    auto imaxX = max_element(coordX.begin(), coordX.end());
    int maxX = *imaxX;
    auto iminX = min_element(coordX.begin(), coordX.end());
    int minX = *iminX;
    auto imaxY = max_element(coordY.begin(), coordY.end());
    int maxY = *imaxY;
    auto iminY = min_element(coordY.begin(), coordY.end());
    int minY = *iminY;
    return sqrt((maxX - minX) * (maxX - minX) + (maxY - minY) * (maxY - minY));
}

vector<mPoint> getBoundingRect(vector<mPoint> points)
{
    vector<int> coordX;
    vector<int> coordY;
    for (int i = 0; i < points.size(); i++)
    {
        mPoint point = points[i];
        coordX.push_back(point.x);
        coordY.push_back(point.y);
    }
    auto imaxX = max_element(coordX.begin(), coordX.end());
    int x2 = *imaxX;
    auto iminX = min_element(coordX.begin(), coordX.end());
    int x1 = *iminX;
    auto imaxY = max_element(coordY.begin(), coordY.end());
    int y2 = *imaxY;
    auto iminY = min_element(coordY.begin(), coordY.end());
    int y1 = *iminY;
    if (x1 > 1)
    {
        x1 -= 2;
    }
    if (y1 > 0)
    {
        y1 -= 2;
    }
    x2 += 2;
    y2 += 2;
    vector<mPoint> bbox;
    bbox.push_back(mPoint(x1, y1));
    bbox.push_back(mPoint(x2, y1));
    bbox.push_back(mPoint(x2, y2));
    bbox.push_back(mPoint(x1, y2));
    return bbox;
}

mPoint getWeightedPoint(vector<mPoint> points, vector<int> weights)
{
    double medianX = 0;
    double medianY = 0;
    int weightSum = 0;
    for (int i = 0; i < points.size(); i++)
    {
        weightSum += weights[i];
        medianX += weights[i] * points[i].x;
        medianY += weights[i] * points[i].y;
    }
    return mPoint((int)round(medianX / weightSum), (int)round(medianY / weightSum));
}

vector<int> computeLineWeight(vector<Line> lines, vector<vector<cv::Point>> contours, double distTh)
{
    vector<int> weights;
    vector<mPoint> points;
    for (int i = 0; i < contours.size(); i++)
    {
        vector<mPoint> tmp = Contour::getPointList(contours[i]);
        for(int j=0;j<tmp.size();j++){
            points.push_back(tmp[j]);
        }
    }
    for (int i = 0; i < lines.size(); i++)
    {
        mPoint s1 = lines[i].getU();
        mPoint s2 = lines[i].getV();
        int weight = 0;
        for (int k = 0; k < points.size(); k++)
        {
            mPoint point = points[k];
            double val = fabs(det(s2.subtract(s1), point.subtract(s1)) / getPointDist(s2, s1));
            if (val < distTh)
            {
                weight++;
            }
        }
        weights.push_back(weight);
    }
    return weights;
}

int computeLineWeight(Line line, vector<cv::Point> contour, double distTh)
{

    vector<mPoint> points = Contour::getPointList(contour);
    mPoint s1 = line.getU();
    mPoint s2 = line.getV();
    int weight = 0;
    for (int k = 0; k < points.size(); k++)
    {
        mPoint point = points[k];
        double val = fabs(det(s2.subtract(s1), point.subtract(s1)) / getPointDist(s2, s1));
        if (val < distTh)
        {
            weight++;
        }
    }
    return weight;
}
int computeLineWeight_box(Line line, vector<cv::Point> contour, double distTh)
{
    // calculate the number of point in contour, which is close to line
    vector<mPoint> points = Contour::getPointList(contour);
    mPoint s1 = line.getU();
    mPoint s2 = line.getV();
    int weight = 0;
    for (int k = 0; k < points.size(); k++)
    {
        mPoint point = points[k];
        double val = fabs(det(s2.subtract(s1), point.subtract(s1)) / getPointDist(s2, s1));
        if (val < distTh)
        {
            if (pointDot(s2.subtract(s1), point.subtract(s1)) * pointDot(s2.subtract(s1), point.subtract(s2)) < 0)
            {
                weight++;
            }
        }
    }
    return weight;
}

int computeLineWeight(int h, int w, Line line, Polygon* poly, double distTh) {
        vector<mPoint> points;
        CoordinateSequence* polyCoords = poly->getExteriorRing()->getCoordinates().release();
        for (int i = 0; i < poly->getExteriorRing()->getNumPoints() - 1; i++) {
            points.push_back(mPoint((int) polyCoords->getX(i), (int) polyCoords->getY(i)));
        }
        cv::Mat testMat = cv::Mat(h, w, CV_8UC1, cv::Scalar(0));
        vector<vector<cv::Point>> testContourMats;
        testContourMats.push_back(Contour::getContourFromPoints(points));
        cv::drawContours(testMat, testContourMats, -1, cv::Scalar(1), cv::FILLED);
        cv::Mat hierarchy;
        testContourMats.clear();
        cv::findContours(testMat, testContourMats, hierarchy, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_NONE);
        return computeLineWeight(line, testContourMats[0], distTh);
    }

mPoint computeCenterOfContour(vector<cv::Point> contour)
{
    cv::Moments mo = cv::moments(contour);
    if (fabs(mo.m00) > 0.000001)
    {
        return mPoint((int)(mo.m10 / mo.m00), (int)(mo.m01 / mo.m00));
    }
    vector<mPoint> points = Contour::getPointList(contour);
    double centerX = 0;
    double centerY = 0;

    for (int i = 0; i < points.size(); i++)
    {
        centerX += points[i].x;
        centerY += points[i].y;
    }
    centerX = centerX / points.size();
    centerY = centerY / points.size();
    return mPoint((int)centerX, (int)centerY);
}

mPoint rotatePoint(mPoint point, mPoint center, double angle)
{

    double angleRadian = angle * M_PI / 180.0;
    double angleCos = cos(angleRadian);
    double angleSin = sin(angleRadian);
    int x0 = center.x;
    int y0 = center.y;
    int x1 = point.x;
    int y1 = point.y;

    double newX1 = (x1 - x0) * angleCos - (y1 - y0) * angleSin + x0;
    double newY1 = (x1 - x0) * angleSin + (y1 - y0) * angleCos + y0;

    mPoint rotatePoint = mPoint(0, 0);
    rotatePoint.x = (int)round(newX1);
    rotatePoint.y = (int)round(newY1);
    return rotatePoint;
}

vector<mPoint> mergeContourPoints(vector<mPoint> points, double minDistance)
{
    vector<mPoint> newPoints;
    for (int i = 0; i < points.size(); i++)
    {
        mPoint pi = points[i];
        mPoint pj = points[(i + 1) % points.size()];
        if (getPointDist(pi, pj) < minDistance)
        {
            points[(i + 1) % points.size()] = mPoint((int)round((pi.x + pj.x) / 2.0), (int)round((pi.y + pj.y) / 2.0));
        }
        else
        {
            newPoints.push_back(pi);
        }
    }
    return newPoints;
}

void classifyLines(Contour &contour, vector<double> clusterAngles, double angelTh)
{
    vector<Line> lines = contour.getLines();
    for (int i = 0; i < lines.size(); i++)
    {
        Line &line = lines[i];
        vector<double> angleDiffs = angleDistance(clusterAngles, line.angle());
        double minDiff = 1000000;
        int minIdx = -1;
        for (int k = 0; k < angleDiffs.size(); k++)
        {
            if (angleDiffs[k] < minDiff)
            {
                minDiff = angleDiffs[k];
                minIdx = k;
            }
        }
        if (minIdx != -1 && minDiff < 15)
        {
            line.setCluster(minIdx);
        }
        else
        {
            line.setCluster(-1);
        }
    }
    contour.setLines(lines);
}

vector<double> angleDistance(vector<double> angle1s, double angle2)
{
    vector<double> diffs;
    for (int i = 0; i < angle1s.size(); i++)
    {
        double angle1 = angle1s[i];
        angle1 = (int)(angle1 + 180) % 360 - 180;
        angle2 = (int)(angle2 + 180) % 360 - 180;
        double angleDiff = angle1 - angle2;
        angleDiff = fabs((int)(angleDiff + 360) % 360 - 180);
        diffs.push_back(min(180 - angleDiff, angleDiff));
    }

    return diffs;
}

vector<Contour> buildResolvedContours(vector<Geometry*> geometries, vector<Contour> contours)
{
    vector<Contour> resContours;

    for (int i = 0; i < geometries.size(); i++)
    {
        if (geometries[i]->isEmpty())
        {
            continue;
        }
        pair<bool, Polygon*> validInfo = makeValidRoom(geometries[i]);
        if (validInfo.first)
        {
            Polygon* poly = validInfo.second;
            vector<mPoint> points;
            CoordinateSequence* polyCoords = poly->getExteriorRing()->getCoordinates().release();
            for (int i = 0; i < poly->getExteriorRing()->getNumPoints() - 1; i++) {
                points.push_back(mPoint((int) polyCoords->getX(i), (int) polyCoords->getY(i)));
            }
            vector<mPoint> mergePoints = mergeContourPoints(points, 1);
            Contour contour = Contour(contours[i].FIX_POINT, Contour::getContourFromPoints(mergePoints), contours[i].getLabel(), contours[i].getGroupId(), contours[i].getShapeId());
            resContours.push_back(contour);
        }
    }
    return resContours;
}

Contour buildResolvedContour(Geometry *geometry, Contour contour)
{
    vector<mPoint> tmp;
    Contour resContour = Contour(contour.FIX_POINT, Contour::getContourFromPoints(tmp), contour.getLabel(), contour.getGroupId(), contour.getShapeId());
    pair<bool, Polygon*> validInfo = makeValidRoom(geometry);
    if (validInfo.first)
    {
        Polygon* poly = validInfo.second;
        poly=(Polygon*)geos::simplify::TopologyPreservingSimplifier::simplify(poly, 0.3).release();
        vector<mPoint> points;
        CoordinateSequence* polyCoords = poly->getExteriorRing()->getCoordinates().release();
        for (int i = 0; i < poly->getExteriorRing()->getNumPoints() - 1; i++) {
            points.push_back(mPoint((int) polyCoords->getX(i), (int) polyCoords->getY(i)));
        }
        vector<mPoint> mergePoints = mergeContourPoints(points, 5);
        resContour = Contour(contour.FIX_POINT, Contour::getContourFromPoints(mergePoints), contour.getLabel(), contour.getGroupId(), contour.getShapeId());
    }
    return resContour;
}