#include"geom/LineMerger.h"
using namespace std;
using namespace cv;

vector<ClusterItem> buildClusterLines(vector<Line> lines, double angle) {
        angle = angle*M_PI/180.0;
        vector<ClusterItem> clusterItems;
        double centerX = 0;
        double centerY = 0;
        for (int i = 0; i < lines.size(); i++) {
            mPoint lineCenter = lines[i].center();
            centerX += lineCenter.x;
            centerY += lineCenter.y;

        }
        centerX = centerX / lines.size();
        centerY = centerY / lines.size();
        Line s = getPerpendicularLine(centerX, centerY, cos(angle), sin(angle), 10);
        for (int i = 0; i < lines.size(); i++) {
            pair<mPoint, bool> intersectInfo = getIntersection(s, lines[i]);
            if (intersectInfo.second) {
                vector<double> clusterData(2);
                clusterData[0] = intersectInfo.first.x;
                clusterData[1] = intersectInfo.first.y;
                ClusterItem item = ClusterItem(clusterData, i);
                clusterItems.push_back(item);
            } else {
                centerX += 0.001;
            }
        }
        return clusterItems;


    }

    pair<vector<vector<ClusterItem>>, unordered_set<int>> clusterCloseLines(vector<Line> lines, double angle, double eps) {
        DBScan<ClusterItem> model(eps,1);
        vector<ClusterItem> points = buildClusterLines(lines, angle);
        vector<vector<ClusterItem>> clusters = model.GetClusters(points,false); 
        unordered_set<int> unlabelLineIdxSet;
        for (int i = 0; i < lines.size(); i++) {
            unlabelLineIdxSet.insert(i);
        }
        for (int i = 0; i < clusters.size(); i++) {
            vector<ClusterItem> clusterItems = clusters[i];
            for (int k = 0; k < clusterItems.size(); k++) {
                int labelIdx = clusterItems[k].getIdx();
                unlabelLineIdxSet.erase(labelIdx);
            }
        }
    
        return pair<vector<vector<ClusterItem>>, unordered_set<int>>(clusters, unlabelLineIdxSet);
        }


    Line getMedianLine(vector<Line> lines, double angle, vector<int> lineWeights) {
        angle = angle*M_PI/180.0;
        double size = getBboxDiagonal(lines);
        double centerX = 0;
        double centerY = 0;
        for (int i = 0; i < lines.size(); i++) {
            mPoint lineCenter = lines[i].center();
            centerX += lineCenter.x;
            centerY += lineCenter.y;

        }
        centerX = centerX / lines.size();
        centerY = centerY / lines.size();
        Line s = getPerpendicularLine(centerX, centerY, cos(angle), sin(angle), 10);
        vector<mPoint> intersectPoints;
        for (int i = 0; i < lines.size(); i++) {
            pair<mPoint, bool> intersectInfo = getIntersection(s, lines[i]);
            if (intersectInfo.second) {
                mPoint interPoint = intersectInfo.first;
                intersectPoints.push_back(interPoint);
            }
        }
        mPoint centerPoint = getWeightedPoint(intersectPoints, lineWeights);
        return vector2PointLine(cos(angle), sin(angle), centerPoint.x, centerPoint.y, (int) size, (int) size);
    }


    void mergeCluster(HoughSupportLine sl, int clusterId, vector<vector<cv::Point>> contours, vector<Line>& resLines, vector<double>& resAngles, vector<int>& resWeights, vector<int>& resClusterIds) {

        vector<Line> oldLines;
        vector<double> oldAngles;
        vector<int> oldWeights;
        for (int i = 0; i < sl.getLineCoords().size(); i++) {
            if (sl.getClusterId()[i] == clusterId) {
                oldLines.push_back(sl.getLineCoords()[i]);
                oldAngles.push_back(sl.getLineAngles()[i]);
                oldWeights.push_back(sl.getLineWeights()[i]);
            }
        }
        double medianAngle = sl.getClusterValues()[clusterId];

        if(oldLines.size()==0){
            return;
        }
        pair<vector<vector<ClusterItem>>, unordered_set<int>> clusterInfo = clusterCloseLines(oldLines, medianAngle, 10);
        vector<vector<ClusterItem>> clusterList = clusterInfo.first;
        unordered_set<int> unClusterSet = clusterInfo.second;
        if(unClusterSet.size()!=0){
        for(const int& unclusterLineId: unClusterSet) {
            resLines.push_back(oldLines[unclusterLineId]);
            resAngles.push_back(oldAngles[unclusterLineId]);
            resWeights.push_back(oldWeights[unclusterLineId]);
            resClusterIds.push_back(clusterId);
        }
        }
        for (int i = 0; i < clusterList.size(); i++) {
            vector<ClusterItem> clusterItems = clusterList[i];
            vector<Line> clusterLines;
            vector<int> clusterWeights;
            for (int k = 0; k < clusterItems.size(); k++) {
                clusterLines.push_back(oldLines[clusterItems[k].getIdx()]);
                clusterWeights.push_back(oldWeights[clusterItems[k].getIdx()]);
            }
            Line medianLine = getMedianLine(clusterLines, medianAngle, clusterWeights);
            vector<Line> medianLines;
            medianLines.push_back(medianLine);
            vector<int> weights = computeLineWeight(medianLines, contours, 3);
            resAngles.push_back(medianAngle);
            resWeights.push_back(weights[0]);
            resLines.push_back(medianLine);
            resClusterIds.push_back(clusterId);

        }


    }

    HoughSupportLine mergeSupportLine(HoughSupportLine supportLine, vector<vector<cv::Point>> contours) {
        vector<Line> newLines;
        vector<double> newAngles;
        vector<int> newWeights;
        vector<int> newIds;
        int clusterNum = supportLine.getClusterValues().size();
        for (int i = 0; i < clusterNum; i++) {
            mergeCluster(supportLine, i, contours, newLines, newAngles, newWeights, newIds);
        }
        vector<double> clusterValues;
        clusterValues=supportLine.getClusterValues();
        HoughSupportLine newSL = HoughSupportLine(newLines, newWeights, newIds, newAngles, clusterValues);
        return newSL;

    }