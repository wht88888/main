#include"geom/LineClusterDBSCAN.h"
using namespace std;

vector<ClusterItem> buildPointFromLineAngle(vector<double> lineAngles) {
        vector<ClusterItem> points;
        for (int i = 0; i < lineAngles.size(); i++) {
            vector<double> angleWrapper(1);
            angleWrapper[0] = lineAngles[i];
            ClusterItem item = ClusterItem(angleWrapper, i);
            points.push_back(item);

        }
        return points;
    }

    double getClusterMedia(vector<double> lineAngles, vector<int> lineWeights) {
        double median = 0;
        int weightSum = 0;
        int verticalLineNum = 0; 
        vector<double> correctLineAngles;
        for (int i = 0; i < lineAngles.size(); i++) { 
            double angle = lineAngles[i];
            if (angle < 0) {
                angle += 180;
            } else if (angle > 180) {
                angle -= 180;
            }
            if (angle > 45 && angle < 135) {
                verticalLineNum++;
            }
            correctLineAngles.push_back(angle);

        }
        bool isVerticalCluster = (verticalLineNum > lineAngles.size() / 2);
        for (int i = 0; i < lineAngles.size(); i++) {
            double angle = correctLineAngles[i];
            if (!isVerticalCluster) {
                if (angle > 90) {
                    angle -= 180;
                }
            }
            median += angle * lineWeights[i];
            weightSum += lineWeights[i];
        }
        return median / weightSum;
    }

    vector<double> getClusterMedians(vector<int> clusterLabels, vector<double> lineAngles, vector<int> lineWeights) {
        vector<double> clusterMedians;
        std::unordered_map<int, vector<int>> labelDict;
        for (int i = 0; i < clusterLabels.size(); i++) {
            int label = clusterLabels[i];
            if (label == -1) {
                continue;
            }
            if (labelDict.find(label) == labelDict.end()) {
                vector<int> v;
                labelDict.insert({label,v});
            }
            labelDict[label].push_back(i);
        }
        int labelNum = labelDict.size();
        vector<double> labelLineAngles;
        vector<int> labelLineWeights;
        for (int i = 0; i < labelNum; i++) {
            labelLineAngles.clear();
            labelLineWeights.clear();
            int label = i;
            vector<int> labelIdx = labelDict[label];
            for (int k = 0; k < labelIdx.size(); k++) {
                labelLineAngles.push_back(lineAngles[labelIdx[k]]);
                labelLineWeights.push_back(lineWeights[labelIdx[k]]);
            }
            double median = getClusterMedia(labelLineAngles, labelLineWeights);
            clusterMedians.push_back(median);

        }
        return clusterMedians;
    }

    std::pair<vector<int>, vector<double>> cluster(vector<double> lineAngles, vector<int> lineWeights,float eps,int min_num) {
        vector<ClusterItem> points = buildPointFromLineAngle(lineAngles);
        DBScan<ClusterItem> model(eps,min_num);
        vector<vector<ClusterItem>> clusters = model.GetClusters(points,true);
        vector<int> clusterLabels;
        for (int i = 0; i < lineAngles.size(); i++) {
            clusterLabels.push_back(UNCLUSTER_LABEL);
        } 
        for (int i = 0; i < clusters.size(); i++) {
            vector<ClusterItem> clusterItems = clusters[i];
            for (int k = 0; k < clusterItems.size(); k++) {
                clusterLabels[clusterItems[k].getIdx()] = i;
            }
        }
        vector<double> clusterValues = getClusterMedians(clusterLabels, lineAngles, lineWeights);
        return pair<vector<int>, vector<double>>(clusterLabels, clusterValues);
    }