#include"geom/HungarianAlgorithm.h"
using namespace std;

    HungarianAlgorithm::HungarianAlgorithm(vector<vector<double>> costMatrix) {
        this->dim = max(costMatrix.size(), costMatrix[0].size());
        this->rows = costMatrix.size();
        this->cols = costMatrix[0].size();
        this->costMatrix = vector<vector<double>>(this->dim);
        for (int w = 0; w < this->dim; w++) {
            if (w < costMatrix.size()) {
                if (costMatrix[w].size() != this->cols) {
                    cout<<"Irregular cost matrix"<<endl;
                    break;
                }
                for (int j = 0; j < this->cols; j++) {
                    if (isinf(costMatrix[w][j])) {
                        cout<<"Infinite cost"<<endl;
                        break;
                    }
                    if (isnan(costMatrix[w][j])) {
                        cout<<"NaN cost"<<endl;
                        break;
                    }
                }
                this->costMatrix[w].assign(costMatrix[w].begin(), costMatrix[w].begin()+this->dim);
            } else {
                this->costMatrix[w] = vector<double>(this->dim);
            }
        }
        labelByWorker = vector<double>(this->dim);
        labelByJob = vector<double>(this->dim);
        minSlackWorkerByJob = vector<int>(this->dim);
        minSlackValueByJob = vector<double>(this->dim);
        committedWorkers = vector<bool>(this->dim);
        parentWorkerByCommittedJob = vector<int>(this->dim);
        matchJobByWorker = vector<int>(this->dim);
        fill(matchJobByWorker.begin(),matchJobByWorker.end(), -1);
        matchWorkerByJob = vector<int>(this->dim);
        fill(matchWorkerByJob.begin(),matchWorkerByJob.end(), -1);
    }

    void HungarianAlgorithm::computeInitialFeasibleSolution() {
        for (int j = 0; j < dim; j++) {
            labelByJob[j] = DBL_MAX;
        }
        for (int w = 0; w < dim; w++) {
            for (int j = 0; j < dim; j++) {
                if (costMatrix[w][j] < labelByJob[j]) {
                    labelByJob[j] = costMatrix[w][j];
                }
            }
        }
    }

    vector<int> HungarianAlgorithm::execute() {
        reduce();
        computeInitialFeasibleSolution();
        greedyMatch();

        int w = fetchUnmatchedWorker();
        while (w < dim) {
            initializePhase(w);
            executePhase();
            w = fetchUnmatchedWorker();
        }
        vector<int> result;
        result.assign(matchJobByWorker.begin(), matchJobByWorker.begin()+rows);
        for (w = 0; w < result.size(); w++) {
            if (result[w] >= cols) {
                result[w] = -1;
            }
        }
        return result;
    }

    void HungarianAlgorithm::executePhase() {
        while (true) {
            int minSlackWorker = -1, minSlackJob = -1;
            double minSlackValue = DBL_MAX;
            for (int j = 0; j < dim; j++) {
                if (parentWorkerByCommittedJob[j] == -1) {
                    if (minSlackValueByJob[j] < minSlackValue) {
                        minSlackValue = minSlackValueByJob[j];
                        minSlackWorker = minSlackWorkerByJob[j];
                        minSlackJob = j;
                    }
                }
            }
            if (minSlackValue > 0) {
                updateLabeling(minSlackValue);
            }
            parentWorkerByCommittedJob[minSlackJob] = minSlackWorker;
            if (matchWorkerByJob[minSlackJob] == -1) {
                int committedJob = minSlackJob;
                int parentWorker = parentWorkerByCommittedJob[committedJob];
                while (true) {
                    int temp = matchJobByWorker[parentWorker];
                    match(parentWorker, committedJob);
                    committedJob = temp;
                    if (committedJob == -1) {
                        break;
                    }
                    parentWorker = parentWorkerByCommittedJob[committedJob];
                }
                return;
            } else {
                int worker = matchWorkerByJob[minSlackJob];
                committedWorkers[worker] = true;
                for (int j = 0; j < dim; j++) {
                    if (parentWorkerByCommittedJob[j] == -1) {
                        double slack = costMatrix[worker][j] - labelByWorker[worker]
                                - labelByJob[j];
                        if (minSlackValueByJob[j] > slack) {
                            minSlackValueByJob[j] = slack;
                            minSlackWorkerByJob[j] = worker;
                        }
                    }
                }
            }
        }
    }

    int HungarianAlgorithm::fetchUnmatchedWorker() {
        int w;
        for (w = 0; w < dim; w++) {
            if (matchJobByWorker[w] == -1) {
                break;
            }
        }
        return w;
    }

    void HungarianAlgorithm::greedyMatch() {
        for (int w = 0; w < dim; w++) {
            for (int j = 0; j < dim; j++) {
                if (matchJobByWorker[w] == -1 && matchWorkerByJob[j] == -1
                        && costMatrix[w][j] - labelByWorker[w] - labelByJob[j] == 0) {
                    match(w, j);
                }
            }
        }
    }

    void HungarianAlgorithm::initializePhase(int w) {
        fill(committedWorkers.begin(),committedWorkers.end(), false);
        fill(parentWorkerByCommittedJob.begin(),parentWorkerByCommittedJob.end(), -1);
        committedWorkers[w] = true;
        for (int j = 0; j < dim; j++) {
            minSlackValueByJob[j] = costMatrix[w][j] - labelByWorker[w]
                    - labelByJob[j];
            minSlackWorkerByJob[j] = w;
        }
    }

    void HungarianAlgorithm::match(int w, int j) {
        matchJobByWorker[w] = j;
        matchWorkerByJob[j] = w;
    }

    void HungarianAlgorithm::reduce() {
        for (int w = 0; w < dim; w++) {
            double min = DBL_MAX;
            for (int j = 0; j < dim; j++) {
                if (costMatrix[w][j] < min) {
                    min = costMatrix[w][j];
                }
            }
            for (int j = 0; j < dim; j++) {
                costMatrix[w][j] -= min;
            }
        }
        vector<double> min = vector<double>(dim);
        for (int j = 0; j < dim; j++) {
            min[j] = DBL_MAX;
        }
        for (int w = 0; w < dim; w++) {
            for (int j = 0; j < dim; j++) {
                if (costMatrix[w][j] < min[j]) {
                    min[j] = costMatrix[w][j];
                }
            }
        }
        for (int w = 0; w < dim; w++) {
            for (int j = 0; j < dim; j++) {
                costMatrix[w][j] -= min[j];
            }
        }
    }

    void HungarianAlgorithm::updateLabeling(double slack) {
        for (int w = 0; w < dim; w++) {
            if (committedWorkers[w]) {
                labelByWorker[w] += slack;
            }
        }
        for (int j = 0; j < dim; j++) {
            if (parentWorkerByCommittedJob[j] != -1) {
                labelByJob[j] -= slack;
            } else {
                minSlackValueByJob[j] -= slack;
            }
        }
    }