#include"geom/ClusterItem.h"

ClusterItem::ClusterItem(std::vector<double> point, int idx) {
        this->point = point;
        this->idx = idx;
}

int ClusterItem::getIdx() {
        return this->idx;
}

std::vector<double> ClusterItem::getPoint() {
        return this->point;
}

bool ClusterItem::equals(ClusterItem other) {
        return point == other.point && idx == other.idx;
}