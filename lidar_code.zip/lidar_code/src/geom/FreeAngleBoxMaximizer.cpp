#include"geom/FreeAngleBoxMaximizer.h"
using namespace std;
using namespace cv;

    template <typename ClassType,typename ObjectType>
    bool instanceof(ObjectType* obj){
        return dynamic_cast<ClassType*>(obj);
    }

    double FreeAngleBoxMaximizer::angleCluster(double angle) {
        angle = fabs((int)angle % 90);
        if (angle > 25 && angle < 65) {
            angle = 45;
        } else {
            angle = 0;
        }
        return angle;

    }

   vector<int> FreeAngleBoxMaximizer::calcAngleClustersConnectionMatrix(vector<double> clusterValues) {
       vector<int> cm;
        int n = clusterValues.size();
        for (int k = 0; k < n * n; k++) {
            int i = k / n;
            int j = k % n;
            double vi = clusterValues[i];
            double vj = clusterValues[j];
            double diff = fabs((int)(vi - vj) % 90);
            if (diff < angleEps || diff > 90 - angleEps) {
                cm.push_back(1);
            } else {
                cm.push_back(0);
            }

        }
        return cm;
    }

    void FreeAngleBoxMaximizer::normClusterWeights(vector<double> clusterValues,vector<int> &clusterWeights,vector<int> &clusterNums) {
        int n = clusterValues.size();
       vector<int> connectionMatrix = calcAngleClustersConnectionMatrix(clusterValues);
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i == j) {
                    continue;
                }
                int connectIdx = i * n + j;
                if (connectionMatrix[connectIdx] == 1 && clusterWeights[i] > clusterWeights[j]) {
                    clusterWeights[i]=clusterWeights[i] + clusterWeights[j];
                    clusterWeights[j]= 0;
                    clusterNums[i]= clusterNums[i] + clusterNums[j];
                    clusterNums[j]= 0;
                }
            }
        }
    }

    double FreeAngleBoxMaximizer::getRectAngle(vector<cv::Point> contour, HoughSupportLine sl) {
        //use line finder to return angle of a Contour:: return -1 :line finder is useless. return -2:the contour is noise
        int clusterNum = sl.getClusterValues().size();
       vector<int> clusterID2Num;
       vector<int> lineWeights;
       vector<int> lineNums;
       vector<int> linePre;
       vector<int> lineAfter;
       vector<int> isNoise;
        for (int i = 0; i < clusterNum; i++) {
            clusterID2Num.push_back(0);
            lineWeights.push_back(0);
            lineNums.push_back(0);
            linePre.push_back(-1);
            lineAfter.push_back(-1);
            isNoise.push_back(0);
        }

        for (int i = 0; i < sl.getClusterId().size(); i++) {
            int clusterId = sl.getClusterId()[i];
            int count = clusterID2Num[clusterId];
            clusterID2Num[clusterId]=count + 1;
        }
        for (int i = 0; i < sl.getLineCoords().size(); i++) {
            int clusterId = sl.getClusterId()[i];
            Line line = sl.getLineCoords()[i];
            int w = computeLineWeight_box(line, contour, maxLine2PointDist);
            if (w >= minLineWeightTh) {
                lineWeights[clusterId]= lineWeights[clusterId] + w;
                lineNums[clusterId]= lineNums[clusterId] + 1;
                if(linePre[clusterId]==-1){
                    linePre[clusterId]=i;
                }
                else{
                    lineAfter[clusterId]=i;
                }
            }
        }
        normClusterWeights(sl.getClusterValues(), lineWeights, lineNums);
        bool notNoise=false;
        for(int i=0;i < lineWeights.size(); i++){
            if(lineNums[i]>3)
            {
                notNoise=true;
            }
        }
        if(!notNoise&&contourArea(contour) < 10000){
            //find noise:if a contour satisfies following conditions, return -2 as noise
            for (int i = 0; i < lineWeights.size(); i++) {
                for (int j = i + 1; j < lineWeights.size(); j++){
                    if(lineNums[i]==1 &&lineNums[j]==1){
                        Line line1=sl.getLineCoords()[linePre[i]];
                        Line line2=sl.getLineCoords()[linePre[j]];
                        double angle1=sl.getLineAngles()[linePre[i]];
                        double angle2=sl.getLineAngles()[linePre[j]];
                        angle1=((int)angle1+180)%180;
                        angle2=((int)angle2+180)%180;
                        double diff=fabs(angle1-angle2);
                        double minDist1=min(getPointDist(line1.getU(),line2.getU()),getPointDist(line1.getU(),line2.getV()));
                        double minDist2=min(getPointDist(line1.getV(),line2.getU()),getPointDist(line1.getV(),line2.getV()));
                        double minDist=min(minDist1,minDist2);
                        if(((diff>15&&diff<75)||(diff>105&&diff<165))&&minDist<30){
                            return -2;
                        }
                    }
                }
            }
        }
        int maxIdx = -1;
        int maxWeight = 0;
        for (int i = 0; i < lineWeights.size(); i++) {
            if(lineNums[i]<2){
                continue;
            }
            if (lineWeights[i] > maxWeight) {
                maxWeight = lineWeights[i];
                maxIdx = i;
            }
            if(lineNums[i]<3){
                //find noise:if a contour satisfies following conditions, return -2 as noise
                if(linePre[i]==-1 || lineAfter[i]==-1){
                    continue;
                }
                Line line1=sl.getLineCoords()[linePre[i]];
                Line line2=sl.getLineCoords()[lineAfter[i]];
                mPoint s1u=line1.getU();
                mPoint s1v=line1.getV();
                mPoint s2u=line2.getU();
                mPoint s2v=line2.getV();
                mPoint mPoint;
                if(getPointDist(s1u,line2.center())<getPointDist(s1v,line2.center())){
                    mPoint=s1u;
                }
                else{
                    mPoint=s1v;
                }
                double dot =pointDot(s2v.subtract(s2u),mPoint.subtract(s2u))*pointDot(s2v.subtract(s2u),mPoint.subtract(s2v));
                if(point2LineDistance(line1.center(),line2)<30 && (dot<=0 || getPointDist(line1.center(),line2.center())<80))
                {
                    isNoise[i]=1;
                }
            }
        }
        if (maxIdx == -1) {
            return -1;
        }
        else if (isNoise[maxIdx] == 1){
            return -2;
        }
        return sl.getClusterValues()[maxIdx];
    }


   vector<mPoint> FreeAngleBoxMaximizer::getMinimalRect(vector<cv::Point> contour, double angle) {
        mPoint center = computeCenterOfContour(contour);
       vector<mPoint> points = Contour::getPointList(contour);

       vector<mPoint> rotatePoints;
        for(int i=0;i<points.size();i++){
            rotatePoints.push_back(rotatePoint(points[i], center, -angle));
        }
       vector<mPoint> rotateRect=getBoundingRect(rotatePoints);
        vector<mPoint> result;
        for(int i=0;i<rotateRect.size();i++){
            result.push_back(rotatePoint(rotateRect[i], center, angle));
        }
        return result;
    }

   vector<vector<cv::Point>> FreeAngleBoxMaximizer::run(vector<SegmentRoom> rooms, HoughSupportLine sl, Mat floorMask) {
        //need the relationship between contours, move the following steps form VacuumCleanerHandler.java to here
        int ldkGroupId = -1;
        for (int i = 0; i < rooms.size(); i++) {
            if (rooms[i].getRoomType()=="LDK") {
                ldkGroupId = rooms[i].getGroupId();
                break;
            }
        }
        unordered_set<int> corridorIdxs;
        if (ldkGroupId != -1) {
            for (int i = 0; i < rooms.size(); i++) {
                if (rooms[i].getRoomType()!="LDK" && rooms[i].getGroupId() == ldkGroupId) {
                    corridorIdxs.insert(i);
                }
            }
        }
       vector<vector<mPoint>> contourPointsList;
        vector<vector<cv::Point>> boxContours;
        vector<bool> isTrustworthy;
        vector<double> angles;
        vector<mPoint> centers;
        for (int i = 0; i < rooms.size(); i++) {
            SegmentRoom room = rooms[i];
            vector<cv::Point> contour = room.getContours();
            if (contourArea(contour) < 4200) {
                //area<4200, mark as Not trustworthy
                isTrustworthy.push_back(false);
                angles.push_back(0.0);
               vector<mPoint> contourPoints = getMinimalRect(contour, 0.0);
                vector<cv::Point> mat = Contour::getContourFromPoints(contourPoints);
                Moments mo = moments(mat);
                int x_center = (int)(mo.m10/mo.m00);
                int y_center = (int)(mo.m01/mo.m00);
                mPoint p_center = mPoint(x_center,y_center);
                centers.push_back(p_center);
                contourPointsList.push_back(contourPoints);
                continue;
            }
            double angle0 = getRectAngle(contour, sl);
            bool useLine = true;
            bool isNoise = false;
            if(angle0 == -1){
                useLine = false;
                angle0 = 0;
            }
            if(angle0 == -2){
                isNoise = true;
                angle0 = 0;
            }
            angle0 = angleCluster(angle0);
            double angle1=0;
            double angle2=45;
           vector<mPoint> contourPoints0 = getMinimalRect(contour, angle0);
           vector<mPoint> contourPoints1 = getMinimalRect(contour, angle1);
           vector<mPoint> contourPoints2 = getMinimalRect(contour, angle2);
            vector<cv::Point> mat1 = Contour::getContourFromPoints(contourPoints1);
            vector<cv::Point> mat2 = Contour::getContourFromPoints(contourPoints2);
            double area1 = contourArea(mat1);
            double area2 = contourArea(mat2);
           vector<mPoint> contourPoints;
            //use area and linefinder to determine the angle
            // is noise or satisfy no condition, mark as Not trustworthy
            if (isNoise){
                contourPoints = contourPoints0;
                isTrustworthy.push_back(false);
                angles.push_back(angle0);
            }
            else if(1.3*area1<area2){
                contourPoints = contourPoints1;
                isTrustworthy.push_back(true);
                angles.push_back(angle1);
            }
            else if(1.3*area2<area1){
                contourPoints = contourPoints2;
                isTrustworthy.push_back(true);
                angles.push_back(angle2);
            }
            else if(useLine){
                contourPoints = contourPoints0;
                isTrustworthy.push_back(true);
                angles.push_back(angle0);
            }
            else if(1.10*area2<area1){
                contourPoints = contourPoints2;
                isTrustworthy.push_back(true);
                angles.push_back(angle2);
            }
            else{
                contourPoints = contourPoints0;
                isTrustworthy.push_back(false);
                angles.push_back(angle0);
            }
            vector<cv::Point> mat = Contour::getContourFromPoints(contourPoints);
            Moments mo = moments(mat);
            int x_center = (int)(mo.m10/mo.m00);
            int y_center = (int)(mo.m01/mo.m00);
            mPoint p_center = mPoint(x_center,y_center);
            centers.push_back(p_center);
            contourPointsList.push_back(contourPoints);
        }
        for (int i = 0; i < rooms.size(); i++){
            //for Not trustworthy, find the nearest contour, copy its angle
            if(!isTrustworthy[i]){
                double minDis=10000;
                int minIndex=-1;
                for(int j=0; j < rooms.size();j++){
                    if(j==i){
                        continue;
                    }
                    if(!isTrustworthy[j])
                    {
                        continue;
                    }
                    if(contourArea(rooms[j].getContours()) < 8000)
                    {
                        continue;
                    }
                    double distance = getPointDist(centers[i],centers[j]);
                    if(distance<minDis){
                        minDis=distance;
                        minIndex=j;
                    }
                }
                SegmentRoom room = rooms[i];
                vector<cv::Point> contour = room.getContours();
               vector<mPoint> contourPoints;
                if(minIndex==-1){
                    contourPoints = getMinimalRect(contour, 0);
                }
                else{
                    contourPoints = getMinimalRect(contour, angles[minIndex]);
                }
                contourPointsList[i]=contourPoints;
            }
        }
        for (int i = 0; i < rooms.size(); i++) {
           vector<mPoint> contourPoints = contourPointsList[i];
            bool isCorridor;
            if (corridorIdxs.find(i)!=corridorIdxs.end()) {
                isCorridor = true;
            }
            else{
                isCorridor = false;
            }
            if (!isCorridor) {
                boxContours.push_back(Contour::getContourFromPoints(contourPoints));
                continue;
            }
            Polygon* corridorPoly = createPolygon(contourPoints);
            Polygon* corridorRawPoly = buildRawPolygon(contourPoints, floorMask);
            CoordinateSequence* coords = corridorPoly->getExteriorRing()->getCoordinates().release();
            vector<LineString*> longLines;
            for (int j = 0; j < (*coords).size() - 1; j++) {
                Coordinate pt1 = (*coords)[j];
                Coordinate pt2 = (*coords)[j + 1];
                LineString* line = createLineString(mPoint((int) pt1.x, (int) pt1.y), mPoint((int) pt2.x, (int) pt2.y));
                longLines.push_back(line);
            }
            sort(longLines.begin(),longLines.end(),[](LineString* l1,LineString* l2){return l1->getLength()>l2->getLength();});
            longLines = vector<LineString*>(longLines.begin(),longLines.begin()+2);
            vector<mPoint> resultPoints;
            if (longLines[0]->getLength() < 150) {
                boxContours.push_back(Contour::getContourFromPoints(contourPoints));
                continue;
            }
            mPoint prePoint=mPoint(0,0);
            for (LineString* line : longLines) {
                LineString* shrinkLine1 = line;
                if (!isInnerLine(line, floorMask)) {
                    shrinkLine1 = shrinkLine(line, corridorRawPoly);
                }
                CoordinateSequence* lineCoords = shrinkLine1->getCoordinates().release();
                mPoint p1((int) round((*lineCoords)[0].x), (int) round((*lineCoords)[0].y));
                mPoint p2((int) round((*lineCoords)[1].x), (int) round((*lineCoords)[1].y));
                if(prePoint.x!=0 && prePoint.y!=0){
                    if(getPointDist(p1,prePoint)>getPointDist(p2,prePoint)){
                        mPoint temp=p1;
                        p1=p2;
                        p2=temp;
                    }
                }
                resultPoints.push_back(p1);
                resultPoints.push_back(p2);
                prePoint=resultPoints[resultPoints.size()-1];
            }
            boxContours.push_back(Contour::getContourFromPoints(resultPoints));
        }
        return boxContours;
    }

    bool FreeAngleBoxMaximizer::isInnerLine(LineString* line, Mat floorMask) {
        CoordinateSequence* lineCoordinates = line->getCoordinates().release();
        int x1 = (int) round((*lineCoordinates)[0].x), y1 = (int) round((*lineCoordinates)[0].y);
        int x2 = (int) round((*lineCoordinates)[1].x), y2 = (int) round((*lineCoordinates)[1].y);
        int rowStart = (int) min(y1, y2);
        int rowEnd = (int) max(y1, y2) + 1;
        int colStart = (int) min(x1, x2);
        int colEnd = (int) max(x1, x2) + 1;
        if(rowStart<0){
            rowStart=0;
        }
        if(rowEnd>floorMask.rows-1){
            rowEnd=floorMask.rows-1;
        }
        if(colStart<0){
            colStart=0;
        }
        if(colEnd>floorMask.cols-1){
            colEnd=floorMask.cols-1;
        }
        return countNonZero(floorMask(Range(rowStart, rowEnd),Range(colStart, colEnd))) > 0;
    }

    LineString* FreeAngleBoxMaximizer::shrinkLine(LineString* line, Polygon* rawPoly) {
        double tentativeOffset = 10.0;
        CoordinateSequence *offsetLineCoord = geos::operation::buffer::OffsetCurve::rawOffset(*line, tentativeOffset).release();
        LineString* offsetLine = createLineString(*offsetLineCoord);
        Geometry* dilatedLine = offsetLine->buffer(1).release();
        if (dilatedLine->intersection(rawPoly)->getArea() < 0.0001) {
            tentativeOffset = -10.0;
        }
        double stepSize = tentativeOffset / 5;
        int totalStep = 10;
        double cutRatio = 0.3;

        LineString* bestShrinkLine = line;
        for (int i = 1; i < totalStep; i++) {
            offsetLineCoord = geos::operation::buffer::OffsetCurve::rawOffset(*line, i * stepSize).release();
            offsetLine = createLineString(*offsetLineCoord);

            Geometry* intersectLine = rawPoly->intersection(offsetLine).release();
            if ( instanceof<LineString>(intersectLine)|| instanceof<MultiLineString>(intersectLine)) {
                if (intersectLine->getLength() > cutRatio * line->getLength()) {
                    return bestShrinkLine;
                }
            }

            bestShrinkLine = offsetLine;
        }
        return offsetLine;
    }