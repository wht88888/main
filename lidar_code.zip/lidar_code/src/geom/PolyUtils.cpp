#include<geom/PolyUtils.h>
using namespace std;
using namespace cv;

    template <typename ClassType,typename ObjectType>
    bool instanceof(ObjectType* obj){
        return dynamic_cast<ClassType*>(obj);
    }

    GeometryFactory::Ptr geometryFactory;

    Polygon *createEmptyPolygon() {
        return (Polygon*)geometryFactory->createEmpty(2).release();
    }

    LineString *createEmptyLineString() {
        return (LineString*) geometryFactory->createEmpty(1).release();
    }

    gPoint *createEmptyPoint() {
        return (gPoint*) geometryFactory->createEmpty(0).release();
    }

    Polygon *createPolygon(CoordinateSequence coords) {
        return (Polygon *)geometryFactory->createPolygon(geometryFactory->createLinearRing(coords)).release();
    }

    Polygon *createPolygon(vector<mPoint> points) {
        CoordinateSequence coords;
        for (int i = 0; i < points.size(); i++) {
            Coordinate coord = Coordinate(points[i].x, points[i].y);
            coords.add(coord);
        }
        coords.add(Coordinate(points[0].x, points[0].y));
        return createPolygon(coords);
    }

    unique_ptr<LineString> createLineStringUnique(CoordinateSequence coords) {
        return geometryFactory->createLineString(coords);
    }

    LineString *createLineString(CoordinateSequence coords) {
        return (LineString*)geometryFactory->createLineString(coords).release();
    }

    LineString *createLineString(mPoint p1, mPoint p2) {
        CoordinateSequence coords;
        Coordinate coord =Coordinate(p1.x, p1.y);
        coords.add(coord);
        coord = Coordinate(p2.x, p2.y);
        coords.add(coord);

        return createLineString(coords);
    }

    gPoint *createPoint(Coordinate coord) {
        return (gPoint*)geometryFactory->createPoint(coord).release();
    }


    gPoint *createPoint(mPoint point) {
        Coordinate coord = Coordinate(point.x, point.y);
        return createPoint(coord);
    }

    vector<Polygon*> geometryCollection2Polygons(GeometryCollection* collection) {
        vector<Polygon*> polys;
        for (int i = 0; i < collection->getNumGeometries(); i++) {
            Geometry* geom = (Geometry*)collection->getGeometryN(i);
            if (instanceof<MultiPolygon>(geom) || instanceof<GeometryCollection>(geom)) {
                vector<Polygon*> temp = geometryCollection2Polygons((GeometryCollection*) geom);
                for(int i=0;i<temp.size();i++){
                    polys.push_back(temp[i]);
                }
            } else if (instanceof<Polygon>(geom)) {
                polys.push_back((Polygon*) geom);
            }
        }
        return polys;
    }

    MultiLineString *createMultiLineString(vector<unique_ptr<LineString>> lines) {
        return geometryFactory->createMultiLineString(move(lines)).release();
    }

    pair<bool, Polygon*> makeValidRoom(Geometry *poly) {
        Geometry* validPoly = poly;
        if (!poly->isValid()) {
            validPoly = geos::geom::util::GeometryFixer::fix(poly).release();
        }
        if (instanceof<MultiPolygon>(validPoly) || instanceof<GeometryCollection>(validPoly)) {
            vector<Polygon*> polys = geometryCollection2Polygons((GeometryCollection*) validPoly);
            sort(polys.begin(),polys.end(),[](Polygon* p1,Polygon* p2){return p1->getArea()>p2->getArea();});
            if (polys.size() > 0) {
                return pair<bool, Polygon*>(true, polys[0]);
            } else {
                return pair<bool, Polygon*>(false, (Polygon*)geometryFactory->createPolygon().release());
            }
        } else if (instanceof<Polygon>(validPoly)) {
            return pair<bool, Polygon*>(true, (Polygon*) validPoly);
        } else {
            return pair<bool, Polygon*>(false, geometryFactory->createPolygon().release());
        }
    }

    Polygon *points2Poly(vector<mPoint> points) {
        return createPolygon(points);
    }

    Polygon *points2Poly(vector<cv::Point> contour) {
        vector<mPoint> points = Contour::getPointList(contour);
        return points2Poly(points);
    }


    vector<Polygon*> buildRawPolygons(SegmentInfo segmentInfo) {
        vector<SegmentRoom> rooms = segmentInfo.getRooms();
        vector<Polygon*> rawPolys;
        for (int i = 0; i < rooms.size(); i++) {
            vector<cv::Point> roomContour = rooms[i].getContours();
            Polygon* poly = points2Poly(roomContour);
            pair<bool, Polygon*> validInfo = makeValidRoom(poly);
            Polygon* validRoom = validInfo.second;
            validRoom = (Polygon*) geos::simplify::TopologyPreservingSimplifier::simplify(validRoom, 6).release();
            if (validInfo.first && validRoom->getArea() > 0) {
                rawPolys.push_back(validRoom);
            }
        }
        return rawPolys;
    }

    Polygon* makePolygonCCW(Polygon* poly) {
        if (!geos::algorithm::Orientation::isCCW(poly->getExteriorRing()->getCoordinates().release())) {
            return poly->reverse().release();
        } else {
            return poly;
        }
    }

    vector<LineString*> polygon2Lines(Polygon* poly) {
        vector<LineString*> lines;
        CoordinateSequence* coords = poly->getExteriorRing()->getCoordinates().release();
        for (int i = 0; i < coords->size() - 1; i++) {
            int j = i + 1;
            CoordinateSequence lineCoords(2);
            lineCoords[0] = Coordinate((*coords)[i].x,(*coords)[i].y);
            lineCoords[1] = Coordinate((*coords)[j].x,(*coords)[j].y);
            LineString* lineString = geometryFactory->createLineString(lineCoords).release();
            lines.push_back(lineString);
        }
        return lines;
    }

    vector<LineString*> geometryCollection2Lines(Geometry* Geometry) {
        vector<LineString*> lines;
        if (instanceof<Polygon>(Geometry)) {
            return polygon2Lines((Polygon*) Geometry);
        } else if (instanceof<MultiPolygon>(Geometry)) {
            for (int i = 0; i < ((MultiPolygon*) Geometry)->getNumGeometries(); i++) {
                vector<LineString*> temp =polygon2Lines((Polygon*) (((MultiPolygon*) Geometry)->getGeometryN(i)));
                for(int j=0;j<temp.size();j++){
                    lines.push_back(temp[j]);
            }
            }
        } else if (instanceof<GeometryCollection>(Geometry)) {
            for (int i = 0; i < ((GeometryCollection*) Geometry)->getNumGeometries(); i++) {
                vector<LineString*> temp = geometryCollection2Lines((geos::geom::Geometry* )((GeometryCollection*) Geometry)->getGeometryN(i));
                for(int j=0;j<temp.size();j++){
                    lines.push_back(temp[j]);
            }
            }
        }
        return lines;
    }

    vector<LineString*> getRoomsLines(vector<Polygon*> polygons) {
        vector<LineString*> lines;
        for (int i = 0; i < polygons.size(); i++) {
            vector<LineString*> temp = geometryCollection2Lines(polygons[i]);
            for(int j=0;j<temp.size();j++){
                    lines.push_back(temp[j]);
            }
        }
        return lines;
    }

    Polygon* buildRawPolygon(Contour contour, Mat floorMask) {
        Mat roomMask = Mat(floorMask.rows, floorMask.cols, CV_8UC1, Scalar(0));
        vector<vector<cv::Point>> contourMats;
        contourMats.push_back(Contour::getContourFromPoints(contour.getContourPoints()));
        drawContours(roomMask, contourMats, -1, Scalar(1), FILLED);
        roomMask = roomMask.mul(floorMask);
        contourMats.clear();
        Mat hierarchy = Mat();
        findContours(roomMask, contourMats, hierarchy, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
        sort(contourMats.begin(),contourMats.end(),[](vector<cv::Point> v1,vector<cv::Point> v2){return contourArea(v1)>contourArea(v2);});
        if (contourMats.size() == 0) {
            return createEmptyPolygon();
        }
        vector<cv::Point> targetContourMat = contourMats[0];
        Polygon* targetPoly = createPolygon(Contour::getPointList(targetContourMat));
        pair<bool, Polygon*> validInfo = makeValidRoom(targetPoly);
        if (validInfo.first) {
            return (Polygon*) geos::simplify::TopologyPreservingSimplifier::simplify(validInfo.second, 6.0).release();
        }
        return createEmptyPolygon();

    }

    Polygon* buildRawPolygon(vector<mPoint> contourPoints, Mat floorMask) {
        Mat roomMask = Mat(floorMask.rows, floorMask.cols, CV_8UC1, Scalar(0));
        vector<vector<cv::Point>> contourMats;
        contourMats.push_back(Contour::getContourFromPoints(contourPoints));
        drawContours(roomMask, contourMats, -1, Scalar(1), FILLED);
        roomMask = roomMask.mul(floorMask);
        contourMats.clear();
        Mat hierarchy = Mat();
        findContours(roomMask, contourMats, hierarchy, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
        sort(contourMats.begin(),contourMats.end(),[](vector<cv::Point> v1,vector<cv::Point> v2){return contourArea(v1)>contourArea(v2);});
        if (contourMats.size() == 0) {
            return createEmptyPolygon();
        }
        vector<cv::Point> targetContourMat = contourMats[0];
        Polygon* targetPoly = createPolygon(Contour::getPointList(targetContourMat));
        pair<bool, Polygon*> validInfo = makeValidRoom(targetPoly);
        if (validInfo.first) {
            return (Polygon*) geos::simplify::TopologyPreservingSimplifier::simplify(validInfo.second, 6.0).release();
        }
        return createEmptyPolygon();
    }

    vector<pair<Polygon*, Contour>> getRoomPolygons(vector<Contour> contours) {
        vector<pair<Polygon*, Contour>> contourAndPolys;
        for (int i = 0; i < contours.size(); i++) {
            Polygon* poly = createPolygon(contours[i].getContourPoints());
            if (poly->getArea() < 0.01) {
                continue;
            }
            pair<bool, Polygon*> validInfo = makeValidRoom(poly);
            if (validInfo.first) {
                contourAndPolys.push_back(pair<Polygon*, Contour>(poly, contours[i]));
            }
        }
        return contourAndPolys;
    }


    LineString* extendLine(int h, int w, Line line) {
        mPoint pt1 = line.getU();
        mPoint pt2 = line.getV();

        double vx = pt1.x - pt2.x;
        double vy = pt1.y - pt2.y;
        double x0 = (pt1.x + pt2.x) / 2.0;
        double y0 = (pt1.y + pt2.y) / 2.0;
        line = vector2PointLine(vx, vy, x0, y0, w, h);
        return createLineString(line.getU(), line.getV());

    }


