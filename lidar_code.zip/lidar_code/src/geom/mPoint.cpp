#include "geom/mPoint.h"
mPoint::mPoint()
{
    this->x = 0;
    this->y = 0;
}

mPoint::mPoint(int x, int y)
{
    this->x = x;
    this->y = y;
}

void mPoint::move(int dx, int dy)
{
    x += dx;
    y += dy;
}

void mPoint::scale(double sx, double sy)
{
    x = (int)round(x * sx);
    y = (int)round(y * sy);
}

mPoint mPoint::subtract(mPoint pt)
{
    return mPoint(this->x - pt.x, this->y - pt.y);
}

mPoint mPoint::add(mPoint pt)
{
    return mPoint(this->x + pt.x, this->y + pt.y);
}

std::string mPoint::toString()
{
    std::string s = "(" + std::to_string(x) + ", " + std::to_string(y) + ")";
    return s;
}