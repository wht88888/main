#include"geom/HoughSupportLine.h"
using namespace std;

    vector<Line> HoughSupportLine::getLineCoords() {
        return this->lineCoords;
    }

    vector<int> HoughSupportLine::getLineWeights() {
        return this->lineWeights;
    }

    vector<int> HoughSupportLine::getClusterId() {
        return this->clusterId;
    }

    vector<double> HoughSupportLine::getLineAngles() {
        return this->lineAngles;
    }

    vector<double> HoughSupportLine::getClusterValues() {
        return this->clusterValues;
    }

HoughSupportLine::HoughSupportLine(vector<Line> lineCoords, vector<int> lineWeights, vector<int> clusterId, vector<double> lineAngles, vector<double> clusterValues) {
        this->lineCoords = lineCoords;
        this->lineWeights = lineWeights;
        this->clusterId = clusterId;
        this->lineAngles = lineAngles;
        this->clusterValues = clusterValues;
    }