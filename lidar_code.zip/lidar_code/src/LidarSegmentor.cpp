#include "LidarSegmentor.h"
#include "time.h"
#include<dirent.h>

using namespace std;
using namespace cv;


int main(int argc, char *argv[]){
    double time1=clock();
    int cnt=0;
    string filename = "4.png";
    string model_name = "rtmdet_int8.ort";
    if (argc > 2) model_name = argv[2];
    if (argc > 1) filename=argv[1];
    if(filename=="total1"||filename=="total2"){
        string dirname;
        if(filename=="total1")
        {   
            dirname="input";
        }
        else{
            dirname="slope_input";
        }
        // string dirname="slope_input";
        DIR* dirp=opendir(dirname.c_str());
        if(dirp!=nullptr){
            struct dirent* dp;
            while((dp=readdir(dirp))!=nullptr){
                if(string(dp->d_name)!="."&&string(dp->d_name)!=".."){
                    cnt++;
                    double time2=clock();
                    cout<<string(dp->d_name)<<endl;
                    Mat img;
                    img = imread(dirname+"/"+string(dp->d_name), IMREAD_GRAYSCALE);
                    img = cutBlack(img);
                    pair<pair<vector<vector<cv::Point>>,vector<Line>>,pair<Mat,string>> boxContours = run(model_name,img);
  
                    Mat debugMat=binary2Show(boxContours.second.first);
                    cvtColor(debugMat, debugMat, COLOR_GRAY2BGR);
                    drawContours(debugMat, boxContours.first.first, -1, Scalar(0, 255, 0), 3);
                    for (int i = 0; i < boxContours.first.second.size(); i++) {
                        Line line = boxContours.first.second[i];
                        mPoint pt1 = line.getU();
                        mPoint pt2 = line.getV();
                        cv::line(debugMat, cv::Point(pt1.x, pt1.y), cv::Point(pt2.x, pt2.y), Scalar(0, 0, 255), 3);
                    }
                    double time3=clock();
                    cout<<"total:"<<(time3-time2)/CLOCKS_PER_SEC<<endl;
                    cout<<"average:"<<((time3-time1)/CLOCKS_PER_SEC)/cnt<<endl;
                    if(filename=="total1")
                    {
                        imwrite("output/"+string(dp->d_name),debugMat);
                    }
                    else
                    {
                        imwrite("slope_output/"+string(dp->d_name),debugMat);
                    }

                    HoughSupportLineFinder finder(5, 50, 10, 14, 1);
                    HoughSupportLine sl = finder.run(boxContours.second.first);
                    Mat lineResult = finder.getDebugImage(sl,binary2Show(boxContours.second.first)).first;
                   if(filename=="total1")
                    {
                        imwrite("lineResult/"+string(dp->d_name),lineResult);
                    }
                    else
                    {
                        imwrite("slope_lineResult/"+string(dp->d_name),lineResult);
                    }
                }
            }
        }
        closedir(dirp);
        return 0;
    }
    Mat img;
    img = imread(filename, IMREAD_GRAYSCALE);
    img = cutBlack(img);

    pair<pair<vector<vector<cv::Point>>,vector<Line>>,pair<Mat,string>> boxContours = run(model_name,img);
  
    Mat debugMat=binary2Show(boxContours.second.first);
    cvtColor(debugMat, debugMat, COLOR_GRAY2BGR);
    drawContours(debugMat, boxContours.first.first, -1, Scalar(0, 255, 0), 3);
    for (int i = 0; i < boxContours.first.second.size(); i++) {
        Line line = boxContours.first.second[i];
        mPoint pt1 = line.getU();
        mPoint pt2 = line.getV();
        cv::line(debugMat, cv::Point(pt1.x, pt1.y), cv::Point(pt2.x, pt2.y), Scalar(0, 0, 255), 3);
    }
    double time2=clock();
    cout<<"total:"<<(time2-time1)/CLOCKS_PER_SEC<<endl;

    namedWindow("Image",WINDOW_AUTOSIZE);
    imwrite(filename+"_output.png",debugMat);
    imshow("Image",debugMat);
    waitKey(0);
    HoughSupportLineFinder finder(5, 50, 10, 14, 1);
    HoughSupportLine sl = finder.run(boxContours.second.first);
    Mat lineResult = finder.getDebugImage(sl,binary2Show(boxContours.second.first)).first;
    imwrite(filename+"_lineResult.png",lineResult);
    return 0;
}