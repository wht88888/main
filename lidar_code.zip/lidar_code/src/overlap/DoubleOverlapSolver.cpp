#include"overlap/DoubleOverlapSolver.h"
using namespace std;
using namespace cv;

    int minDoorWidth=30;
    double doorStringScale=10.0;

    vector<int> roomMatch(vector<Polygon*> rawPolys, vector<Polygon*> fitPolys) {
        int n = fitPolys.size();
        int m = rawPolys.size();

        vector<vector<double>> cost(n,vector<double>(m));
        for (int i = 0; i < n; i++) {
            Polygon* fitPoly = fitPolys[i];
            for (int j = 0; j < m; j++) {
                Polygon* rawPoly = rawPolys[j];
                cost[i][j] = (double)(1.0 - (fitPoly->intersection(rawPoly)->getArea() / (fitPoly->getArea() + 0.001)));
            }
        }
        HungarianAlgorithm matcher = HungarianAlgorithm(cost);
        return matcher.execute();
    }

    bool overlapByMaxAreaStrategy(vector<Polygon*> &polygons, Geometry* intersect, int i, int j, vector<Polygon*> rawPolys, vector<int> matchData) {
        Polygon* pi = polygons[i];
        Polygon* pj = polygons[j];
        int matchIdx1 = matchData[i];
        int matchIdx2 = matchData[j];
        intersect = makeValidRoom(intersect).second;
        if (matchIdx1 != -1 && matchIdx2 != -1) {
            Polygon* ri = rawPolys[matchIdx1];
            Polygon* rj = rawPolys[matchIdx2];
            Geometry* newPoly1 = pi->difference(pj).release();
            Geometry* newPoly2 = pj->Union(intersect).release();
            try{
                if (ri->intersection(intersect)->getArea() > rj->intersection(intersect)->getArea()) {
                newPoly1 = pi->Union(intersect).release();
                newPoly2 = pj->difference(pi).release();
                }
            }
            catch (Exception e){
                return false;
            }

            pair<bool, Polygon*> validInfo1 = makeValidRoom(newPoly1);
            pair<bool, Polygon*> validInfo2 = makeValidRoom(newPoly2);
            if (validInfo1.first && validInfo2.first) {
                polygons[i]= validInfo1.second;
                polygons[j]= validInfo2.second;
                return true;
            }

        }
        return false;
    }


    vector<Contour> DoubleOverlapSolver(SegmentInfo segmentInfo, vector<Contour> contours) {
        vector<Contour> roomContours;
        for(int i=0;i<contours.size();i++){
            if(contourArea(contours[i].getContourFromPoints(contours[i].getContourPoints()))>0)
            {
                roomContours.push_back(contours[i]);
            }
        }
        sort(roomContours.begin(),roomContours.end(),[](Contour contour1, Contour contour2){
            double area1 =contourArea(contour1.getContourFromPoints(contour1.getContourPoints()));
            double area2 =contourArea(contour2.getContourFromPoints(contour2.getContourPoints()));
            return area1>area2;
        });
        vector<Polygon*> polygons;
        for(int i=0;i<roomContours.size();i++){
            polygons.push_back(createPolygon(roomContours[i].getContourPoints()));
        }
        for (int i = 0; i < polygons.size(); i++) {
            pair<bool, Polygon*> validInfo = makeValidRoom(polygons[i]);
            if (validInfo.first) {
                polygons[i]= validInfo.second;
            }
        }

        vector<Polygon*> rawPolys = buildRawPolygons(segmentInfo);
        vector<int> matchData = roomMatch(rawPolys, polygons);
        int n = polygons.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = i + 1; j < n; j++) {
                Polygon* pi = polygons[i];
                Polygon* pj = polygons[j];
                Geometry* inter = pi->intersection(pj).release();
                bool resolved = false;
                if (inter->getArea() > 0) {
                    if (!resolved) {
                        resolved = overlapByMaxAreaStrategy(polygons, inter, i, j, rawPolys, matchData);
                    }
                }

            }
        }
        vector<Geometry*> geometries;
        for (int i = 0; i < n; i++) {
            geometries.push_back(geos::simplify::TopologyPreservingSimplifier::simplify(polygons[i], 3).release());
        }
        return buildResolvedContours(geometries, roomContours);

    }