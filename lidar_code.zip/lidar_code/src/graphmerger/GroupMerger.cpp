#include"graphmerger/GroupMerger.h"
using namespace std;
using namespace cv;

vector<Contour> GroupMerger(vector<Contour> contours) {
        vector<Contour> ldkContour;
        for(int i=0;i<contours.size();i++){
            if(contours[i].getLabel()=="LDK"){
                ldkContour.push_back(contours[i]);
            }
        }
        if (ldkContour.size() == 0) {
            return contours;
        }
        int ldkGroupId = ldkContour[0].getGroupId();
        vector<Contour> ldkGroup;
        vector<Contour> noneLdkGroup;
        for(int i=0;i<contours.size();i++){
            if(contours[i].getGroupId() == ldkGroupId){
                ldkGroup.push_back(contours[i]);
            }
            else{
                noneLdkGroup.push_back(contours[i]);
            }
        }
        vector<Geometry*> ldkPolys;
        vector<Geometry*> noneLdkPolys;
        for(int i=0;i<ldkGroup.size();i++){
            ldkPolys.push_back(createPolygon(ldkGroup[i].getContourPoints()));
        }
        for(int i=0;i<noneLdkGroup.size();i++){
            noneLdkPolys.push_back(createPolygon(noneLdkGroup[i].getContourPoints()));
        }
        double overlapTh = 1000;
        if (ldkGroup.size() == 1 && noneLdkGroup.size() == 1) {
            Geometry* boundingLdk = ldkPolys[0]->getEnvelope().release();
            Geometry* boundingRoom = noneLdkPolys[0]->getEnvelope().release();
            Geometry* overlapGeom = boundingLdk->intersection(boundingRoom).release();
            if (overlapGeom->getArea() < overlapTh) {
                Geometry* mergeLDK = ldkPolys[0]->buffer(0.1, 16, 3).release()->Union(noneLdkPolys[0]->buffer(0.1, 16, 3).release()).release();
                Contour ldkMergedContour = buildResolvedContour(mergeLDK, ldkGroup[0]);
                vector<Contour> resContour;
                resContour.push_back(ldkMergedContour);
                return resContour;
            }
        }
        Geometry* mergeLDK = createPolygon(ldkContour[0].getContourPoints());
        vector<int> undetermined;
        bool is_undetermined = false;
        for (int i = 0; i < ldkPolys.size(); i++) {
            Geometry* temp;
            temp = mergeLDK->buffer(0.1, 16, 3).release()->intersection(ldkPolys[i]->buffer(0.1, 16, 3).release()).release();
            if(temp->getArea()==0.0){
                undetermined.push_back(i);
                is_undetermined = true;
            }
            else{
                mergeLDK = mergeLDK->buffer(0.1, 16, 3).release()->Union(ldkPolys[i]->buffer(0.1, 16, 3).release()).release();
            }
        }
        if(is_undetermined){
            for(int i = 0; i < undetermined.size() && mergeLDK != NULL; i++){
                Geometry* temp;
                temp = mergeLDK->buffer(0.1, 16, 3).release()->intersection(ldkPolys[undetermined[i]]->buffer(0.1, 16, 3).release()).release();
                if(temp->getArea()==0.0){
                    noneLdkGroup.push_back(ldkGroup[undetermined[i]]);
                }
                else{
                    mergeLDK = mergeLDK->buffer(0.1, 16, 3).release()->Union(ldkPolys[undetermined[i]]->buffer(0.1, 16, 3).release()).release();
                }
            }
        }
        for (int i = 0; i < noneLdkPolys.size() && mergeLDK != NULL; i++) {
            mergeLDK = mergeLDK->difference(noneLdkPolys[i]).release();
        }
        Contour ldkMergedContour = buildResolvedContour(mergeLDK, ldkGroup[0]);

        noneLdkGroup.insert(noneLdkGroup.begin(), ldkMergedContour);
        return noneLdkGroup;
    }