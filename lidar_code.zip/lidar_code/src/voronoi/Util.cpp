#include "voronoi/Util.h"
#include "time.h"
using namespace std;
using namespace boost;

cv::Mat distTransform(cv::Mat binary_image)
{
    cv::Mat dist = cv::Mat();
    distanceTransform(binary_image, dist, cv::DIST_L2, 3);
    return dist;
}

cv::Mat iPhoneGetBinaryImage(cv::Mat image)
{
    int height = image.rows;
    int width = image.cols;
    cv::Mat res = cv::Mat(height, width, CV_8UC1, cv::Scalar(0));
    uchar *image_data = image.ptr<uchar>(0, 0);
    uchar *res_data = res.ptr<uchar>(0, 0);
    for (int i = 0; i < image.total(); i++)
    {
        if (image_data[i] > 128)
        {
            res_data[i] = (uchar)1;
        }
        else
        {
            res_data[i] = 0;
        }
    }
    // res.put(0, 0, image_data);
    return res;
}

cv::Mat getBinaryImage(cv::Mat image)
{
    int height = image.rows;
    int width = image.cols;
    cv::Mat res = cv::Mat(height, width, CV_8UC1, cv::Scalar(0));
    // uchar image_data[(int)image.total()];
    uchar *image_data = image.ptr<uchar>(0, 0);
    uchar *res_data = res.ptr<uchar>(0, 0);
    // image.get(0, 0, image_data);
    for (int i = 0; i < image.total(); i++)
    {
        if (image_data[i] != 0)
        {
            res_data[i] = (uchar)1;
        }
        else
        {
            res_data[i] = 0;
        }
    }
    // res.put(0, 0, image_data);
    return res;
}

cv::Mat binary2Show(cv::Mat binaryMat)
{
    cv::Mat resultMat = cv::Mat(binaryMat.rows, binaryMat.cols, CV_8UC1, cv::Scalar(0));
    // uchar data[(int)binaryMat.total()];
    uchar *data = binaryMat.ptr<uchar>(0, 0);
    uchar *res = resultMat.ptr<uchar>(0, 0);
    // binaryMat.get(0, 0, data);
    for (int i = 0; i < binaryMat.total(); i++)
    {
        if (data[i] > 0)
        {
            res[i] = (uchar)-1;
        }
        else
        {
            res[i] = 0;
        }
    }
    // resultMat.put(0, 0, data);
    return resultMat;
}

cv::Mat binary2ShowGray(cv::Mat binaryMat)
{
    cv::Mat resultMat = cv::Mat(binaryMat.rows, binaryMat.cols, CV_8UC1, cv::Scalar(255));
    // uchar data[(int)binaryMat.total()];
    uchar *data = resultMat.ptr<uchar>(0, 0);
    // binaryMat.get(0, 0, data);
    for (int i = 0; i < binaryMat.total(); i++)
    {
        if (data[i] != 0)
        {
            data[i] = (uchar)-80;
        }
        else if (data[i] == 0)
        {
            data[i] = (uchar)-1;
        }
    }
    // resultMat.put(0, 0, data);
    return resultMat;
}

pair<vector<vector<cv::Point>>, cv::Mat> getContourTree(cv::Mat mask)
{
    vector<vector<cv::Point>> contours;
    cv::Mat hierarchy = cv::Mat();
    findContours(mask, contours, hierarchy, cv::RETR_TREE, cv::CHAIN_APPROX_NONE);
    return pair<vector<vector<cv::Point>>, cv::Mat>(contours, hierarchy);
}

double getL2Dist(int x, int y, cv::Point point2)
{
    return (double)sqrt((point2.y - y) * (point2.y - y) + (point2.x - x) * (point2.x - x));
}

double getL2Dist(pair<int, int> p1, pair<int, int> p2)
{
    return (double)sqrt((p1.first - p2.first) * (p1.first - p2.first) + (p1.second - p2.second) * (p1.second - p2.second));
}

double getL2Dist(double x, double y, cv::Point point2)
{
    return (double)sqrt((point2.y - y) * (point2.y - y) + (point2.x - x) * (point2.x - x));
}

double getL2Dist(cv::Point point1, cv::Point point2)
{
    return (double)sqrt((point2.y - point1.y) * (point2.y - point1.y) + (point2.x - point1.x) * (point2.x - point1.x));
}

double getCosin(double u1, double v1, double u2, double v2)
{
    double len1 = sqrt(u1 * u1 + v1 * v1);
    double len2 = sqrt(u2 * u2 + v2 * v2);
    return (u1 * u2 + v1 * v2) / (len1 * len2);
}

vector<pair<int, int>> peakLocalMax(cv::Mat mask, cv::Mat distMat, int minDistance, double distTh)
{
    int height = distMat.rows;
    int width = distMat.cols;

    mask = binary2Show(mask);

    cv::Mat debugMat = cv::Mat();
    cvtColor(mask, debugMat, cv::COLOR_GRAY2BGR);
    bool peakData[height * width];
    fill(peakData, peakData + height * width, false);
    int footPrint = 2 * minDistance + 1;
    cv::Mat dilateMat = cv::Mat();
    cv::Mat dilateKernel = cv::Mat(footPrint, footPrint, CV_8UC1, cv::Scalar(1));
    dilate(distMat, dilateMat, dilateKernel);

    // float distData[(int)distMat.total()];
    // float dilateData[(int)dilateMat.total()];
    // distMat.get(0, 0, distData);
    // dilateMat.get(0, 0, dilateData);
    float *distData = distMat.ptr<float>(0, 0);
    float *dilateData = dilateMat.ptr<float>(0, 0);

    vector<pair<int, int>> coords;
    float maxVal = 0;
    int maxY = 0;
    int maxX = 0;
    for (int i = minDistance; i < height - minDistance; i++)
    {
        for (int j = minDistance; j < width - minDistance; j++)
        {
            int idx = i * width + j;
            if (distData[idx] > maxVal)
            {
                maxVal = distData[idx];
                maxY = i;
                maxX = j;
            }
            if (distData[idx] > distTh && fabs(distData[idx] - dilateData[idx]) < 0.00001)
            {

                coords.push_back(pair<int, int>(j, i));

                circle(debugMat, cv::Point(j, i), 3, cv::Scalar(0, 255, 0), cv::FILLED);
            }
        }
    }
    return coords;
}

cv::Mat segment2Color(cv::Mat segmentMat)
{
    cv::Scalar ldkColor = cv::Scalar(255, 0, 0);
    cv::Scalar corridorColor = cv::Scalar(255, 255, 0);
    vector<cv::Scalar> roomColors;
    roomColors.push_back(cv::Scalar(100, 200, 50));
    roomColors.push_back(cv::Scalar(82, 68, 171));
    roomColors.push_back(cv::Scalar(0, 82, 203));
    roomColors.push_back(cv::Scalar(0, 164, 190));
    roomColors.push_back(cv::Scalar(0, 135, 90));
    roomColors.push_back(cv::Scalar(255, 154, 30));
    roomColors.push_back(cv::Scalar(66, 82, 111));
    roomColors.push_back(cv::Scalar(166, 173, 186));
    roomColors.push_back(cv::Scalar(255, 143, 115));
    roomColors.push_back(cv::Scalar(192, 182, 243));
    roomColors.push_back(cv::Scalar(75, 154, 255));
    roomColors.push_back(cv::Scalar(122, 242, 192));
    roomColors.push_back(cv::Scalar(255, 0, 128));
    roomColors.push_back(cv::Scalar(128, 0, 255));
    roomColors.push_back(cv::Scalar(128, 255, 0));
    roomColors.push_back(cv::Scalar(255, 128, 0));
    roomColors.push_back(cv::Scalar(0, 128, 255));
    roomColors.push_back(cv::Scalar(0, 255, 128));
    cv::Mat colorSegment = cv::Mat(segmentMat.rows, segmentMat.cols, CV_8UC3, cv::Scalar(0));

    // uchar segmentData[(int)segmentMat.total()];
    // segmentMat.get(0, 0, segmentData);
    uchar *segmentData = segmentMat.ptr<uchar>(0, 0);
    for (int i = 0; i < segmentMat.rows; i++)
    {
        for (int j = 0; j < segmentMat.cols; j++)
        {
            uchar label = segmentData[i * segmentMat.cols + j];
            if (label == (uchar)100)
            {
                circle(colorSegment, cv::Point(j, i), 1, ldkColor, cv::FILLED);
            }
            else if (label > 0)
            {
                circle(colorSegment, cv::Point(j, i), 1, roomColors[(label - 1) % roomColors.size()], cv::FILLED);
            }
            else if (label < 0)
            {
                circle(colorSegment, cv::Point(j, i), 1, corridorColor, cv::FILLED);
            }
        }
    }
    return colorSegment;
}

Graph removeIsolatedCycle(Graph &baseGraph)
{
    vector<int> cp(num_vertices(baseGraph));
    int num = connected_components(baseGraph, &cp[0]);
    int maxSize = 0;
    int maxIdx = -1;
//    int cpSize[num] = {0};
    int cpSize[num];
    for(int i=0;i<num;i++){
        cpSize[i]=0;
    }
    for (int i = 0; i < num_vertices(baseGraph); i++)
    {
        cpSize[cp[i]]++;
    }
    for (int i = 0; i < num; i++)
    {
        if (cpSize[i] > maxSize)
        {
            maxSize = cpSize[i];
            maxIdx = i;
        }
    }
    if (maxIdx == -1)
    {
        return baseGraph;
    }
    std::unordered_set<int> maxCluster;
    for (int i = 0; i < num_vertices(baseGraph); i++)
    {
        if (cp[i] == maxIdx)
        {
            maxCluster.insert(baseGraph[i].index);
        }
    }
    Graph maxGraph = getSubGraph(baseGraph, maxCluster);
    Graph graph;
    vertex_iter v_i, v_end;
    for (tie(v_i, v_end) = vertices(maxGraph); v_i != v_end; ++v_i)
    {
        Vertex v = add_vertex(graph);
        graph[v].index = maxGraph[*v_i].index;
    }
    edge_iter e_i, e_end;
    for (tie(e_i, e_end) = edges(maxGraph); e_i != e_end; ++e_i)
    {
        Vertex s = source(*e_i, maxGraph);
        Vertex t = target(*e_i, maxGraph);
        if (!edge(s, t, graph).second)
        {
            add_edge(s, t, graph);
        }
    }
    return graph;
}

Graph removeNoneCriticalNodes(Graph &baseGraph, std::unordered_set<int> criticalNodes, vector<pair<int, int>> coords)
{
    baseGraph = removepair(baseGraph, criticalNodes);

    baseGraph = removeSingle(baseGraph, criticalNodes);

    baseGraph = removeTriplet(baseGraph, criticalNodes, coords);

    baseGraph = removepair(baseGraph, criticalNodes);

    baseGraph = removeSingle(baseGraph, criticalNodes);

    return baseGraph;
}

inline vector<Vertex> neighborList(Graph &baseGraph, Vertex nodeId)
{
    vector<Vertex> neighbors;
    adjacency_iter v_i, v_end;
    for (tie(v_i, v_end) = adjacent_vertices(nodeId, baseGraph); v_i != v_end; ++v_i)
    {
        neighbors.push_back(*v_i);
    }
    return neighbors;
}

void removeEdge(Graph &baseGraph, Vertex sourceID, Vertex targetID)
{
    Edge edgeID = edge(sourceID, targetID, baseGraph).first;
    remove_edge(edgeID, baseGraph);

    return;
}

Graph removeSingle(Graph &baseGraph, std::unordered_set<int> criticalNodes)
{
    int oldEdgeNum = 0;
    int currentEdgeNum = num_edges(baseGraph);
    int difference = oldEdgeNum - currentEdgeNum;
    while (difference != 0)
    {
        vertex_iter nodeId, v_end;
        for (tie(nodeId, v_end) = vertices(baseGraph); nodeId != v_end; ++nodeId)
        {
            if (criticalNodes.find(baseGraph[*nodeId].index) != criticalNodes.end())
            {
                continue;
            }
            int nodeDegree = out_degree(*nodeId, baseGraph);
            if (nodeDegree == 1)
            {
                vector<Vertex> neighbors = neighborList(baseGraph, *nodeId);
                removeEdge(baseGraph, *nodeId, neighbors[0]);
            }
        }
        oldEdgeNum = currentEdgeNum;
        currentEdgeNum = num_edges(baseGraph);
        difference = oldEdgeNum - currentEdgeNum;
    }
    baseGraph = removeIsolatedCycle(baseGraph);
    return baseGraph;
}

Graph removepair(Graph &baseGraph, std::unordered_set<int> criticalNodes)
{
    int oldEdgeNum = 0;
    int currentEdgeNum = num_edges(baseGraph);
    int difference = oldEdgeNum - currentEdgeNum;
    double timeneighborList = 0;
    while (difference != 0)
    {
        vertex_iter nodeId, v_end;
        for (tie(nodeId, v_end) = vertices(baseGraph); nodeId != v_end; ++nodeId)
        {
            if (criticalNodes.find(baseGraph[*nodeId].index) != criticalNodes.end())
            {
                continue;
            }
            int nodeDegree = out_degree(*nodeId, baseGraph);
            if (nodeDegree == 2)
            {
                double time1 = clock();
                vector<Vertex> neighbors = neighborList(baseGraph, *nodeId);
                double time2 = clock();
                timeneighborList += (time2 - time1);
                Edge edgeId1 = edge(*nodeId, neighbors[0], baseGraph).first;
                Edge edgeId2 = edge(*nodeId, neighbors[1], baseGraph).first;
                remove_edge(edgeId1, baseGraph);
                remove_edge(edgeId2, baseGraph);
                if (!edge(neighbors[0], neighbors[1], baseGraph).second)
                {
                    add_edge(neighbors[0], neighbors[1], baseGraph);
                }
            }
        }
        oldEdgeNum = currentEdgeNum;
        currentEdgeNum = num_edges(baseGraph);
        difference = oldEdgeNum - currentEdgeNum;
    }
    return baseGraph;
}

Vertex getMinDistNeighbor(Graph &baseGraph, int nodeId, vector<pair<int, int>> coords)
{
    vertex_iter v_i, v_end;
    std::unordered_map<int, Vertex> contains;
    for (tie(v_i, v_end) = vertices(baseGraph); v_i != v_end; ++v_i)
    {
        contains.insert({baseGraph[*v_i].index, *v_i});
    }
    vector<Vertex> neighbors = neighborList(baseGraph, contains[nodeId]);
    double minDist = 100000;
    Vertex minNode = -1;
    for (int i = 0; i < neighbors.size(); i++)
    {
        double dist = getL2Dist(coords[nodeId], coords[baseGraph[neighbors[i]].index]);
        if (dist < minDist)
        {
            minDist = dist;
            minNode = neighbors[i];
        }
    }
    return minNode;
}

Graph copySimpleGraph(Graph &simpleGraph)
{
    Graph graph;
    vertex_iter v_i, v_end;
    for (tie(v_i, v_end) = vertices(simpleGraph); v_i != v_end; ++v_i)
    {
        Vertex v = add_vertex(graph);
        graph[v].index = simpleGraph[*v_i].index;
    }
    edge_iter e_i, e_end;
    for (tie(e_i, e_end) = edges(simpleGraph); e_i != e_end; ++e_i)
    {
        Vertex s = source(*e_i, simpleGraph);
        Vertex t = target(*e_i, simpleGraph);
        if (!edge(s, t, graph).second)
        {
            add_edge(s, t, graph);
        }
    }
    return graph;
}

Graph removeTriplet(Graph &baseGraph, std::unordered_set<int> criticalNodes, vector<pair<int, int>> coords)
{
    int oldEdgeNum = 0;
    int currentEdgeNum = num_edges(baseGraph);
    int difference = oldEdgeNum - currentEdgeNum;
    while (difference != 0)
    {
        vertex_iter nodeId, v_end;
        for (tie(nodeId, v_end) = vertices(baseGraph); nodeId != v_end; ++nodeId)
        {
            if (criticalNodes.find(baseGraph[*nodeId].index) != criticalNodes.end())
            {
                continue;
            }
            int nodeDegree = out_degree(*nodeId, baseGraph);
            if (nodeDegree > 2)
            {
                vector<Vertex> neighbors = neighborList(baseGraph, *nodeId);
                Vertex minDistNeighborId = getMinDistNeighbor(baseGraph, baseGraph[*nodeId].index, coords);

                for (int i = 0; i < neighbors.size(); i++)
                {
                    removeEdge(baseGraph, *nodeId, neighbors[i]);
                    if (neighbors[i] != minDistNeighborId)
                    {
                        if (!edge(minDistNeighborId, neighbors[i], baseGraph).second)
                        {
                            add_edge(minDistNeighborId, neighbors[i], baseGraph);
                        }
                    }
                }
            }
        }
        oldEdgeNum = currentEdgeNum;
        currentEdgeNum = num_edges(baseGraph);
        difference = oldEdgeNum - currentEdgeNum;
    }
    return baseGraph;
}

cv::Mat roomMergeDebug(cv::Mat floormask, vector<std::unordered_set<int>> ldkList, vector<std::unordered_set<int>> corridorList, vector<std::unordered_set<int>> roomList, std::unordered_set<int> whiteNodes, vector<pair<int, int>> coords)
{
    cv::Mat mask = floormask.clone();
    // uchar maskData[(int)mask.total()];
    uchar *maskData = mask.ptr<uchar>(0, 0);
    // mask.get(0, 0, maskData);
    for (int i = 0; i < mask.total(); i++)
    {
        if (maskData[i] != 0)
        {
            maskData[i] = 100;
        }
    }
    // mask.put(0, 0, maskData);

    cv::Mat debugMat = cv::Mat();
    cvtColor(mask, debugMat, cv::COLOR_GRAY2BGR);

    cv::Scalar ldkColor = cv::Scalar(255, 0, 0);
    cv::Scalar corridorColor = cv::Scalar(255, 255, 0);
    vector<cv::Scalar> roomColors;
    roomColors.push_back(cv::Scalar(222, 255, 12));
    roomColors.push_back(cv::Scalar(82, 68, 171));
    roomColors.push_back(cv::Scalar(0, 82, 203));
    roomColors.push_back(cv::Scalar(0, 164, 190));
    roomColors.push_back(cv::Scalar(0, 135, 90));
    roomColors.push_back(cv::Scalar(255, 154, 30));
    roomColors.push_back(cv::Scalar(66, 82, 111));
    roomColors.push_back(cv::Scalar(166, 173, 186));
    roomColors.push_back(cv::Scalar(255, 143, 115));
    roomColors.push_back(cv::Scalar(192, 182, 243));
    roomColors.push_back(cv::Scalar(75, 154, 255));
    roomColors.push_back(cv::Scalar(122, 242, 192));

    for (int i = 0; i < ldkList.size(); i++)
    {
        std::unordered_set<int> roomSet = ldkList[i];
        for (const auto &nodeId : roomSet)
        {
            cv::Point pt = cv::Point(coords[nodeId].first, coords[nodeId].second);
            circle(debugMat, pt, 1, ldkColor, cv::FILLED);
        }
    }

    for (int i = 0; i < corridorList.size(); i++)
    {
        std::unordered_set<int> roomSet = corridorList[i];
        for (const auto &nodeId : roomSet)
        {
            cv::Point pt = cv::Point(coords[nodeId].first, coords[nodeId].second);
            circle(debugMat, pt, 1, corridorColor, cv::FILLED);
        }
    }

    for (int i = 0; i < roomList.size(); i++)
    {
        std::unordered_set<int> roomSet = roomList[i];
        for (const auto &nodeId : roomSet)
        {
            cv::Point pt = cv::Point(coords[nodeId].first, coords[nodeId].second);
            circle(debugMat, pt, 1, roomColors[i % roomColors.size()], cv::FILLED);
        }
    }
    for (const auto &nodeId : whiteNodes)
    {
        cv::Point pt = cv::Point(coords[nodeId].first, coords[nodeId].second);
        circle(debugMat, pt, 1, cv::Scalar(255, 255, 255), cv::FILLED);
    }
    return debugMat;
}

std::unordered_set<int> getShortestPath(Graph &baseGraph, Graph &searchGraph)
{
    std::unordered_set<int> nodeSet;

    edge_iter nodeId, e_end;

    for (tie(nodeId, e_end) = edges(searchGraph); nodeId != e_end; ++nodeId)
    {
        Vertex s = source(*nodeId, searchGraph);
        Vertex t = target(*nodeId, searchGraph);
        // vector<Vertex> parent(num_vertices(baseGraph));
        // vector<int> distance(num_vertices(baseGraph));
        // dijkstra_shortest_paths(baseGraph,searchGraph[s].index,
        //                         predecessor_map(make_iterator_property_map(parent.begin(),get(vertex_index,baseGraph))).
        //                         distance_map(make_iterator_property_map(distance.begin(),get(vertex_index,baseGraph))).
        //                         weight_map(make_constant_property<Edge>(1.0))
        //                         );
        Vertex *parent = new Vertex[num_vertices(baseGraph)];
        breadth_first_search(baseGraph, searchGraph[s].index,
                             visitor(make_bfs_visitor(record_predecessors(parent, on_tree_edge()))).vertex_index_map(identity_property_map()));
        Vertex current = searchGraph[t].index;
        Vertex parentTemp = parent[current];
        vertex_iter v_i, v_end;
        bool inGraph = false;
        for (tie(v_i, v_end) = vertices(baseGraph); v_i != v_end; ++v_i)
        {
            if (*v_i == parentTemp)
            {
                inGraph = true;
                break;
            }
        }
        if (inGraph)
        {
            while (current != searchGraph[s].index)
            {
                nodeSet.insert(baseGraph[current].index);
                current = parent[current];
            }
        }
        delete [] parent;
    }

    return nodeSet;
}

std::unordered_set<int> getNeighbor3(Graph &baseGraph, cv::Mat distMat, vector<pair<int, int>> coords)
{
    // float[] dists = float[1];
    float distTh = 10;
    std::unordered_set<int> resultNodes;
    vertex_iter nodeId, v_end;
    for (tie(nodeId, v_end) = vertices(baseGraph); nodeId != v_end; ++nodeId)
    {
        int nodeDegree = out_degree(*nodeId, baseGraph);
        if (nodeDegree > 2)
        {
            int x = coords[baseGraph[*nodeId].index].first;
            int y = coords[baseGraph[*nodeId].index].second;
            // distMat.get(y, x, dists);
            float *dists = distMat.ptr<float>(y, x);
            if (dists[0] > distTh)
            {
                resultNodes.insert(baseGraph[*nodeId].index);
            }
        }
    }
    return resultNodes;
}

std::unordered_set<int> correctNodeSet(Graph &graph, std::unordered_set<int> nodeSet, cv::Mat distMat, vector<pair<int, int>> coords)
{
    std::unordered_set<int> neighbor3NodeSet = getNeighbor3(graph, distMat, coords);
    std::unordered_set<int> resultSet;
    resultSet.insert(nodeSet.begin(), nodeSet.end());

    if (nodeSet.size() == 0)
    {
        return nodeSet;
    }

    int sourceId = *nodeSet.begin();

    Vertex s = sourceId;
    // vector<Vertex> parent(num_vertices(graph));
    // vector<int> distance(num_vertices(graph));
    // dijkstra_shortest_paths(graph,s,
    //                         predecessor_map(make_iterator_property_map(parent.begin(),get(vertex_index,graph))).
    //                         distance_map(make_iterator_property_map(distance.begin(),get(vertex_index,graph))).
    //                         weight_map(make_constant_property<Edge>(1.0))
    //                         );
    Vertex *parent = new Vertex[num_vertices(graph)];
    breadth_first_search(graph, s,
                         visitor(make_bfs_visitor(record_predecessors(parent, on_tree_edge()))).vertex_index_map(identity_property_map()));
    for (const auto &nodeId : neighbor3NodeSet)
    {
        Vertex t = nodeId;
        Vertex current = t;
        Vertex parentTemp = parent[current];
        vertex_iter v_i, v_end;
        bool inGraph = false;
        for (tie(v_i, v_end) = vertices(graph); v_i != v_end; ++v_i)
        {
            if (*v_i == parentTemp)
            {
                inGraph = true;
                break;
            }
        }
        if (inGraph)
        {
            while (current != s)
            {
                resultSet.insert(graph[current].index);
                current = parent[current];
            }
        }
    }
    delete [] parent;
    return resultSet;
}

pair<std::unordered_set<int>, std::tuple<vector<std::unordered_set<int>>, vector<std::unordered_set<int>>, vector<std::unordered_set<int>>>> convertSegmentToGraph(cv::Mat maskrcnnMat, std::unordered_set<int> nodeSet, vector<pair<int, int>> coords)
{

    cout<<"nodeSet.size(): "<<nodeSet.size()<<endl;
    cout<<"coords.size(): "<<coords.size()<<endl;
    std::unordered_set<int> ldkNodes;
    std::unordered_set<int> whiteNodes;
    vector<std::unordered_set<int>> roomNodes;
    vector<std::unordered_set<int>> corridorNodes;

    // uchar segmentData[(int)maskrcnnMat.total()];
    uchar *segmentData = maskrcnnMat.ptr<uchar>(0, 0);
    // maskrcnnMat.get(0, 0, segmentData);

    std::unordered_map<uchar, std::unordered_set<int>> roomLabels;
    std::unordered_map<uchar, std::unordered_set<int>> corridorLabels;

    uchar LDK_LABEL = (uchar)100;
    int width = maskrcnnMat.cols;
    for (const auto &nodeId : nodeSet)
    {
        int x = coords[nodeId].first;
        int y = coords[nodeId].second;
        uchar label = segmentData[y * width + x];
        
        if (label == LDK_LABEL)
        {
            ldkNodes.insert(nodeId);
        }
        else if (label == (uchar)0)
        {
            whiteNodes.insert(nodeId);
        }
        else if (label < (uchar)100)
        {
            if (roomLabels.find(label) != roomLabels.end())
            {
                roomLabels[label].insert(nodeId);
            }
            else
            {
                std::unordered_set<int> roomSet;
                roomSet.insert(nodeId);
                roomLabels.insert({label, roomSet});
            }
        }
        else if (label >= (uchar)200)
        {
            if (corridorLabels.find(label) != corridorLabels.end())
            {
                corridorLabels[label].insert(nodeId);
            }
            else
            {
                std::unordered_set<int> corridorSet;
                corridorSet.insert(nodeId);
                corridorLabels.insert({label, corridorSet});
            }
        }
    }

    for (const auto &pair : roomLabels)
    {
        roomNodes.push_back(pair.second);
    }

    for (const auto &pair : corridorLabels)
    {
        corridorNodes.push_back(pair.second);
    }
    vector<std::unordered_set<int>> ldkList;
    ldkList.push_back(ldkNodes);
    return pair<std::unordered_set<int>, std::tuple<vector<std::unordered_set<int>>, vector<std::unordered_set<int>>, vector<std::unordered_set<int>>>>(whiteNodes, std::tuple<vector<std::unordered_set<int>>, vector<std::unordered_set<int>>, vector<std::unordered_set<int>>>(ldkList, roomNodes, corridorNodes));
}

Graph getSubGraph(Graph &baseGraph, std::unordered_set<int> nodeSet)
{
    vertex_iter v_i, v_end;
    std::unordered_map<int, Vertex> basecontains;
    for (tie(v_i, v_end) = vertices(baseGraph); v_i != v_end; ++v_i)
    {
        basecontains.insert({baseGraph[*v_i].index, *v_i});
    }
    std::unordered_map<int, Vertex> contains;
    Graph subGraph;
    Vertex v1 = -1, v2 = -1;

    for (const int nodeId : nodeSet)
    {
        if (contains.find(nodeId) == contains.end())
        {
            v1 = add_vertex(subGraph);
            subGraph[v1].index = nodeId;
            contains.insert(pair<int, Vertex>(nodeId, v1));
        }
        else
        {
            v1 = contains[nodeId];
        }

        vector<Vertex> neighbors = neighborList(baseGraph, basecontains[nodeId]);
        for (const Vertex neighborNode : neighbors)
        {
            if (nodeSet.find(baseGraph[neighborNode].index) != nodeSet.end())
            {
                if (contains.find(baseGraph[neighborNode].index) == contains.end())
                {
                    v2 = add_vertex(subGraph);
                    subGraph[v2].index = baseGraph[neighborNode].index;
                    contains.insert(pair<int, Vertex>(baseGraph[neighborNode].index, v2));
                }
                else
                {
                    v2 = contains[baseGraph[neighborNode].index];
                }
                if (!edge(v1, v2, subGraph).second)
                {
                    add_edge(v1, v2, subGraph);
                }
            }
        }
    }
    return subGraph;
}

pair<std::unordered_set<int>, std::tuple<vector<std::unordered_set<int>>, vector<std::unordered_set<int>>, vector<std::unordered_set<int>>>> fixConnectivity(double scaleBoost, int height, int width, Graph &baseGraph,
                                                                                                                                                             vector<std::unordered_set<int>> ldkNodes, vector<std::unordered_set<int>> roomNodes, vector<std::unordered_set<int>> corridorNodes, std::unordered_set<int> whiteNodes, vector<pair<int, int>> coords)
{
    int LDK_AREA_TH = 45;
    int ROOM_AREA_TH = 10;
    ldkNodes = filterSmallAreaAndMerge(LDK_AREA_TH, baseGraph, ldkNodes, whiteNodes);
    roomNodes = filterSmallAreaAndMerge(ROOM_AREA_TH, baseGraph, roomNodes, whiteNodes);
    corridorNodes = filterSmallAreaAndMerge(ROOM_AREA_TH, baseGraph, corridorNodes, whiteNodes);
    return pair<std::unordered_set<int>, std::tuple<vector<std::unordered_set<int>>, vector<std::unordered_set<int>>, vector<std::unordered_set<int>>>>(std::unordered_set<int>(), std::tuple<vector<std::unordered_set<int>>, vector<std::unordered_set<int>>, vector<std::unordered_set<int>>>(ldkNodes, roomNodes, corridorNodes));
}

vector<std::unordered_set<int>> filterSmallAreaAndMerge(int roomNodeTh, Graph &baseGraph, vector<std::unordered_set<int>> roomList,
                                                        std::unordered_set<int> whiteNodes)
{
    vertex_iter v_i, v_end;
    std::unordered_map<int, Vertex> contains;
    for (tie(v_i, v_end) = vertices(baseGraph); v_i != v_end; ++v_i)
    {
        contains.insert({baseGraph[*v_i].index, *v_i});
    }

    vector<std::unordered_set<int>> roomRefineList;
    for (int i = 0; i < roomList.size(); i++)
    {
        std::unordered_set<int> roomSet = roomList[i];
        if (roomSet.size() < roomNodeTh)
        {
            continue;
        }
        Graph subGraph = getSubGraph(baseGraph, roomSet);
        vector<int> cp(num_vertices(subGraph));
        int num = connected_components(subGraph, &cp[0]);
        vector<std::unordered_set<int>> roomCluster;
        vector<std::unordered_set<int>> tempCluster(num);

        vertex_iter nodeId, v_end;
        for (tie(nodeId, v_end) = vertices(subGraph); nodeId != v_end; ++nodeId)
        {
            tempCluster[cp[*nodeId]].insert(subGraph[*nodeId].index);
        }

        for (int k = 0; k < num; k++)
        {
            if (tempCluster[k].size() > roomNodeTh)
            {
                roomCluster.push_back(tempCluster[k]);
            }
            else
            {
                whiteNodes.insert(tempCluster[k].begin(), tempCluster[k].end());
            }
        }
        std::unordered_set<int> roomMergeSet;
        if (roomCluster.size() == 1)
        {
            roomMergeSet.insert(roomCluster[0].begin(), roomCluster[0].end());
        }
        else if (roomCluster.size() > 1)
        {
            sort(roomCluster.begin(), roomCluster.end(), [](std::unordered_set<int> set1, std::unordered_set<int> set2)
                 { return set1.size() > set2.size(); });
            roomMergeSet.insert(roomCluster[0].begin(), roomCluster[0].end());

            int startNode = (int)*roomCluster[0].begin();
            for (int k = 1; k < roomCluster.size(); k++)
            {
                int endNode = (int)*roomCluster[k].begin();
                std::unordered_set<int> pathSet;

                // vector<Vertex> parent(num_vertices(baseGraph));
                // vector<int> distance(num_vertices(baseGraph));
                // dijkstra_shortest_paths(baseGraph,startNode,
                //                         predecessor_map(make_iterator_property_map(parent.begin(),get(vertex_index,baseGraph))).
                //                         distance_map(make_iterator_property_map(distance.begin(),get(vertex_index,baseGraph))).
                //                         weight_map(make_constant_property<Edge>(1.0))
                //                         );
                Vertex *parent = new Vertex[num_vertices(baseGraph)];
                breadth_first_search(baseGraph, contains[startNode],
                                     visitor(make_bfs_visitor(record_predecessors(parent, on_tree_edge()))).vertex_index_map(identity_property_map()));
                Vertex current = contains[endNode];
                Vertex parentTemp = parent[current];
                vertex_iter v_i, v_end;
                bool inGraph = false;
                for (tie(v_i, v_end) = vertices(baseGraph); v_i != v_end; ++v_i)
                {
                    if (*v_i == parentTemp)
                    {
                        inGraph = true;
                        break;
                    }
                }
                if (inGraph)
                {
                    while (current != contains[startNode])
                    {
                        pathSet.insert(baseGraph[current].index);
                        current = parent[current];
                    }
                }
                delete [] parent;

                std::unordered_set<int> tentativeMergeRoomSet;
                tentativeMergeRoomSet.insert(roomMergeSet.begin(), roomMergeSet.end());
                tentativeMergeRoomSet.insert(roomCluster[k].begin(), roomCluster[k].end());
                std::unordered_set<int> whiteAndMergeSet;
                whiteAndMergeSet.insert(tentativeMergeRoomSet.begin(), tentativeMergeRoomSet.end());
                whiteAndMergeSet.insert(whiteNodes.begin(), whiteNodes.end());
                // if (whiteAndMergeSet.containsAll(pathSet))
                if (includes(whiteAndMergeSet.begin(), whiteAndMergeSet.end(), pathSet.begin(), pathSet.end()))
                {
                    roomMergeSet.insert(pathSet.begin(), pathSet.end());
                    roomMergeSet.insert(roomCluster[k].begin(), roomCluster[k].end());
                    for (const auto &removed : pathSet)
                    {
                        whiteNodes.erase(removed);
                    }
                }
                else
                {
                    whiteNodes.insert(roomCluster[k].begin(), roomCluster[k].end());
                }
            }
        }
        if (roomMergeSet.size() > 0)
        {
            roomRefineList.push_back(roomMergeSet);
        }
    }
    return roomRefineList;
}

vector<DoorLine> getCriticalLine(vector<vector<cv::Point>> contours, vector<int> doorList, vector<pair<int, int>> coords, std::unordered_map<int, float> distMap)
{
    vector<DoorLine> lineList;
    double angleTh = -0.766;
    vector<cv::Point> contoursList;
    for (int i = 0; i < contours.size(); i++)
    {
        contoursList.insert(contoursList.end(), contours[i].begin(), contours[i].end());
    }
    for (int p = 0; p < doorList.size(); p++)
    {
        int doorNode = doorList[p];
        int i = coords[doorList[p]].second;
        int j = coords[doorList[p]].first;
        float distTh = distMap[doorNode];
        // vector<cv::Point> filterList = contoursList.stream().filter(cv::Point->getL2Dist(j, i, cv::Point) < distTh * 2.4).collect(Collectors.toList());
        vector<cv::Point> filterList;
        // copy_if(contoursList.begin(), contoursList.end(), back_inserter(filterList), [j, i, distTh](cv::Point p)
        //         { return getL2Dist(p, cv::Point(j, i)) < distTh * 2.4; });
        for (int a = 0; a < contoursList.size(); a++)
        {
            if (getL2Dist(j, i, contoursList[a]) < distTh * 2.4)
            {
                filterList.push_back(contoursList[a]);
            }
        }
        double minDist = 100000;
        int pointIdx1 = 0;
        int pointIdx2 = 0;
        double minAlignDist = 100000;
        int pointAlignIdx1 = 0;
        int pointAlignIdx2 = 0;
        for (int m = 0; m < filterList.size(); m++)
        {
            cv::Point point1 = filterList[m];
            for (int n = m + 1; n < filterList.size(); n++)
            {
                cv::Point point2 = filterList[n];
                double cosVal = getCosin(point1.x - j, point1.y - i, point2.x - j, point2.y - i);
                double distVal = getL2Dist(point1, point2);
                if (cosVal < angleTh)
                {
                    if (distVal < minDist)
                    {
                        minDist = distVal;
                        pointIdx1 = m;
                        pointIdx2 = n;
                    }
                    double alignCos = fabs(getCosin(1, 0, point2.x - point1.x, point2.y - point1.y));
                    if ((alignCos < 0.01 || alignCos > 0.99) && distVal < minAlignDist)
                    {
                        minAlignDist = distVal;
                        pointAlignIdx1 = m;
                        pointAlignIdx2 = n;
                    }
                }
            }
        }
        if (minAlignDist < 1.65 * minDist)
        {
            lineList.push_back(DoorLine(minAlignDist, 0, pair<int, int>((int)filterList[pointAlignIdx1].x, (int)filterList[pointAlignIdx1].y), pair<int, int>((int)filterList[pointAlignIdx2].x, (int)filterList[pointAlignIdx2].y), doorList[p]));
        }
        else
        {
            lineList.push_back(DoorLine(minDist, 0, pair<int, int>((int)filterList[pointIdx1].x, (int)filterList[pointIdx1].y), pair<int, int>((int)filterList[pointIdx2].x, (int)filterList[pointIdx2].y), doorList[p]));
        }
    }

    return lineList;
}

std::unordered_map<int, float> convertToDistMap(cv::Mat distMat, std::unordered_set<int> nodeSet, vector<pair<int, int>> coords)
{
    // float[] distData = float[(int)distMat.total()];
    float *distData = distMat.ptr<float>(0, 0);
    // distMat.get(0, 0, distData);

    std::unordered_map<int, float> distMap;
    int width = distMat.cols;
    for (const auto &nodeId : nodeSet)
    {
        int x = coords[nodeId].first;
        int y = coords[nodeId].second;
        distMap.insert({nodeId, distData[y * width + x]});
    }

    return distMap;
}

void getDoorPostionDebug(cv::Mat debugMat, std::vector<DoorLine> doors, std::vector<DoorLine> corridorDoors, std::vector<DoorLine> corridorCorridorDoors)
{
    for (auto door : doors)
    {
        line(debugMat, cv::Point(door.getStartNodeCoord().first, door.getStartNodeCoord().second), cv::Point(door.getEndNodeCoord().first, door.getEndNodeCoord().second), cv::Scalar(255, 0, 0), 5);
    }

    for (auto corridorDoor : corridorDoors)
    {
        line(debugMat, cv::Point(corridorDoor.getStartNodeCoord().first, corridorDoor.getStartNodeCoord().second), cv::Point(corridorDoor.getEndNodeCoord().first, corridorDoor.getEndNodeCoord().second), cv::Scalar(255, 255, 0), 5);
    }

    for (auto corridorCorridorDoor : corridorCorridorDoors)
    {
        line(debugMat, cv::Point(corridorCorridorDoor.getStartNodeCoord().first, corridorCorridorDoor.getStartNodeCoord().second), cv::Point(corridorCorridorDoor.getEndNodeCoord().first, corridorCorridorDoor.getEndNodeCoord().second), cv::Scalar(0, 255, 0), 5);
    }
}
