#include"voronoi/NativeUtils.h"
using namespace std;
using namespace cv;
    
    Mat getMinDistMaskByP2(vector<vector<cv::Point>> contours, Mat skeleton) {

        int height = skeleton.rows;
        int width = skeleton.cols;
        Mat distMat = Mat(height, width, CV_32FC1, Scalar(0));
        int contourLength[contours.size()];

        int totalPoints = 0;
        for (int i = 0; i < contours.size(); i++) {
            vector<Point> contourPoints = contours[i];
            contourLength[i] = contourPoints.size();
            totalPoints += contourPoints.size();
        }
        vector<int> contourCoords(totalPoints * 2);
        int k = 0;
        for (int i = 0; i < contours.size(); i++) {
            vector<Point> contourPoints = contours[i];
            contourLength[i] = contourPoints.size();
            for (int j = 0; j < contourPoints.size(); j++) {
                contourCoords[k * 2] = (int) contourPoints[j].x;
                contourCoords[k * 2 + 1] = (int) contourPoints[j].y;
                k++;
            }
        }

        distMat.data = getMinDistNative(contourCoords, width, height, skeleton.data, distMat.data);

        return distMat;

    }

    tuple<Graph, vector<pair<int, int>>, unordered_map<int, int>> skeletonAnalysis(Mat skeleton) {

        tuple<vector<int>,vector<int>,unordered_map<int,int>> result = nativeSkeletonAnalysis(skeleton.data, skeleton.cols, skeleton.rows);
        vector<int> coords=get<0>(result);
        vector<int> edges=get<1>(result);
        unordered_map<int, int> idxMap=get<2>(result);
        //SimpleGraph<int, DefaultEdge> prunedGraph = SimpleGraph<>(DefaultEdge.class);
        Graph prunedGraph;
        for (int i = 0; i < coords.size(); i++) {
            Vertex v =add_vertex(prunedGraph);
            prunedGraph[v].index=i;
        }
        for (int i = 0; i < edges.size() / 2; i++) {
            if (!edge(edges[i * 2], edges[i * 2 + 1],prunedGraph).second) {
                add_edge(edges[i * 2], edges[i * 2 + 1],prunedGraph);
            }
        }
        vector<pair<int, int>> imageCoords;
        for (int i = 0; i < coords.size(); i++) {
            int y = coords[i] / skeleton.cols;
            int x = coords[i] % skeleton.cols;
            imageCoords.push_back(pair<int,int>(x, y));
        }

        return tuple<Graph, vector<pair<int, int>>, unordered_map<int, int>>(prunedGraph, imageCoords, idxMap);

    }

    tuple<vector<DoorLine>, vector<DoorLine>, vector<DoorLine>> getDoorPos(Mat mergeDebugMat, 
                                                                vector<vector<cv::Point>> floorContours, 
                                                                vector<unordered_set<int>> ldkvector, 
                                                                vector<unordered_set<int>> roomvector,
                                                                vector<unordered_set<int>> corridorvector, 
                                                                unordered_set<int> whiteNodes, 
                                                                Graph graph, 
                                                                unordered_map<int, float> distMap,
                                                                unordered_set<int> newRoomIdset, 
                                                                vector<pair<int, int>> coords) {

        vector<int> floorContourvector;
        for (int i = 0; i < floorContours.size(); i++) {
            vector<cv::Point> contourPoints = floorContours[i];
            for (int j = 0; j < contourPoints.size(); j++) {
                floorContourvector.push_back((int) contourPoints[j].x);
                floorContourvector.push_back((int) contourPoints[j].y);
            }
        }

        vector<int> ldkLength;
        vector<int> ldkFlatvector;
        for (int i = 0; i < ldkvector.size(); i++) {
            ldkLength.push_back(ldkvector[i].size());
            copy(ldkvector[i].begin(),ldkvector[i].end(),back_inserter(ldkFlatvector));
        }

        vector<int> roomLength;
        vector<int> roomFlatvector;
        for (int i = 0; i < roomvector.size(); i++) {
            roomLength.push_back(roomvector[i].size());
            copy(roomvector[i].begin(),roomvector[i].end(),back_inserter(roomFlatvector));
        }

        vector<int> corridorLength;
        vector<int> corridorFlatvector;
        for (int i = 0; i < corridorvector.size(); i++) {
            corridorLength.push_back(corridorvector[i].size());
            copy(corridorvector[i].begin(),corridorvector[i].end(),back_inserter(corridorFlatvector));
        }

        vector<int> whiteNodesvector;
        copy(whiteNodes.begin(),whiteNodes.end(),back_inserter(whiteNodesvector));

        vector<int> edgesvector;
        edge_iter e_i,e_end;
        for (tie(e_i,e_end)=edges(graph);e_i!=e_end;++e_i) {
            edgesvector.push_back(graph[source(*e_i,graph)].index);
            edgesvector.push_back(graph[target(*e_i,graph)].index);
        }

        vector<int> flatDistMap;
        for (const auto& pairMap: distMap) {
            flatDistMap.push_back(pairMap.first);
            flatDistMap.push_back((int) pairMap.second);
        }

        vector<int> newRoomIdvector;
        copy(newRoomIdset.begin(),newRoomIdset.end(),back_inserter(newRoomIdvector));

        vector<int> flatCoords;
        for (int i = 0; i < coords.size(); i++) {
            flatCoords.push_back(coords[i].first);
            flatCoords.push_back(coords[i].second);
        }
        
        int vertextNum=coords.size();
        tuple<vector<int>,vector<int>,vector<int>>result = nativeGetDoorPos(floorContourvector, ldkLength, ldkFlatvector, roomLength, roomFlatvector,
                corridorLength, corridorFlatvector, whiteNodesvector, vertextNum, edgesvector, flatDistMap, flatCoords, newRoomIdvector);


        vector<int> doors=get<0>(result);
        vector<int> corridors=get<1>(result);
        vector<int> corridorCorridors=get<2>(result);
        vector<DoorLine> doorLines=getCriticalLine(floorContours, doors, coords, distMap);
        vector<DoorLine> corridorLines=getCriticalLine(floorContours, corridors, coords, distMap);
        vector<DoorLine> corridorCorridorLines=getCriticalLine(floorContours, corridorCorridors, coords, distMap);

        return tuple<vector<DoorLine>, vector<DoorLine>, vector<DoorLine>>(doorLines, corridorLines, corridorCorridorLines);

    }