    #include "voronoi/TopologicalSegmentation.h"
    #include "time.h"
    using namespace std;
    using namespace boost;
    using namespace cv;
    
    void TopologicalSegmentation::initSegmentModel(string modelName) {
        segmentor.loadModel(modelName, SegmentOnnx::ModelType::RTMDET_INS, 114);
    }

    // void initSegmentModel(Context context, string modelName) {
    //     segmentor.loadModel(context, modelName, SegmentOnnx.ModelType.RTMDET_INS, 114);
    // }

    // void initSegmentModel(AssetManager assetManager, string modelName) {
    //     segmentor.loadModel(assetManager, modelName, SegmentOnnx.ModelType.RTMDET_INS, 114);
    // }

    // void deinitSegmentModel() {
    //     segmentor.release();
    // }

    // void setMapData(MapData mapData) {
    //     this.mapData = mapData;
    // }

    SegmentInfo TopologicalSegmentation::applySegmentation(Mat binaryMask) {
        return applySegmentation(NULL, binaryMask);
    }

    SegmentInfo TopologicalSegmentation::applySegmentation(string modelName, Mat originMat) {
        double time1=clock();
        
        int height = originMat.rows;
        int width = originMat.cols;
        
        string model = "rtmdet_int8.ort";
        string modelNameCopy = modelName;
        string tmppath = modelNameCopy.erase(modelNameCopy.length()-model.length());
        
        imwrite(tmppath+"originMat_ios_0506.png", originMat);
        Mat smoothMask = artifactFilter.run(originMat, true);
        imwrite(tmppath+"smoothMask_ios_0506.png", smoothMask);
        double time2=clock();
        cout<<"artifactFilter:"<<(time2-time1)/CLOCKS_PER_SEC<<endl;

        Mat skeletonMat = Mat();
        ximgproc::thinning(binary2Show(smoothMask), skeletonMat);
        double time3=clock();
        cout<<"thinning:"<<(time3-time2)/CLOCKS_PER_SEC<<endl;

        pair<vector<vector<cv::Point>>, Mat> contourInfo = getContourTree(smoothMask);
        double time4=clock();
        cout<<"getContourTree:"<<(time4-time3)/CLOCKS_PER_SEC<<endl;


        vector<vector<cv::Point>> contourvector = contourInfo.first;
        Mat distMat = getMinDistMaskByP2(contourvector, skeletonMat);
        
        
        vector<pair<int, int>> peakPoints = peakLocalMax(smoothMask, distMat, 30, 10);
        double time5=clock();
        cout<<"getMinDistMaskByP2:"<<(time5-time4)/CLOCKS_PER_SEC<<endl;


        std::tuple<Graph, vector<pair<int, int>>, std::unordered_map<int, int>> analysisResult = skeletonAnalysis(skeletonMat);
        double time6=clock();
        cout<<"skeletonAnalysis:"<<(time6-time5)/CLOCKS_PER_SEC<<endl;


        Graph baseGraph = get<0>(analysisResult);
        vector<pair<int, int>> coords = get<1>(analysisResult);
        std::unordered_map<int, int> indexMap = get<2>(analysisResult);
        std::unordered_set<int> peakNodeSet;
        for (int i = 0; i < peakPoints.size(); i++) {
            pair<int, int> pt = peakPoints[i];
            int pointId = indexMap[pt.second * width + pt.first]; 
            peakNodeSet.insert(pointId);
        }
        Graph doorGraph = copySimpleGraph(baseGraph);
        double time7=clock();
        cout<<"copySimpleGraph:"<<(time7-time6)/CLOCKS_PER_SEC<<endl;


        Graph graph = removeNoneCriticalNodes(doorGraph, peakNodeSet, coords);
        double time8=clock();
        cout<<"removeNoneCriticalNodes:"<<(time8-time7)/CLOCKS_PER_SEC<<endl;


        std::unordered_set<int> nodeSet = getShortestPath(baseGraph, graph);
        nodeSet = correctNodeSet(baseGraph, nodeSet, distMat, coords);
        Mat segmentInput = binary2Show(smoothMask);
        // cvtColor(segmentInput, segmentInput, COLOR_GRAY2BGR);
        double time9=clock();
        cout<<"getShortestPath:"<<(time9-time8)/CLOCKS_PER_SEC<<endl;
        
        cout<<"modelName111:"<<modelName<<endl;
        imwrite(modelName+"segmentInput.png",segmentInput);
        Mat segmentMat = segmentor.forward(segmentInput, modelName, SegmentOnnx::ModelType::RTMDET_INS);
        imwrite(modelName+"segmentMat_ios.png",segmentMat);
        double time10=clock();
        cout<<"segmentor:"<<(time10-time9)/CLOCKS_PER_SEC<<endl;

        pair<std::unordered_set<int>, std::tuple<vector<std::unordered_set<int>>, vector<std::unordered_set<int>>, vector<std::unordered_set<int>>>> nodeInfo = convertSegmentToGraph(segmentMat, nodeSet, coords);
        vector<std::unordered_set<int>> ldkvector = get<0>(nodeInfo.second);
        vector<std::unordered_set<int>> roomvector = get<1>(nodeInfo.second);
        vector<std::unordered_set<int>> corridorvector = get<2>(nodeInfo.second);
        std::unordered_set<int> whiteNodes = nodeInfo.first;
        double time11=clock();
        cout<<"convertSegmentToGraph:"<<(time11-time10)/CLOCKS_PER_SEC<<endl;


        Graph pruneGraph = getSubGraph(baseGraph, nodeSet);
        pair<std::unordered_set<int>, std::tuple<vector<std::unordered_set<int>>, vector<std::unordered_set<int>>, vector<std::unordered_set<int>>>> fixInfo = fixConnectivity(3.0, height, width, pruneGraph, ldkvector, roomvector, corridorvector, whiteNodes, coords);
        std::unordered_set<int> newRoomIdSet = fixInfo.first;
        ldkvector = get<0>(fixInfo.second);
        roomvector = get<1>(fixInfo.second);
        corridorvector = get<2>(fixInfo.second);
        Mat mergeDebugMat = roomMergeDebug(smoothMask, ldkvector, corridorvector, roomvector, whiteNodes, coords);
        imwrite(modelName+"mergeDebugMat0_ios.png",mergeDebugMat);
        
        std::unordered_map<int, float> distMap = convertToDistMap(distMat, nodeSet, coords);
        double time12=clock();
        cout<<"fixConnectivity:"<<(time12-time11)/CLOCKS_PER_SEC<<endl;


        std::tuple<std::vector<DoorLine>, std::vector<DoorLine>, std::vector<DoorLine>> allDoors = getDoorPos(mergeDebugMat, contourvector, ldkvector, roomvector, corridorvector, whiteNodes, pruneGraph, distMap, newRoomIdSet, coords);
        getDoorPostionDebug(mergeDebugMat, get<0>(allDoors), get<1>(allDoors), get<2>(allDoors));
        imwrite(modelName+"mergeDebugMat1_ios.png",mergeDebugMat);
        SegmentInfo si = SegmentInfo(get<0>(allDoors), get<1>(allDoors), get<2>(allDoors), smoothMask, segmentMat, height*width/400);
        double time13=clock();
        cout<<"getDoorPos:"<<(time13-time12)/CLOCKS_PER_SEC<<endl;

        return si;
    }
