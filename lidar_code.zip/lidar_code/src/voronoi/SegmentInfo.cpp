#include"voronoi/SegmentInfo.h"
#include"voronoi/Util.h"
#include"geom/Utils.h"

using namespace std;
using namespace cv;

    cv::Mat SegmentInfo::getFloorMask() {
        return floorMask;
    }

    vector<SegmentRoom> SegmentInfo::getRooms() {
        return rooms;
    }

    vector<DoorLine> SegmentInfo::getDoors() {
        vector<DoorLine> tmpSet=this->doors;
        vector<DoorLine> tmpVector(tmpSet.begin(),tmpSet.end());
        return tmpVector;
    }

    vector<vector<cv::Point>> SegmentInfo::getRoomsByDoors(cv::Mat floormask, vector<DoorLine> doors) {
        cv::Mat mask = floormask.clone();
        for (DoorLine door : doors) {
            pair<int, int> startCoord = door.getStartNodeCoord();
            pair<int, int> endCoord = door.getEndNodeCoord();
            if (startCoord.first==endCoord.first && startCoord.second==endCoord.second) {
                cv::circle(mask, cv::Point(startCoord.first, startCoord.second), 6, cv::Scalar(0), cv::FILLED);
            } else {
                cv::line(mask, cv::Point(startCoord.first, startCoord.second), cv::Point(endCoord.first, endCoord.second), cv::Scalar(0), 2);
                cv::circle(mask, cv::Point(startCoord.first, startCoord.second), 6, cv::Scalar(0), cv::FILLED);
                cv::circle(mask, cv::Point(endCoord.first, endCoord.second), 6, cv::Scalar(0), cv::FILLED);
            }
        }

        vector<vector<cv::Point>> contours;
        cv::Mat hierarchy = cv::Mat();
        cv::findContours(mask, contours, hierarchy, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_NONE);

        return contours;
    }


    SegmentInfo::SegmentInfo(vector<DoorLine> doors, vector<DoorLine> corridors, vector<DoorLine> corridorCorridors, cv::Mat floorMask, cv::Mat instanceMask, int areaTh) {

        this->floorMask = floorMask;
        this->doors = doors;
        int height = floorMask.rows;
        int width = floorMask.cols;
        cv::Mat ldkMask = cv::Mat(height, width, CV_8UC1, cv::Scalar(0));

        uchar *instanceByte = (uchar *)malloc(instanceMask.total()*sizeof(uchar));
        memcpy(instanceByte,instanceMask.ptr<uchar>(0),sizeof(uchar)*instanceMask.total());
        uchar *ldkByte = (uchar *)malloc(ldkMask.total()*sizeof(uchar));
        cout<<"fixConnectivity2:"<<endl;
        uchar *countByte = (uchar *)malloc(ldkMask.total()*sizeof(uchar));
        memcpy(ldkByte,ldkMask.ptr<uchar>(0),sizeof(uchar)*ldkMask.total());
        cv::Mat roomMask = cv::Mat(height, width, CV_8UC1, cv::Scalar(0));
        cv::Mat partMask = cv::Mat(height, width, CV_8UC1, cv::Scalar(0));
        cv::Mat corridorPartMask = cv::Mat(height, width, CV_8UC1, cv::Scalar(0));
        for (int i = 0; i < instanceMask.total(); i++) {
            if (instanceByte[i] == LDK_LABEL) {
                ldkByte[i] = (uchar) 1;
            }
        }
        ldkMask = cv::Mat(ldkMask.rows,ldkMask.cols,CV_8UC1,ldkByte);
        int shapeId = 0;
        vector<vector<cv::Point>> roomContours = getRoomsByDoors(floorMask, doors);
        int ldkShapeId = -1;
        int maxLdkOverlapArea = 0;
        for (int groupId = 0; groupId < roomContours.size(); groupId++) {
            double roomArea = cv::contourArea(roomContours[groupId]);
            if (roomArea < areaTh) {
                continue;
            }
            roomMask = cv::Mat(roomMask.rows,roomMask.cols,CV_8UC1,cv::Scalar(0));
            cv::drawContours(roomMask, roomContours, groupId, cv::Scalar(1), cv::FILLED);
            roomMask = roomMask.mul(floorMask);
            vector<vector<cv::Point>> partContours = getRoomsByDoors(roomMask, corridors);
            for (int partId = 0; partId < partContours.size(); partId++) {
                double partArea = cv::contourArea(partContours[partId]);
                if (partArea < areaTh) {
                    continue;
                }
                partMask = cv::Mat(partMask.rows,partMask.cols,CV_8UC1,cv::Scalar(0));
                cv::drawContours(partMask, partContours, partId, cv::Scalar(1), cv::FILLED);
                partMask = partMask.mul(floorMask);
                vector<vector<cv::Point>> corridorPartContours = getRoomsByDoors(partMask, corridorCorridors);
                for (int corridorPartId = 0; corridorPartId < corridorPartContours.size(); corridorPartId++) {
                    double corridorPartArea = cv::contourArea(corridorPartContours[corridorPartId]);
                    if (corridorPartArea < areaTh) {
                        continue;
                    }
                    SegmentRoom room = SegmentRoom(corridorPartContours[corridorPartId], groupId, shapeId, "BEDROOM");
                    rooms.push_back(room);
                    corridorPartMask = cv::Mat(corridorPartMask.rows,corridorPartMask.cols,CV_8UC1,cv::Scalar(0));
                    cv::drawContours(corridorPartMask, corridorPartContours, corridorPartId, cv::Scalar(1), cv::FILLED);
                    corridorPartMask = corridorPartMask.mul(ldkMask);
                    memcpy(countByte,corridorPartMask.ptr<uchar>(0),sizeof(uchar)*corridorPartMask.total());

                    

                    int countSum = 0;
                    for (int i = 0; i < height * width; i++) {
                        if (countByte[i] != 0) {
                            countSum++;
                        }
                    }
                    if (countSum > maxLdkOverlapArea) {
                        maxLdkOverlapArea = countSum;
                        ldkShapeId = shapeId;
                    }
                    shapeId += 1;

                }

            }
        }
        if (ldkShapeId != -1) {
            rooms[ldkShapeId].setRoomType("LDK");
        }

        cv::Mat segmentMask = cv::Mat(height, width, CV_8UC1, cv::Scalar(0));

        for (int i = 0; i < rooms.size(); i++) {
            vector<vector<cv::Point>> contourList;
            contourList.push_back(rooms[i].getContours());
            cv::drawContours(segmentMask, contourList, -1, cv::Scalar(255), cv::FILLED);
        }
        free(instanceByte);
        free(ldkByte);
        free(countByte);
    }
