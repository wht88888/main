#include"voronoi/DoorLine.h"
using namespace std;

    //  bool DoorLine::equals(Object o) {
    //     if (this == o) return true;
    //     if (o == NULL || getClass() != o.getClass()) return false;
    //     DoorLine doorLine = (DoorLine) o;
    //     return this->nodeId==doorLine.nodeId;
    // }

    
    //  int DoorLine::hashCode() {
    //     return Objects.hash(nodeId);
    // }

    DoorLine::DoorLine(double doorLen, double doorAngle, pair<int, int> startNodeCoord, pair<int, int> endNodeCoord, int nodeId) {
        this->doorLen = doorLen;
        this->doorAngle = doorAngle;
        this->startNodeCoord = startNodeCoord;
        this->endNodeCoord = endNodeCoord;
        this->nodeId = nodeId;
    }

    pair<int, int> DoorLine::getStartNodeCoord() {
        return startNodeCoord;
    }

    pair<int, int> DoorLine::getEndNodeCoord() {
        return endNodeCoord;
    }