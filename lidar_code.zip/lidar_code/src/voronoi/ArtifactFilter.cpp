#include"voronoi/ArtifactFilter.h"
using namespace std;
using namespace cv;
#include<opencv2/imgproc.hpp>

ArtifactFilter::ArtifactFilter(int room_area_lower_bound, int hole_area_bound, int graph_diameter_th, double wall_width_th) {
        this->room_area_lower_bound = room_area_lower_bound;
        this->hole_area_bound = hole_area_bound;
        this->graph_diameter_th = graph_diameter_th;
        this->wall_width_th = wall_width_th;
    }

    // Mat ArtifactFilter::run(Mat floormask, bool outputBinary, MapData mapData) {
    //     this->mapData = mapData;
    //     return run(floormask, outputBinary);
    // }

    Mat ArtifactFilter::run(Mat floormask, bool outputBinary) {
        height = floormask.rows;
        width = floormask.cols;
        vector<vector<cv::Point>> contours;
        Mat hierarchy = Mat();
        findContours(floormask, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE);
        int contourNum = contours.size();
        vector<vector<cv::Point>> floorContours;
        vector<vector<cv::Point>> holeContours;
        for (int i = 0; i < contourNum; i++) {
            int contour_hier[4];
            // hierarchy.get(0, i, contour_hier);
            int *hierarchyData = hierarchy.ptr<int>(0,i);
            for(int j=0;j<4;j++){
                contour_hier[j]=hierarchyData[j];
            }

            if (contour_hier[3] == -1) {
                floorContours.push_back(contours[i]);
            } else {
                holeContours.push_back(contours[i]);
            }
        }

        floorContours = filterRoom(floorContours);
        holeContours = filterHole(holeContours);

        Mat filterMat = Mat(height, width, CV_8UC1, Scalar(0));
        if (outputBinary) {
            drawContours(filterMat, floorContours, -1, Scalar(1), FILLED);
        } else {
            drawContours(filterMat, floorContours, -1, Scalar(255), FILLED);
        }
        drawContours(filterMat, holeContours, -1, Scalar(0), FILLED);

        return filterMat;
    }


    vector<vector<cv::Point>> ArtifactFilter::filterRoom(vector<vector<cv::Point>> floorContours) {
        vector<vector<cv::Point>> filterContours;
        double maxArea = 0;
        vector<cv::Point> maxContours;
        for (int i = 0; i < floorContours.size(); i++) {
            vector<cv::Point> contour = floorContours[i];
            double contourArea = cv::contourArea(contour);
            if (contourArea > maxArea) {
                maxArea = contourArea;
                maxContours = contour;
            }
            if (contourArea > room_area_lower_bound) {
                filterContours.push_back(contour);
            }
        }
        if (filterContours.size() == 0 && maxContours.size()!=0) {
            // if (mapData != NULL) {
            //     vector<Float> oriPoint = mapData.getTransformedCoordinate(0, 0);
            //     if (oriPoint != NULL) {
            //         Point pt = Point(oriPoint[0), oriPoint[1));
            //         for (int i = 0; i < floorContours.size(); i++) {
            //             vector<cv::Point> contour = floorContours[i);
            //             double dist = pointPolygonTest(MatOfPoint2f(contour.toArray()), pt, true);
            //             if (dist >= 0) {
            //                 filterContours.push_back(contour);
            //                 break;
            //             }
            //         }
            //     }
            //     if (filterContours.size() == 0) filterContours.push_back(maxContours);
            // } else {
                double maxCoverage = 0;
                vector<cv::Point> maxCoverageContours;
                for (int i = 0; i < floorContours.size(); i++) {
                    vector<cv::Point> contour = floorContours[i];

                    double contourArea = cv::contourArea(contour);
                    if (contourArea > 2000) {
                        vector<cv::Point> points = contour;
                        double x1 = 1e9, x2 = 0, y1 = 1e9, y2 = 0;
                        for (cv::Point point : points) {
                            x1 = min((double)point.x, x1);
                            x2 = max((double)point.x, x2);
                            y1 = min((double)point.y, y1);
                            y2 = max((double)point.y, y2);
                        }
                        double wholeArea = (y2 - y1) * (x2 - x1);
                        double coverage = contourArea / wholeArea;
                        if (coverage > maxCoverage) {
                            maxCoverage = coverage;
                            maxCoverageContours = contour;
                        }
                    }
                // }
                if (maxCoverageContours.size()!=0) filterContours.push_back(maxCoverageContours);
                else filterContours.push_back(maxContours);
            }
        }
        return filterContours;
    }

    vector<vector<cv::Point>> ArtifactFilter::filterHole(vector<vector<cv::Point>> holeContours) {
        vector<vector<cv::Point>> filterContours;
        vector<vector<cv::Point>> resContours;
        for (int i = 0; i < holeContours.size(); i++) {
            if (contourArea(holeContours[i]) <= hole_area_bound) {
                filterContours.push_back(holeContours[i]);
            } else {
                resContours.push_back(holeContours[i]);
            }
        }

        Mat mask = Mat(height, width, CV_8UC1, Scalar(0));
        drawContours(mask, filterContours, -1, Scalar(1), FILLED);
        Mat instanceMask = Mat(height, width, CV_32SC1, Scalar(-1));

        if (filterContours.size() == 0) {
            return resContours;
        }
        for (int i = 0; i < filterContours.size(); i++) {
            drawContours(instanceMask, filterContours, i, Scalar(i), FILLED);
        }

        bool filterFlag[filterContours.size()];
        fill(filterFlag,filterFlag+filterContours.size(), true);

        Mat skeleton = Mat();
        ximgproc::thinning(binary2Show(mask), skeleton);

        Mat distMat = distTransform(mask);
        Mat skeletonF = Mat();
        skeleton.convertTo(skeletonF, CV_32FC1);
        Mat skeletonDistMat = distMat.mul(skeletonF);

        tuple<Graph, vector<pair<int, int>>, unordered_map<int, int>> analyzeResult = skeletonAnalysis(skeleton);

        Graph graph = get<0>(analyzeResult);
        vector<pair<int, int>> coords = get<1>(analyzeResult);
        vector<int> cp(num_vertices(graph));
        int num = connected_components(graph,&cp[0]);
        vector<std::unordered_set<int>> tempCluster(num);
        vertex_iter nodeId,v_end;
        for (tie(nodeId,v_end)=vertices(graph);nodeId!=v_end;++nodeId){
            tempCluster[cp[*nodeId]].insert(*nodeId);
        }

        for (int i = 0; i < num; i++) {
            unordered_set<int> vertSet = tempCluster[i];
            if (vertSet.size() < graph_diameter_th) {
                continue;
            }
            double averageDist = 0;
            int holeId = -1;
            int instanceId[1];
            for(const auto& vert:vertSet){
                pair<int, int> coord = coords[vert];
                int x = coord.first;
                int y = coord.second;
                float deltaDist = skeletonDistMat.at<float>(y, x);
                averageDist += deltaDist;

                int *instanceMaskData = instanceMask.ptr<int>(y,x);
                instanceId[0]=instanceMaskData[0];
                holeId = instanceId[0];

            }
            averageDist /= vertSet.size();
            if (averageDist < wall_width_th) {
                continue;
            }
            filterFlag[holeId] = false;
        }

        for (int i = 0; i < filterContours.size(); i++) {
            if (!filterFlag[i]) {
                resContours.push_back(filterContours[i]);
            }
        }

        return resContours;
    }
