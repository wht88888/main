#include"voronoi/SegmentRoom.h"
SegmentRoom::SegmentRoom(std::vector<cv::Point> contours, int groupId, int shapeId, std::string roomType) {
        this->contours = contours;
        this->groupId = groupId;
        this->shapeId = shapeId;
        this->roomType = roomType;
    }

     std::vector<cv::Point> SegmentRoom::getContours() {
        return contours;
    }

     int SegmentRoom::getGroupId() {
        return groupId;
    }

     int SegmentRoom::getShapeId() {
        return shapeId;
    }

     std::string SegmentRoom::getRoomType() {
        return roomType;
    }

     void SegmentRoom::setRoomType(std::string roomType) {
        this->roomType = roomType;
    }