#include "voronoi/fpg.h"
#include "iostream"

using namespace boost;

 double getL2Dist(int x1, int y1, int x2, int y2) {
    return std::sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
}

 double getCosin(int u1, int v1, int u2, int v2) {
    double len1 = std::sqrt(u1 * u1 + v1 * v1);
    double len2 = std::sqrt(u2 * u2 + v2 * v2);
    return (u1 * u2 + v1 * v2) / (len1 * len2);
}

// inline jobject convertInteger(JNIEnv *env, int i) {
//     jclass j_Integer = env->FindClass("java/lang/Integer");
//     jmethodID j_Integer_valueof = env->GetStaticMethodID(j_Integer, "valueOf",
//                                                          "(I)Ljava/lang/Integer;");
//     jobject j_Intvalue = env->CallStaticObjectMethod(j_Integer, j_Integer_valueof, i);
//     return j_Intvalue;
// }

 void getNeighbours(unsigned char *data, int width, int i, int j, std::vector<int> &neighborVec) {
    for (int p = -1; p < 2; p++) {
        for (int q = -1; q < 2; q++) {
            int neighbor_idx = (i + p) * width + j + q;
            if (data[neighbor_idx] != 0 && !(p == 0 && q == 0)) {
                neighborVec.push_back(neighbor_idx);
            }
        }
    }


}

// void convertVec(std::vector<int> nativeVec, JNIEnv *env, jobject javaList) {
//     jclass listClass = env->GetObjectClass(javaList);
//     jmethodID addMethod = env->GetMethodID(listClass, "add", "(Ljava/lang/Object;)Z");
//     for (int i = 0; i < nativeVec.size(); i++) {
//         jobject val = convertInteger(env, nativeVec[i]);
//         env->CallBooleanMethod(javaList, addMethod, val);
//         env->DeleteLocalRef(val);
//     }
// }

// void convertMap(std::unordered_map<int, int> nativeMap, JNIEnv *env, jobject javaMap) {
//     jclass mapClass = env->GetObjectClass(javaMap);
//     jmethodID putMethod = env->GetMethodID(mapClass, "put",
//                                            "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");

//     for (const std::pair<const int, int> &n: nativeMap) {
//         jobject obj1 = convertInteger(env, n.first);
//         jobject obj2 = convertInteger(env, n.second);
//         env->CallObjectMethod(javaMap, putMethod, obj1, obj2);
//         env->DeleteLocalRef(obj1);
//         env->DeleteLocalRef(obj2);

//     }
// }


std::vector<int> getCandidateNode(std::unordered_set<int> roomNodes, Graphfpg graph, int distTh, std::vector<int> coords,bool isMinDist) {
    std::vector<int> candidateVec;

    std::unordered_set<int> resultSet;
    typename graph_traits<Graphfpg>::adjacency_iterator vi, vi_end;
    candidateVec.insert(candidateVec.begin(), roomNodes.begin(), roomNodes.end());
    std::vector<E> clusterEdge;

    for (int i = 0; i < candidateVec.size(); i++) {
        std::vector<Vertex> p(num_vertices(graph));
        std::vector<int> d(num_vertices(graph));
        dijkstra_shortest_paths(graph, (Vertex)candidateVec[i],
                                predecessor_map(boost::make_iterator_property_map(
                                        p.begin(), get(boost::vertex_index, graph)))
                                        .distance_map(boost::make_iterator_property_map(
                                                d.begin(), get(boost::vertex_index, graph))));
                                // predecessor_map(make_iterator_property_map(p.begin(),get(vertex_index,graph))).
                                // distance_map(make_iterator_property_map(d.begin(),get(vertex_index,graph))).
                                // weight_map(make_constant_property<Edge>(1.0)));
        for (int j = i + 1; j < candidateVec.size(); j++) {
            if (d[candidateVec[j]] < distTh) {
                clusterEdge.push_back(std::make_pair(i, j));
            }

        }

    }

    std::vector<int> clusterEdgeWeights(clusterEdge.size(), 1);
    Graphfpg clusterGraph(clusterEdge.data(), clusterEdge.data() + clusterEdge.size(),
                       clusterEdgeWeights.data(), candidateVec.size());

    std::vector<int> components(candidateVec.size());
    int clusterNum = connected_components(clusterGraph, &components[0]);
    std::vector<int> resultList(clusterNum, 0);
    if (!isMinDist) {
        for (int i = 0; i < components.size(); i++) {
            int clusterIdx = components[i];
            resultList[clusterIdx] = candidateVec[i];
        }
    } else {
        for (int i = 0; i < clusterNum; i++) {
            std::vector<int> selectVec;
            for (int j = 0; j < candidateVec.size(); j++) {
                if (components[j] == i) {
                    selectVec.push_back(candidateVec[j]);
                }
            }
            int minDist = 100000;
            int minNodeId = -1;
            for (int p = 0; p < selectVec.size(); p++) {
                int sumDist = 0;
                for (int q = 0; q < selectVec.size(); q++) {
                    sumDist += getL2Dist(coords[selectVec[p] * 2], coords[selectVec[p] * 2 + 1],
                                         coords[selectVec[q] * 2], coords[selectVec[q] * 2 + 1]);
                }
                if (sumDist < minDist) {
                    minDist = sumDist;
                    minNodeId = selectVec[p];
                }
            }
            resultList[i] = minNodeId;

        }
    }

    return resultList;


}

std::vector<int>
getCandidateNode(std::unordered_set<int> roomNodes, Graphfpg graph, int distTh, std::vector<int> coords,
                 bool isMinDist, std::unordered_map<int, std::vector<int>> &backpaths,
                 int backlen) {
    std::vector<int> candidateVec;
    std::unordered_set<int> resultSet;
    std::unordered_map<int, std::vector<int>> allCandidateBackPaths;
    typename graph_traits<Graphfpg>::adjacency_iterator vi, vi_end;
    for (auto it = roomNodes.begin(); it != roomNodes.end(); it++) {
        tie(vi, vi_end) = adjacent_vertices(*it, graph);
        while (vi != vi_end) {
            if (roomNodes.find(*vi) == roomNodes.end()) {
                candidateVec.push_back(*it);
                break;
            }
            vi++;
        }
    }
    std::vector<E> clusterEdge;
    for (int i = 0; i < candidateVec.size(); i++) {
        std::vector<Vertex> p(num_vertices(graph));
        std::vector<int> d(num_vertices(graph));
        dijkstra_shortest_paths(graph, candidateVec[i],
                                predecessor_map(boost::make_iterator_property_map(
                                        p.begin(), get(boost::vertex_index, graph)))
                                        .distance_map(boost::make_iterator_property_map(
                                                d.begin(), get(boost::vertex_index, graph))));
        for (int j = i + 1; j < candidateVec.size(); j++) {
            if (d[candidateVec[j]] < distTh) {
                clusterEdge.push_back(std::make_pair(i, j));
            }

        }

        std::vector<int> backpath;

        for (int j = 0; j < num_vertices(graph); j++) {
            if (d[j] <= backlen) {
                backpath.push_back(j);
            }
        }
        allCandidateBackPaths[candidateVec[i]] = backpath;
    }

    std::vector<int> clusterEdgeWeights(clusterEdge.size(), 1);
    Graphfpg clusterGraph(clusterEdge.data(), clusterEdge.data() + clusterEdge.size(),
                       clusterEdgeWeights.data(), candidateVec.size());


    std::vector<int> components(candidateVec.size());
    int clusterNum = connected_components(clusterGraph, &components[0]);
    std::vector<int> resultList(clusterNum, 0);
    if (!isMinDist) {
        for (int i = 0; i < components.size(); i++) {
            int clusterIdx = components[i];
            resultList[clusterIdx] = candidateVec[i];
        }
    } else {
        for (int i = 0; i < clusterNum; i++) {
            std::vector<int> selectVec;
            for (int j = 0; j < candidateVec.size(); j++) {
                if (components[j] == i) {
                    selectVec.push_back(candidateVec[j]);
                }
            }
            int minDist = 100000;
            int minNodeId = -1;
            for (int p = 0; p < selectVec.size(); p++) {
                int sumDist = 0;
                for (int q = 0; q < selectVec.size(); q++) {
                    sumDist += getL2Dist(coords[selectVec[p] * 2], coords[selectVec[p] * 2 + 1],
                                         coords[selectVec[q] * 2], coords[selectVec[q] * 2 + 1]);
                }
                if (sumDist < minDist) {
                    minDist = sumDist;
                    minNodeId = selectVec[p];
                }
            }
            resultList[i] = minNodeId;

        }
    }

    backpaths.insert(allCandidateBackPaths.begin(), allCandidateBackPaths.end());

    return resultList;

}

std::vector<fpgDoorLine> getCriticalLine(std::vector<int> contourCoords, int contourPointNum, std::vector<int> doorNodes,std::vector<int> coords) {
    std::vector<fpgDoorLine> fpgDoorLines;
    double angleTh = -0.766;
    for (int p = 0; p < doorNodes.size(); p++) {
        double minDist1 = 100000;
        int minIdx1 = 0;
        int doorNode = doorNodes[p];
        int i = coords[doorNode * 2 + 1];
        int j = coords[doorNode * 2];
        for (int k = 0; k < contourPointNum; k++) {
            double dist = getL2Dist(j, i, contourCoords[k * 2], contourCoords[k * 2 + 1]);
            if (dist < minDist1) {
                minDist1 = dist;
                minIdx1 = k;
            }
        }

        int p1Idx = minIdx1;
        int p1toC_x = contourCoords[p1Idx * 2] - j;
        int p1toC_y = contourCoords[p1Idx * 2 + 1] - i;


        if (std::fabs(p1toC_y) < 0.1 && std::fabs(p1toC_x) < 0.1) {
            fpgDoorLine line(0, 0, doorNode);
            fpgDoorLines.push_back(line);
            continue;
        }

        double minDist2 = 100000;
        int minIdx2 = 0;
        double minAlignDist2 = 100000;
        int minAlignIdx2 = 0;

        for (int k = 0; k < contourPointNum; k++) {
            int p2toC_x = contourCoords[k * 2] - j;
            int p2toC_y = contourCoords[k * 2 + 1] - i;
            double dotVal = getCosin(p1toC_x, p1toC_y, p2toC_x, p2toC_y);
            double ptDist = getL2Dist(contourCoords[minIdx1 * 2], contourCoords[minIdx1 * 2 + 1],
                                      contourCoords[k * 2], contourCoords[k * 2 + 1]);
            if ((std::fabs(contourCoords[k * 2] - contourCoords[minIdx1 * 2]) < 5 ||
                 std::fabs(contourCoords[k * 2 + 1] - contourCoords[minIdx1 * 2 + 1])) &&
                dotVal < 0) {
                if (ptDist < minAlignDist2) {
                    minAlignDist2 = ptDist;
                    minAlignIdx2 = k;
                }
            }

            if (dotVal < angleTh && ptDist < minDist2) {
                minDist2 = ptDist;
                minIdx2 = k;
            }
        }
        if (minAlignDist2 < 1.35 * minDist2) {
            fpgDoorLine line(minAlignDist2, 0, doorNode);
            fpgDoorLines.push_back(line);
        } else {
            double lineCosAngle =
                    std::fabs(contourCoords[minIdx1 * 2] - contourCoords[minIdx2 * 2]) / minDist2;
            fpgDoorLine line(minDist2, lineCosAngle, doorNode);
            fpgDoorLines.push_back(line);
        }
    }
    return fpgDoorLines;
}


std::pair<std::unordered_set<int>, std::unordered_map<int, std::pair<int, int>>>
getDoorFromPairCluster(std::vector<int> contourCoords, int contourPointNum,
                       Graphfpg graph, std::vector<int> candidate1,
                       std::vector<int> candidate2,
                       std::unordered_map<int, std::vector<int>> backpaths,
                       std::unordered_set<int> whiteNodes, int searchDistTh,
                       std::unordered_map<int, int> distMap,
                       std::vector<int> coords, bool strictMode) {
    std::unordered_map<int, std::pair<int, int>> doorDict;
    std::unordered_set<int> doorCandidates;
    const int BACK_PATH_TH = 10;
    const int DOOR_DIST_TH = 20;
    const int STRICT_DOOR_TH = 40;
    const int WIDE_DOOR_TH = 90;

    for (int i = 0; i < candidate1.size(); i++) {
        std::vector<Vertex> p(num_vertices(graph));
        std::vector<int> d(num_vertices(graph));
        dijkstra_shortest_paths(graph, candidate1[i],
                                predecessor_map(boost::make_iterator_property_map(
                                        p.begin(), get(boost::vertex_index, graph)))
                                        .distance_map(boost::make_iterator_property_map(
                                                d.begin(), get(boost::vertex_index, graph))));
        for (int j = 0; j < candidate2.size(); j++) {
            if (d[candidate2[j]] < searchDistTh) {
                std::vector<int> pathNodes;
                int node = candidate2[j];
                int noneWhiteCount = 0;
                bool pathBlock = false;
                while (node != candidate1[i]) {
                    if (whiteNodes.find(node) == whiteNodes.end()) {
                        noneWhiteCount++;
                        if (noneWhiteCount > 15) {
                            pathBlock = true;
                            break;
                        }
                    }
                    pathNodes.push_back(node);
                    node = p[node];
                }
                if (!pathBlock) {
                    std::vector<int> backpath1 = backpaths[candidate1[i]];
                    std::vector<int> backpath2 = backpaths[candidate2[j]];
                    pathNodes.insert(pathNodes.begin(), backpath1.begin(), backpath1.end());
                    pathNodes.insert(pathNodes.begin(), backpath2.begin(), backpath2.end());
                    int minVal = 1000000;
                    int minNodeId = 0;
                    for (int k = 0; k < pathNodes.size(); k++) {
                        if (distMap.find(pathNodes[k]) != distMap.end()) {
                            int distval = distMap[pathNodes[k]];
                            if (distval < minVal) {
                                minVal = distval;
                                minNodeId = pathNodes[k];
                            }
                        }
                    }

                    doorCandidates.insert(minNodeId);
                    doorDict[minNodeId] = std::make_pair(candidate1[i], candidate2[j]);

                }
            }
        }
    }

    std::vector<int> clusterNodes = getCandidateNode(doorCandidates, graph, DOOR_DIST_TH, coords,true);
    std::unordered_set<int> filterDoors;
    std::vector<fpgDoorLine> fpgDoorLines = getCriticalLine(contourCoords, contourPointNum, clusterNodes,coords);
    if (strictMode && fpgDoorLines.size() == 1) {
        if (fpgDoorLines[0].doorLen < STRICT_DOOR_TH) {
            filterDoors.insert(fpgDoorLines[0].nodeID);
        }
    } else if (fpgDoorLines.size() == 1) {
        if (fpgDoorLines[0].doorLen < WIDE_DOOR_TH || fpgDoorLines[0].doorCosAngle < 0.5 ||
            fpgDoorLines[0].doorCosAngle > 0.87) {
            filterDoors.insert(fpgDoorLines[0].nodeID);
        }
    } else if (fpgDoorLines.size() > 1) {
        for (int k = 0; k < fpgDoorLines.size(); k++) {
            if (fpgDoorLines[0].doorLen < WIDE_DOOR_TH) {
                filterDoors.insert(fpgDoorLines[k].nodeID);
            }
        }
    }

    return std::make_pair(filterDoors, doorDict);
}



uchar * getMinDistNative(std::vector<int> nativeCoords,
                int width, int height,
                uchar * skeleton_ptr,
                uchar * result_ptr)
{
    unsigned char *skeletonData = (unsigned char *) skeleton_ptr;
    float *resultData = (float *) result_ptr;
    int coordNum = nativeCoords.size()/2;

    double angleTh = -0.7666;
    #pragma omp parallel for num_threads(4)
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            int idx = i * width + j;
            if (skeletonData[idx] != 0) {
                double minDist1 = 100000.0;
                int minIdx1 = 0;
                for (int k = 0; k < coordNum; k++) {
                    double dist = getL2Dist(j, i, nativeCoords[k * 2], nativeCoords[k * 2 + 1]);
                    if (dist < minDist1) {
                        minDist1 = dist;
                        minIdx1 = k;
                    }
                }
                if (getL2Dist(j, i, nativeCoords[minIdx1 * 2], nativeCoords[minIdx1 * 2 + 1]) <
                    0.15) {
                    resultData[idx] = 1.0;
                    continue;
                }

                int p1toC_x = nativeCoords[minIdx1 * 2] - j;
                int p1toC_y = nativeCoords[minIdx1 * 2 + 1] - i;

                int p2Target_x = 2 * j - nativeCoords[minIdx1 * 2];
                int p2Target_y = 2 * i - nativeCoords[minIdx1 * 2 + 1];

                int minIdx2 = 0;
                double minDist2 = 100000.0;
                for (int k = 0; k < coordNum; k++) {
                    int p2toC_x = nativeCoords[k * 2] - j;
                    int p2toC_y = nativeCoords[k * 2 + 1] - i;
                    if (getCosin(p1toC_x, p1toC_y, p2toC_x, p2toC_y) < angleTh) {
                        double dist = getL2Dist(p2Target_x, p2Target_y, nativeCoords[k * 2],
                                                nativeCoords[k * 2 + 1]);
                        if (dist < minDist2) {
                            minDist2 = dist;
                            minIdx2 = k;
                        }
                    }

                }
                resultData[idx] =
                        getL2Dist(nativeCoords[minIdx1 * 2], nativeCoords[minIdx1 * 2 + 1],
                                  nativeCoords[minIdx2 * 2], nativeCoords[minIdx2 * 2 + 1]) / 2;

            }
        }
    }
    return (uchar *)resultData;
}

std::tuple<std::vector<int>,std::vector<int>,std::unordered_map<int,int>> nativeSkeletonAnalysis(uchar* skeleton_ptr,
                        int width,
                        int height)
{
    std::vector<int> coordVec;
    std::vector<int> degrees;

    std::vector<std::vector<int>> neighbour_encode_vec;
    std::unordered_map<int, int> nativeIdxMap;
    unsigned char *skeletonData = (unsigned char *) skeleton_ptr;


    for (int i = 1; i < height - 1; i++) {
        for (int j = 1; j < width - 1; j++) {
            int idx = i * width + j;
            if (skeletonData[idx] != 0) {
                coordVec.push_back(idx);
                nativeIdxMap[idx] = coordVec.size() - 1;
                std::vector<int> neighborVec;
                getNeighbours(skeletonData, width, i, j, neighborVec);
                neighbour_encode_vec.push_back(neighborVec);
                degrees.push_back(neighborVec.size());
            }
        }
    }


    std::vector<E> junction_edges;
    std::vector<int> none_junction_edges;
    std::vector<int> weights;

    for (int i = 0; i < coordVec.size(); i++) {
        std::vector<int> neighbour = neighbour_encode_vec[i];
        for (int j = 0; j < neighbour.size(); j++) {
            if (nativeIdxMap.find(neighbour[j]) == nativeIdxMap.end()) {
                continue;
            }
            int decode_val = nativeIdxMap[neighbour[j]];
            if (i < decode_val && degrees[i] >= 3 && degrees[decode_val] >= 3) {
                junction_edges.push_back(std::make_pair(i, decode_val));
                weights.push_back(1);
            } else if (i < decode_val) {
                none_junction_edges.push_back(i);
                none_junction_edges.push_back(decode_val);
            }
        }
    }


    Graphfpg g(junction_edges.data(), junction_edges.data() + junction_edges.size(), weights.data(),
            coordVec.size());
    std::vector<Edge> spanning_tree;
    kruskal_minimum_spanning_tree(g, std::back_inserter(spanning_tree));
    std::vector<std::pair<Vertex, Vertex>> resultEdges;
    for (std::vector<Edge>::iterator iter = spanning_tree.begin();
         iter != spanning_tree.end(); iter++) {
        Vertex source_v = source(*iter, g);
        Vertex target_v = target(*iter, g);
        none_junction_edges.push_back(source_v);
        none_junction_edges.push_back(target_v);

    }

    return std::tuple<std::vector<int>,std::vector<int>,std::unordered_map<int,int>>(coordVec,none_junction_edges,nativeIdxMap);

    // convertVec(none_junction_edges, env, edges);
    // convertVec(coordVec, env, coords);
    // convertMap(nativeIdxMap, env, idx_map);


}

std::tuple<std::vector<int>,std::vector<int>,std::vector<int>> nativeGetDoorPos(
                    std::vector<int> nativeFloorContours,
                    std::vector<int> nativeLdkLength,
                    std::vector<int> nativeLdkNodes,
                    std::vector<int> nativeRoomLength,
                    std::vector<int> nativeRoomNodes,
                    std::vector<int> nativeCorridorLength,
                    std::vector<int> nativeCorridorNodes,
                    std::vector<int> nativeWhite,
                    int vertext_num,
                    std::vector<int> nativeEdges,
                    std::vector<int> nativeDistMap,
                    std::vector<int> nativeCoords,
                    std::vector<int> nativeRoomIds){
    // TODO: implement nativeGetDoorPos()

    int contourPointsNum = nativeFloorContours.size() / 2;
    int coordNum = nativeCoords.size() / 2;
    std::vector<std::unordered_set<int>> ldkNodes;
    std::vector<std::unordered_set<int>> corridorNodes;
    std::vector<std::unordered_set<int>> roomNodes;
    int ldkNum = nativeLdkLength.size();
    int currentIdx = 0;
    for (int i = 0; i < ldkNum; i++) {
        std::unordered_set<int> ldkSet;
        int roomLen = nativeLdkLength[i];
        for (int j = 0; j < roomLen; j++) {
            ldkSet.insert(nativeLdkNodes[currentIdx]);
            currentIdx++;
        }
        ldkNodes.push_back(ldkSet);
    }
    int roomNum = nativeRoomLength.size();

    currentIdx = 0;
    for (int i = 0; i < roomNum; i++) {
        std::unordered_set<int> roomSet;
        int roomLen = nativeRoomLength[i];
        for (int j = 0; j < roomLen; j++) {
            roomSet.insert(nativeRoomNodes[currentIdx]);
            currentIdx++;
        }
        roomNodes.push_back(roomSet);
    }
    int corridorNum = nativeCorridorLength.size();

    currentIdx = 0;
    for (int i = 0; i < corridorNum; i++) {
        std::unordered_set<int> corridorSet;
        int roomLen = nativeCorridorLength[i];
        for (int j = 0; j < roomLen; j++) {
            corridorSet.insert(nativeCorridorNodes[currentIdx]);
            currentIdx++;
        }
        corridorNodes.push_back(corridorSet);
    }

    std::unordered_set<int> whiteNodes;
    int whiteNum = nativeWhite.size();
    for (int i = 0; i < whiteNum; i++) {
        whiteNodes.insert(nativeWhite[i]);
    }

    std::unordered_set<int> newRoomIds;
    int newRoomIdNum = nativeRoomIds.size();
    for (int i = 0; i < newRoomIdNum; i++) {
        newRoomIds.insert(nativeRoomIds[i]);
    }

    int edgeNum = nativeEdges.size() / 2;
    std::vector<E> graphEdges;
    std::vector<int> edgeWeights;

    for (int i = 0; i < edgeNum; i++) {
        graphEdges.push_back(std::make_pair(nativeEdges[i * 2], nativeEdges[i * 2 + 1]));\
        edgeWeights.push_back(1);
    }

    Graphfpg graph(graphEdges.data(), graphEdges.data() + graphEdges.size(), edgeWeights.data(),
                coordNum);

    int distMapNum = nativeDistMap.size() / 2;
    std::unordered_map<int, int> distMap;
    for (int i = 0; i < distMapNum; i++) {
        distMap[nativeDistMap[i * 2]] = nativeDistMap[i * 2 + 1];
    }

    const int CANDIDATE_DIST_TH = 2;
    std::vector<std::vector<int>> ldkCandidates;
    std::vector<std::vector<int>> roomCandidates;
    std::vector<std::vector<int>> corridorCandidates;

    //std::unordered_map<int, std::vector<int>> ldkBackPaths;
    //std::unordered_map<int, std::vector<int>> corridorBackPaths;
    //std::unordered_map<int, std::vector<int>> roomBackPaths;
    std::unordered_map<int, std::vector<int>> allBackPaths;
    for (int i = 0; i < ldkNodes.size(); i++) {
        ldkCandidates.push_back(
                getCandidateNode(ldkNodes[i], graph, CANDIDATE_DIST_TH, nativeCoords, false,
                                 allBackPaths, 10));
    }
    for (int i = 0; i < roomNodes.size(); i++) {
        roomCandidates.push_back(
                getCandidateNode(roomNodes[i], graph, CANDIDATE_DIST_TH, nativeCoords, false,
                                 allBackPaths, 10));
    }
    for (int i = 0; i < corridorNodes.size(); i++) {
        corridorCandidates.push_back(
                getCandidateNode(corridorNodes[i], graph, CANDIDATE_DIST_TH, nativeCoords, false,
                                 allBackPaths, 10));
    }

    std::unordered_set<int> corridorDoors;
    std::unordered_set<int> corridorCorridorDoors;
    std::unordered_set<int> roomDoor1s;
    std::unordered_set<int> roomDoor2s;
    std::vector<int> corridorDoorVec;
    std::vector<int> doorVec;
    std::vector<int> corridorCorridorVec;
    const int SEARCH_DIST_TH = 300;


// getDoorFromPairCluster(std::vector<int> contourCoords, int contourPointNum,
//                                                                                                        Graphfpg graph, std::vector<int> candidate1,
//                                                                                                        std::vector<int> candidate2, std::unordered_map<int, std::vector<int>> backpaths,
//                                                                                                        std::unordered_set<int> whiteNodes, int searchDistTh, std::unordered_map<int, int> distMap,
//                                                                                                        std::vector<int> coords, bool strictMode) {


    for (int i = 0; i < ldkCandidates.size(); i++) {
        for (int j = 0; j < corridorCandidates.size(); j++) {
            std::pair<std::unordered_set<int>, std::unordered_map<int, std::pair<int, int>>> doorinfo = getDoorFromPairCluster(
                    nativeFloorContours,
                    contourPointsNum,
                    graph,
                    ldkCandidates[i],
                    corridorCandidates[j],
                    allBackPaths,
                    whiteNodes,
                    SEARCH_DIST_TH,
                    distMap, nativeCoords, false);
            corridorDoors.insert(doorinfo.first.begin(), doorinfo.first.end());
        }
    }


    for (int i = 0; i < corridorCandidates.size(); i++) {
        for (int j = i + 1; j < corridorCandidates.size(); j++) {
            std::pair<std::unordered_set<int>, std::unordered_map<int, std::pair<int, int>>> doorinfo = getDoorFromPairCluster(
                    nativeFloorContours,
                    contourPointsNum,
                    graph,
                    corridorCandidates[i],
                    corridorCandidates[j],
                    allBackPaths,
                    whiteNodes,
                    SEARCH_DIST_TH,
                    distMap, nativeCoords, false);


            corridorCorridorDoors.insert(doorinfo.first.begin(), doorinfo.first.end());

        }
    }

    std::vector<std::vector<int>> ldkAndCorridorCandidates;
    ldkAndCorridorCandidates.insert(ldkAndCorridorCandidates.begin(), corridorCandidates.begin(),
                                    corridorCandidates.end());
    ldkAndCorridorCandidates.insert(ldkAndCorridorCandidates.begin(), ldkCandidates.begin(),
                                    ldkCandidates.end());

    for (int i = 0; i < ldkAndCorridorCandidates.size(); i++) {
//#pragma omp parallel for
        for (int j = 0; j < roomCandidates.size(); j++) {

            bool strictMode = false;
            if (newRoomIds.find(j) != newRoomIds.end()) {
                strictMode = true;
            }
            std::pair<std::unordered_set<int>, std::unordered_map<int, std::pair<int, int>>> doorinfo = getDoorFromPairCluster(
                    nativeFloorContours,
                    contourPointsNum,
                    graph,
                    ldkAndCorridorCandidates[i],
                    roomCandidates[j],
                    allBackPaths,
                    whiteNodes,
                    SEARCH_DIST_TH,
                    distMap, nativeCoords, strictMode);

            //#pragma omp critical
            {
                std::unordered_map<int, std::pair<int, int>> doorConnectMap = doorinfo.second;
                std::unordered_map<int, std::unordered_map<int, int>> roomLDKConnectDoors;
                for (auto doorIter = doorinfo.first.begin();
                     doorIter != doorinfo.first.end(); doorIter++) {
                    if (corridorDoors.find(*doorIter) != corridorDoors.end()) {
                        continue;
                    } else {
                        roomDoor1s.insert(*doorIter);
                        int ldkNode = doorConnectMap[*doorIter].first;
                        int roomNode = doorConnectMap[*doorIter].second;
                        if (roomLDKConnectDoors.find(roomNode) == roomLDKConnectDoors.end()) {
                            std::unordered_map<int, int> tmpmap;
                            roomLDKConnectDoors[roomNode] = tmpmap;
                        }
                        roomLDKConnectDoors[roomNode][ldkNode] = *doorIter;

                    }
                }

                for (const auto [roomNode, roomConnectLdks]: roomLDKConnectDoors) {
                    if (roomConnectLdks.size() > 1) {
                        for (const auto [ldk, door]: roomConnectLdks) {
                            roomDoor1s.erase(door);
                        }

                        roomDoor1s.insert(roomNode);
                    }
                }


            }
        }
    }

//#pragma omp parallel for num_threads(4)
    for (int i = 0; i < roomCandidates.size(); i++) {
        for (int j = i + 1; j < roomCandidates.size(); j++) {
            bool strictMode = false;
            if (newRoomIds.find(j) != newRoomIds.end() || newRoomIds.find(i) != newRoomIds.end()) {
                strictMode = true;
            }
            std::pair<std::unordered_set<int>, std::unordered_map<int, std::pair<int, int>>> doorinfo = getDoorFromPairCluster(
                    nativeFloorContours,
                    contourPointsNum,
                    graph,
                    roomCandidates[i],
                    roomCandidates[j],
                    allBackPaths,
                    whiteNodes,
                    SEARCH_DIST_TH,
                    distMap, nativeCoords, strictMode);


//            #pragma omp critical
            {
                roomDoor2s.insert(doorinfo.first.begin(), doorinfo.first.end());
            }
        }
    }

    doorVec.insert(doorVec.begin(), roomDoor1s.begin(), roomDoor1s.end());
    doorVec.insert(doorVec.begin(), roomDoor2s.begin(), roomDoor2s.end());
    corridorCorridorVec.insert(corridorCorridorVec.begin(), corridorCorridorDoors.begin(),
                               corridorCorridorDoors.end());
    corridorDoorVec.insert(corridorDoorVec.begin(), corridorDoors.begin(), corridorDoors.end());

    return std::tuple<std::vector<int>,std::vector<int>,std::vector<int>>(doorVec,corridorDoorVec,corridorCorridorVec);

    // convertVec(doorVec, env, doors);
    // convertVec(corridorDoorVec, env, corridors);
    // convertVec(corridorCorridorVec, env, corridor_corridors);

}


