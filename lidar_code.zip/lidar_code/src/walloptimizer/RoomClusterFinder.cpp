#include "walloptimizer/RoomClusterFinder.h"
using namespace std;
using namespace cv;
using namespace boost;

int distanceTh;
int intersectTh = 5;
int overlapTh = 1;

std::unordered_map<int, Graph> RoomClusterFinder(vector<Contour> contours, int supportLineClusterNum, Mat floormask, int lineDistance, bool checkOverlap, bool checkIntersect, bool checkBigGap, bool checkLDK, bool checkSelf)
{
    distanceTh = lineDistance;
    std::unordered_map<int, Graph> graphDict;
    if (checkSelf)
    {
        Graph graph = buildSelfGraph(contours, floormask, lineDistance);
        graphDict.insert({0, graph});
        return graphDict;
    }
    for (int i = 0; i < supportLineClusterNum; i++)
    {
        if (checkLDK)
        {
            Graph graph = buildLDKClusterGraph(contours, checkOverlap, checkIntersect, checkBigGap, i, floormask);
            graphDict.insert({i, graph});
        }
        else if (checkBigGap)
        {
            Graph graph = buildBigGapGraph(contours, i, floormask);
            graphDict.insert({i, graph});
        }
        else
        {
            Graph graph = buildClusterGraph(contours, checkOverlap, checkIntersect, checkBigGap, i, floormask);
            graphDict.insert({i, graph});
        }
    }
    return graphDict;
}

Graph buildLDKClusterGraph(vector<Contour> contours, bool checkOverlap, bool checkIntersect, bool checkBig, int lineClusterId, Mat floormask)
{
    // org.jgrapht.Graph<int, DefaultEdge> ldkClusterGraph =  DefaultUndirectedGraph<>(DefaultEdge.class);
    Graph ldkClusterGraph;
    int ldkLineDistTh = 20;
    int nc = contours.size();
    std::unordered_map<int, Vertex> contains;
    Vertex v1 = -1, v2 = -1;
    for (int m = 0; m < nc; m++)
    {
        Contour contour1 = contours[m];
        if (contour1.getLabel() == "LDK")
        {
            vector<Line> line1s = contour1.getLines();
            for (int i = 0; i < line1s.size(); i++)
            {
                Line line1 = line1s[i];
                if (line1.getCluster() != lineClusterId)
                {
                    continue;
                }
                for (int j = i + 1; j < line1s.size(); j++)
                {
                    Line line2 = line1s[j];
                    if (line2.getCluster() != lineClusterId)
                    {
                        continue;
                    }
                    pair<bool, double> distanceInfo = checkDistanceBtwLines(line1, line2, ldkLineDistTh, false, true);
                    double diff = 90;
                    double angle1 = ((int)line1.angle() + 180) % 180;
                    double angle2 = ((int)line2.angle() + 180) % 180;
                    diff = fabs(angle1 - angle2);
                    if (distanceInfo.first && (diff < 25 || diff > 155))
                    {
                        int nodeId1 = AlignOptimizer::encodeNode(m, i);
                        int nodeId2 = AlignOptimizer::encodeNode(m, j);
                        if (contains.find(nodeId1) == contains.end())
                        {
                            v1 = add_vertex(ldkClusterGraph);
                            ldkClusterGraph[v1].index = nodeId1;
                            contains.insert({nodeId1, v1});
                        }
                        else
                        {
                            v1 = contains[nodeId1];
                        }
                        if (contains.find(nodeId2) == contains.end())
                        {
                            v2 = add_vertex(ldkClusterGraph);
                            ldkClusterGraph[v2].index = nodeId2;
                            contains.insert({nodeId2, v1});
                        }
                        else
                        {
                            v2 = contains[nodeId2];
                        }
                        if (!edge(v1, v2, ldkClusterGraph).second)
                        {
                            add_edge(v1, v2, ldkClusterGraph);
                        }
                    }
                }
            }
        }

        // ConnectedComponentsAlgo cpAlgo = ConnectedComponentsAlgo.newBuilder().build();
        // ConnectedComponentsAlgo.Result cp = cpAlgo.computeConnectivityComponents(ldkClusterGraph);
        vector<int> cp(num_vertices(ldkClusterGraph));
        int num = connected_components(ldkClusterGraph, &cp[0]);
        vector<std::unordered_set<int>> tempCluster(num);
        vertex_iter nodeId, v_end;
        for (tie(nodeId, v_end) = vertices(ldkClusterGraph); nodeId != v_end; ++nodeId)
        {
            tempCluster[cp[*nodeId]].insert(ldkClusterGraph[*nodeId].index);
        }

        for (int k = 0; k < num; k++)
        {
            std::unordered_set<int> ldkGroup = tempCluster[k];
            for (const int &nodeId : ldkGroup)
            {
                pair<int, int> nodeInfo = AlignOptimizer::decodeNode(nodeId);
                int contourId = nodeInfo.first;
                int lineId = nodeInfo.second;
                Line line1 = contours[contourId].getLines()[lineId];
                for (int n = 0; n < contours.size(); n++)
                {
                    if (n == m)
                    {
                        continue;
                    }
                    Contour contour2 = contours[n];
                    vector<Line> line2s = contour2.getLines();
                    for (int j = 0; j < line2s.size(); j++)
                    {
                        Line line2 = line2s[j];
                        if (line2.getCluster() != lineClusterId)
                        {
                            continue;
                        }
                        pair<bool, double> distanceInfo = checkDistanceBtwLines(line1, line2, distanceTh, true, true);
                        if (distanceInfo.first)
                        {
                            int targetNodeId = AlignOptimizer::encodeNode(n, j);
                            if (contains.find(targetNodeId) == contains.end())
                            {
                                v1 = add_vertex(ldkClusterGraph);
                                ldkClusterGraph[v1].index = targetNodeId;
                                contains.insert({targetNodeId, v1});
                            }
                            else
                            {
                                v1 = contains[targetNodeId];
                            }
                            v2 = contains[nodeId];
                            if (!edge(v1, v2, ldkClusterGraph).second)
                            {
                                add_edge(v1, v2, ldkClusterGraph);
                            }
                        }
                    }
                }
            }
        }
    }
    return ldkClusterGraph;
}

Graph buildClusterGraph(vector<Contour> contours, bool checkOverlap, bool checkIntersect, bool checkBig, int lineClusterId, Mat floormask)
{
    // Graph<int, DefaultEdge> clusterGraph =  DefaultUndirectedGraph<>(DefaultEdge.class);
    Graph clusterGraph;
    std::unordered_map<int, Vertex> contains;
    Vertex v1 = -1, v2 = -1;
    int nc = contours.size();
    for (int m = 0; m < nc; m++)
    {
        Contour contour1 = contours[m];
        vector<Line> line1s = contour1.getLines();
        for (int i = 0; i < line1s.size(); i++)
        {
            Line line1 = line1s[i];
            if (line1.getCluster() != lineClusterId)
            {
                continue;
            }
            for (int n = m + 1; n < nc; n++)
            {
                Contour contour2 = contours[n];
                vector<Line> line2s = contour2.getLines();
                int minJ = -1;
                double minDist = 100000;
                for (int j = 0; j < line2s.size(); j++)
                {
                    Line line2 = line2s[j];
                    if (line2.getCluster() != lineClusterId)
                    {
                        continue;
                    }
                    pair<bool, double> distanceInfo = checkDistanceBtwLines(line1, line2, distanceTh, checkOverlap, checkIntersect);
                    if (distanceInfo.first && distanceInfo.second < minDist)
                    {
                        minDist = distanceInfo.second;
                        minJ = j;
                    }
                }
                double diff = 90;
                if (minJ != -1)
                {
                    double angle1 = ((int)line1.angle() + 180) % 180;
                    double angle2 = ((int)contour2.getLines()[minJ].angle() + 180) % 180;
                    diff = fabs(angle1 - angle2);
                }
                if (minJ != -1 && (diff < 25 || diff > 155))
                {
                    int nodeId1 = AlignOptimizer::encodeNode(m, i);
                    int nodeId2 = AlignOptimizer::encodeNode(n, minJ);
                    if (contains.find(nodeId1) == contains.end())
                    {
                        v1 = add_vertex(clusterGraph);
                        clusterGraph[v1].index = nodeId1;
                        contains.insert({nodeId1, v1});
                    }
                    else
                    {
                        v1 = contains[nodeId1];
                    }
                    if (contains.find(nodeId2) == contains.end())
                    {
                        v2 = add_vertex(clusterGraph);
                        clusterGraph[v2].index = nodeId2;
                        contains.insert({nodeId2, v1});
                    }
                    else
                    {
                        v2 = contains[nodeId2];
                    }
                    if (!edge(v1, v2, clusterGraph).second)
                    {
                        add_edge(v1, v2, clusterGraph);
                    }
                }
            }
        }
    }
    return clusterGraph;
}

Graph buildBigGapGraph(vector<Contour> contours, int lineClusterId, Mat floormask)
{
    Graph gapGraph;
    double largeEdgeTh = 65;
    std::unordered_map<int, Vertex> contains;
    Vertex v1 = -1, v2 = -1;
    int nc = contours.size();
    for (int m = 0; m < nc; m++)
    {
        Contour contour1 = contours[m];
        vector<Line> line1s = contour1.getLines();
        for (int i = 0; i < line1s.size(); i++)
        {
            Line line1 = line1s[i];
            if (line1.getCluster() != lineClusterId)
            {
                continue;
            }
            for (int n = m + 1; n < nc; n++)
            {
                Contour contour2 = contours[n];
                vector<Line> line2s = contour2.getLines();
                int minJ = -1;
                double minDist = 100000;
                for (int j = 0; j < line2s.size(); j++)
                {
                    Line line2 = line2s[j];
                    if (line2.getCluster() != lineClusterId)
                    {
                        continue;
                    }
                    pair<bool, double> distanceInfo = checkDistanceBtwLines(line1, line2, distanceTh, true, false);
                    if (distanceInfo.first && distanceInfo.second < minDist)
                    {
                        minDist = distanceInfo.second;
                        minJ = j;
                    }
                }
                double diff = 90;
                if (minJ != -1)
                {
                    double angle1 = ((int)line1.angle() + 180) % 180;
                    double angle2 = ((int)contour2.getLines()[minJ].angle() + 180) % 180;
                    diff = fabs(angle1 - angle2);
                }
                if (minJ != -1 && line1.length() > largeEdgeTh && contour2.getLines()[minJ].length() > largeEdgeTh && minDist > 10 && (diff < 25 || diff > 155))
                {
                    if (checkGapOK(line1, contour2.getLines()[minJ], floormask))
                    {
                        int nodeId1 = AlignOptimizer::encodeNode(m, i);
                        int nodeId2 = AlignOptimizer::encodeNode(n, minJ);
                        if (contains.find(nodeId1) == contains.end())
                        {
                            v1 = add_vertex(gapGraph);
                            gapGraph[v1].index = nodeId1;
                            contains.insert({nodeId1, v1});
                        }
                        else
                        {
                            v1 = contains[nodeId1];
                        }
                        if (contains.find(nodeId2) == contains.end())
                        {
                            v2 = add_vertex(gapGraph);
                            gapGraph[v2].index = nodeId2;
                            contains.insert({nodeId2, v1});
                        }
                        else
                        {
                            v2 = contains[nodeId2];
                        }
                        if (!edge(v1, v2, gapGraph).second)
                        {
                            add_edge(v1, v2, gapGraph);
                        }
                    }
                }
            }
        }
    }

    vector<int> cp(num_vertices(gapGraph));
    int num = connected_components(gapGraph, &cp[0]);
    vector<std::unordered_set<int>> tempCluster(num);
    vertex_iter nodeId, v_end;
    for (tie(nodeId, v_end) = vertices(gapGraph); nodeId != v_end; ++nodeId)
    {
        tempCluster[cp[*nodeId]].insert(gapGraph[*nodeId].index);
    }

    for (int k = 0; k < num; k++)
    {
        std::unordered_set<int> ldkGroup = tempCluster[k];
        for (const int &nodeId : ldkGroup)
        {
            pair<int, int> nodeInfo = AlignOptimizer::decodeNode(nodeId);
            int contourId = nodeInfo.first;
            int lineId = nodeInfo.second;
            Line line1 = contours[contourId].getLines()[lineId];
            for (int n = 0; n < contours.size(); n++)
            {
                if (n == contourId)
                {
                    continue;
                }
                Contour contour2 = contours[n];
                vector<Line> line2s = contour2.getLines();
                for (int j = 0; j < line2s.size(); j++)
                {
                    Line line2 = line2s[j];
                    if (line2.getCluster() != lineClusterId)
                    {
                        continue;
                    }
                    pair<bool, double> distanceInfo = checkDistanceBtwLines(line1, line2, 10, true, true);
                    if (distanceInfo.first)
                    {
                        int targetNodeId = AlignOptimizer::encodeNode(n, j);
                        if (contains.find(targetNodeId) == contains.end())
                        {
                            v1 = add_vertex(gapGraph);
                            gapGraph[v1].index = targetNodeId;
                            contains.insert({targetNodeId, v1});
                        }
                        else
                        {
                            v1 = contains[targetNodeId];
                        }
                        v2 = contains[nodeId];
                        if (!edge(v1, v2, gapGraph).second)
                        {
                            add_edge(v1, v2, gapGraph);
                        }
                    }
                }
            }
        }
    }

    return gapGraph;
}

Graph buildSelfGraph(vector<Contour> contours, Mat floormask, int lineDistance)
{
    // Mat debugMat=binary2Show(floormask);
    // cvtColor(debugMat, debugMat, COLOR_GRAY2BGR);
    Graph gapGraph;
    double largeEdgeTh = lineDistance;
    std::unordered_map<int, Vertex> contains;
    Vertex v1 = -1, v2 = -1;
    int nc = contours.size();
    for (int m = 0; m < nc; m++)
    {
        Contour contour1 = contours[m];
        vector<Line> line1s = contour1.getLines();
        for (int i = 0; i < line1s.size(); i++)
        {
            Line line1 = line1s[i];
            for (int n = m; n < nc; n++)
            {
                Contour contour2 = contours[n];
                vector<Line> line2s = contour2.getLines();
                for (int j = 0; j < line2s.size(); j++)
                {
                    Line line2 = line2s[j];
                    pair<bool, double> distanceInfo = checkDistanceBtwLines(line1, line2, distanceTh, true, true);
                    // adjust the order of judgment conditions
                    double minDist1=min(getPointDist(line1.getU(),line2.getU()),getPointDist(line1.getU(),line2.getV()));
                    double minDist2=min(getPointDist(line1.getV(),line2.getU()),getPointDist(line1.getV(),line2.getV()));
                    double minDist=min(minDist1,minDist2);
                    if (distanceInfo.second < largeEdgeTh / 2 && (distanceInfo.first || minDist < largeEdgeTh))
                    {
                        double angle1 = ((int)line1.angle() + 180) % 180;
                        double angle2 = ((int)line2.angle() + 180) % 180;
                        double diff = fabs(angle1 - angle2);
                        if ((diff < 10 || diff > 170))
                        {
                            int nodeId1 = AlignOptimizer::encodeNode(m, i);
                            int nodeId2 = AlignOptimizer::encodeNode(n, j);
                            if (contains.find(nodeId1) == contains.end())
                            {
                                v1 = add_vertex(gapGraph);
                                gapGraph[v1].index = nodeId1;
                                contains.insert({nodeId1, v1});
                            }
                            else
                            {
                                v1 = contains[nodeId1];
                            }
                            if (contains.find(nodeId2) == contains.end())
                            {
                                v2 = add_vertex(gapGraph);
                                gapGraph[v2].index = nodeId2;
                                contains.insert({nodeId2, v1});
                            }
                            else
                            {
                                v2 = contains[nodeId2];
                            }
                            if (!edge(v1, v2, gapGraph).second)
                            {
                                add_edge(v1, v2, gapGraph);
                            }
                    //         mPoint pt1 = line1.getU();
                    //         mPoint pt2 = line1.getV();
                    //         cv::line(debugMat, cv::Point(pt1.x, pt1.y), cv::Point(pt2.x, pt2.y), Scalar(0, 0, 255), 3);
                    //         pt1 = line2.getU();
                    //         pt2 = line2.getV();
                    //         cv::line(debugMat, cv::Point(pt1.x, pt1.y), cv::Point(pt2.x, pt2.y), Scalar(0, 0, 255), 3);
                       }
                    }
                }
            }
        }
    }
    // imwrite("test.png",debugMat);

    return gapGraph;
}

pair<bool, double> checkDistanceBtwLines(Line line1, Line line2, int distanceGap, bool checkOverlap, bool checkIntersect)
{
    mPoint center = line1.center().add(line2.center());
    center.scale(0.5, 0.5);
    double distance = 0.0;
    if (line1.length() > line2.length())
    {
        distance = point2LineDistance(center, line1);
    }
    else
    {
        distance = point2LineDistance(center, line2);
    }
    if (distance > distanceGap / 2.0)
    {
        return pair<bool, double>(false, distance);
    }
    if (checkIntersect)
    {
        bool isIntersect = isLineBoundaryIntersect(line1, line2, intersectTh);
        if (isIntersect)
        {
            return pair<bool, double>(true, distance);
        }
    }
    if (checkOverlap)
    {
        mPoint proj1U = projPointOnLine(line1.getU(), line2);
        mPoint proj1V = projPointOnLine(line1.getV(), line2);
        mPoint proj2U = projPointOnLine(line2.getU(), line1);
        mPoint proj2V = projPointOnLine(line2.getV(), line1);
        
        bool isPoint1UOnLine2 = isPointProjectOnInnerSegment(proj1U, line2, overlapTh);
        bool isPoint1VonLine2 = isPointProjectOnInnerSegment(proj1V, line2, overlapTh);
        bool isPoint2UOnLine1 = isPointProjectOnInnerSegment(proj2U, line1, overlapTh);
        bool isPoint2VOnLine1 = isPointProjectOnInnerSegment(proj2V, line1, overlapTh);

        if (isPoint1UOnLine2 || isPoint1VonLine2 || isPoint2UOnLine1 || isPoint2VOnLine1)
        {
            return pair<bool, double>(true, distance);
        }
        if (getPointDist(proj1U, line2.getU()) < overlapTh && getPointDist(proj1V, line2.getV()) < overlapTh)
        {
            return pair<bool, double>(true, distance);
        }

        if (getPointDist(proj1U, line2.getV()) < overlapTh && getPointDist(proj1V, line2.getU()) < overlapTh)
        {
            return pair<bool, double>(true, distance);
        }
    }
    return pair<bool, double>(false, distance);
}

bool checkGapOK(Line line1, Line line2, Mat floorMask)
{

    int overlapDistTh = 60;
    int gapFreeTh = 600;
    mPoint proj1U = projPointOnLine(line1.getU(), line2);
    mPoint proj1V = projPointOnLine(line1.getV(), line2);
    mPoint proj2U = projPointOnLine(line2.getU(), line1);
    mPoint proj2V = projPointOnLine(line2.getV(), line1);

    bool isPoint1UOnLine2 = isPointProjectOnInnerSegment(proj1U, line2, overlapTh);
    bool isPoint1VOnLine2 = isPointProjectOnInnerSegment(proj1V, line2, overlapTh);
    bool isPoint2UOnLine1 = isPointProjectOnInnerSegment(proj2U, line1, overlapTh);
    bool isPoint2VOnLine1 = isPointProjectOnInnerSegment(proj2V, line1, overlapTh);
    bool intersect = false;
    if (isPoint1UOnLine2 || isPoint1VOnLine2 || isPoint2UOnLine1 || isPoint2VOnLine1)
    {
        intersect = true;
    }
    else if (getPointDist(proj1U, line2.getU()) < overlapTh && getPointDist(proj1V, line2.getV()) < overlapTh)
    {
        intersect = true;
    }
    else if (getPointDist(proj1U, line2.getV()) < overlapTh && getPointDist(proj1V, line2.getU()) < overlapTh)
    {
        intersect = true;
    }

    if (!intersect)
    {
        return false;
    }

    if (pointDot(proj1U.subtract(proj1V), line2.getU().subtract(line2.getV())) < 0)
    {
        mPoint tmp = proj1U;
        proj1U = proj1V;
        proj1V = tmp;
    }
    mPoint innerPoint1 = line2.getU();
    mPoint innerPoint2 = line2.getV();
    if (getPointDist(proj1U, line2.getV()) < getPointDist(line2.getU(), line2.getV()))
    {
        innerPoint1 = proj1U;
    }
    if (getPointDist(proj1V, line2.getU()) < getPointDist(line2.getV(), line2.getU()))
    {
        innerPoint2 = proj1V;
    }

    double overlapDist = getPointDist(innerPoint1, innerPoint2);
    if (overlapDist > overlapDistTh)
    {
        mPoint point3 = projPointOnLine(innerPoint1, line1);
        mPoint point4 = projPointOnLine(innerPoint2, line1);

        vector<mPoint> rectPoints;
        rectPoints.push_back(innerPoint1);
        rectPoints.push_back(innerPoint2);
        rectPoints.push_back(point4);
        rectPoints.push_back(point3);
        vector<cv::Point> rectContour = Contour::getContourFromPoints(rectPoints);
        Mat gapMask = Mat(floorMask.rows, floorMask.cols, CV_8UC1, Scalar(0));
        vector<vector<cv::Point>> rectContours;
        rectContours.push_back(rectContour);
        drawContours(gapMask, rectContours, -1, Scalar(1), FILLED);
        if (countNonZero(gapMask.mul(floorMask)) < gapFreeTh)
        {
            return true;
        }
    }
    return false;
}
