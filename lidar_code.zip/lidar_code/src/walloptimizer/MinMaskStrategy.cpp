#include "walloptimizer/MinMaskStrategy.h"
using namespace std;
using namespace cv;
using namespace boost;

bool checkContourValid(vector<Contour> contours)
{
    for (int i = 0; i < contours.size(); i++)
    {
        Contour contour = contours[i];
        vector<mPoint> pointList = contour.getContourPoints();
        Polygon *poly = createPolygon(pointList);
        if (!poly->isValid())
        {
            return false;
        }
    }
    return true;
}

Mat prepareInterMask(Mat floormask, std::unordered_set<int> cluster, vector<Contour> contours)
{
    Mat interMask = floormask.clone();
    for (const int &nodeId : cluster)
    {
        pair<int, int> nodeInfo = AlignOptimizer::decodeNode(nodeId);
        int contourId = nodeInfo.first;
        Contour contour = contours[contourId];
        vector<mPoint> contourPoints = contour.getContourPoints();

        if (contourPoints.size() == 0)
        {
            continue;
        }
        vector<cv::Point> contourCV = Contour::getContourFromPoints(contourPoints);
        vector<vector<cv::Point>> tmp;
        tmp.push_back(contourCV);
        drawContours(interMask, tmp, -1, Scalar(0), FILLED);
    }
    return interMask;
}

pair<double, pair<Line, Line>> getIntersectionBorder(std::unordered_set<int> cluster, vector<Contour> contours)
{
    vector<Line> lineList;
    for (const int &nodeId : cluster)
    {
        pair<int, int> nodeInfo = AlignOptimizer::decodeNode(nodeId);
        int contourId = nodeInfo.first;
        int lineId = nodeInfo.second;
        Line line = contours[contourId].getLines()[lineId];
        lineList.push_back(line);
    }
    double maxDistance = 0;
    pair<Line, Line> border = pair<Line, Line>(Line(), Line());
    for (int i = 0; i < lineList.size(); i++)
    {
        Line line1 = lineList[i];
        for (int j = i + 1; j < lineList.size(); j++)
        {
            Line line2 = lineList[j];
            double lineDist = point2LineDistance(line1.center(), line2);
            if (lineDist > maxDistance)
            {
                maxDistance = lineDist;
                border = pair<Line, Line>(line1, line2);
            }
        }
    }
    return pair<double, pair<Line, Line>>(maxDistance, border);
}

Geometry *buildOutlinePoly(vector<Contour> contours)
{

    vector<Geometry *> dilatedPolys;
    for (int i = 0; i < contours.size(); i++)
    {
        dilatedPolys.push_back(contours[i].getPoly()->buffer(1, 16, 3).release());
    }
    return geos::operation::geounion::UnaryUnionOp::Union(dilatedPolys).release();
}

Mat drawCursor(Mat cursorMask, Line cursor)
{
    mPoint point1 = cursor.getU();
    mPoint point2 = cursor.getV();
    line(cursorMask, cv::Point(point1.x, point1.y), cv::Point(point2.x, point2.y), Scalar(1), 1);
    return cursorMask;
}

Line prepareCursor(mPoint startPoint, std::unordered_set<int> cluster, vector<Contour> contours)
{
    vector<mPoint> points;
    for (const int &nodeId : cluster)
    {
        pair<int, int> nodeInfo = AlignOptimizer::decodeNode(nodeId);
        int contourId = nodeInfo.first;
        int lineId = nodeInfo.second;
        Line line = contours[contourId].getLines()[lineId].copy();
        mPoint projPoint = projPointOnLine(startPoint, line);
        mPoint direction = startPoint.subtract(projPoint);
        line.move(direction.x, direction.y);
        points.push_back(line.getU());
        points.push_back(line.getV());
    }
    pair<mPoint, mPoint> maxPair = pair<mPoint, mPoint>(mPoint(), mPoint());
    double maxDist = 0;
    for (int i = 0; i < points.size(); i++)
    {
        for (int j = i + 1; j < points.size(); j++)
        {
            double pointDist = getPointDist(points[i], points[j]);
            if (pointDist > maxDist)
            {
                maxDist = pointDist;
                maxPair = pair<mPoint, mPoint>(points[i], points[j]);
            }
        }
    }
    if (maxDist > 0)
    {
        return Line(NULL, -1, maxPair.first, maxPair.second, -1, -1);
    }
    return Line(NULL, -1, startPoint, startPoint, -1, -1);
}

pair<mPoint, int> findBestCursorPoint(Mat interMask, Line cursor, mPoint step, int sampleNum)
{
    int minLoss = 10000000;
    mPoint bestPoint = mPoint();
    double stepDist = sqrt(step.x * step.x + step.y * step.y);
    double padDist = 10;

    if (step.x == 0 && step.y == 0)
    {
        Mat lineMask = Mat(interMask.rows, interMask.cols, CV_8UC1, Scalar(0));
        lineMask = drawCursor(lineMask, cursor);
        int loss = countNonZero(lineMask.mul(interMask));
        return pair<mPoint, int>(cursor.center(), loss);
    }

    int padNum = (int)(padDist / stepDist);
    for (int i = 0; i < padNum; i++)
    {
        cursor.move(-step.x, -step.y);
    }
    for (int i = 0; i < sampleNum + padNum * 2; i++)
    {
        Mat lineMask = Mat(interMask.rows, interMask.cols, CV_8UC1, Scalar(0));
        lineMask = drawCursor(lineMask, cursor);
        int loss = countNonZero(lineMask.mul(interMask));
        if (loss < minLoss)
        {
            minLoss = loss;
            bestPoint = cursor.center();
        }
        cursor.move(step.x, step.y);
    }
    return pair<mPoint, int>(bestPoint, minLoss);
}

int getLineLoss(Mat interMask, Line line)
{
    Mat lineMask = Mat(interMask.rows, interMask.cols, CV_8UC1, Scalar(0));
    lineMask = drawCursor(lineMask, line);
    int loss = countNonZero(lineMask.mul(interMask));
    return loss;
}

vector<int> getClusterLosses(Mat interMask, vector<Contour> contours, std::unordered_set<int> cluster)
{
    vector<int> losses;
    for (const int &nodeId : cluster)
    {
        pair<int, int> nodeInfo = AlignOptimizer::decodeNode(nodeId);
        int contourId = nodeInfo.first;
        int lineId = nodeInfo.second;
        int lineLoss = getLineLoss(interMask, contours[contourId].getLines()[lineId]);
        losses.push_back(lineLoss);
    }
    return losses;
}

int getContourCoverMaskArea(Mat floorMask, vector<Contour> contours)
{
    Mat contourMask = Mat(floorMask.rows, floorMask.cols, CV_8UC1, Scalar(0));
    vector<vector<cv::Point>> contourCVs;
    for (int i = 0; i < contours.size(); i++)
    {
        vector<mPoint> points;
        vector<Line> lines = contours[i].getLines();
        for (int j = 0; j < lines.size(); j++)
        {
            points.push_back(lines[j].getU());
        }
        vector<cv::Point> contourCV = Contour::getContourFromPoints(points);
        contourCVs.push_back(contourCV);
    }
    drawContours(contourMask, contourCVs, -1, Scalar(1), FILLED);
    return countNonZero(contourMask.mul(floorMask));
}

bool checkLongBoundaryLine(Geometry *outline, Line line, int dx, int dy)
{
    int maxDist = max(fabs(dx), fabs(dy));
    int LINE_LENGTH_TH = 235;
    int MOVE_TH = 35;
    int deltaX = (int)round(dx / (maxDist / 5.0));
    int deltaY = (int)round(dy / (maxDist / 5.0));

    if (maxDist < MOVE_TH || line.length() < LINE_LENGTH_TH)
    {
        return false;
    }
    Line targetLine = line.copy();
    for (int i = 0; i < 80; i++)
    {
        targetLine.move(deltaX, deltaY);
        Line shrinkLine1 = shrinkLine(targetLine, 0.95);
        CoordinateSequence coords(2);
        coords[0] = Coordinate(shrinkLine1.getU().x, shrinkLine1.getU().y);
        coords[1] = Coordinate(shrinkLine1.getV().x, shrinkLine1.getV().y);
        LineString *lineString = createLineString(coords);

        if (outline->intersects(lineString))
        {
            return false;
        }
    }
    return true;
}

void MinMaskStrategy(Mat floormask, vector<Contour> &origContours, Graph clusterGraph, bool byUniqueContour)
{

    int sampleNum = 10;
    int interLineWidthTh = 175;
    int maskAreaTh = -700;
    vector<Contour> contours;
    for (int i = 0; i < origContours.size(); i++)
    {
        contours.push_back(origContours[i].copy());
    }
    vector<int> cp(num_vertices(clusterGraph));
    int num = connected_components(clusterGraph, &cp[0]);
    vector<std::unordered_set<int>> tempCluster(num);
    vertex_iter nodeId, v_end;
    for (tie(nodeId, v_end) = vertices(clusterGraph); nodeId != v_end; ++nodeId)
    {
        tempCluster[cp[*nodeId]].insert(clusterGraph[*nodeId].index);
    }
    int lossTh = 10;

    for (int i = 0; i < num; i++)
    {
        // std::unordered_set<int> cluster = connectedSet[i];
        std::unordered_set<int> cluster = tempCluster[i];

        Geometry *outline = buildOutlinePoly(contours);
        if (cluster.size() == 1)
        {
            continue;
        }
        if (byUniqueContour && AlignOptimizer::checkConflictInCluster(cluster, contours))
        {
            continue;
        }
        pair<double, pair<Line, Line>> borderInfo = getIntersectionBorder(cluster, contours);
        double borderDist = borderInfo.first;
        Line border1 = borderInfo.second.first;
        Line border2 = borderInfo.second.second;
        if (borderDist < 1)
        {
            continue;
        }
        if (borderDist < 13)
        {
            lossTh = 100;
        }

        // Mat interMask = prepareInterMask(floormask, cluster, contours);
        Mat interMask = floormask.clone();
        vector<int> currentLosses = getClusterLosses(interMask, contours, cluster);
        int currentCoverArea = getContourCoverMaskArea(floormask, contours);

        vector<Line> doorLines;
        for (const int &nodeId : cluster)
        {
            pair<int, int> nodeInfo = AlignOptimizer::decodeNode(nodeId);
            int contourId = nodeInfo.first;
            int lineId = nodeInfo.second;
            Line line = contours[contourId].getLines()[lineId];
            if (line.isHasDoor())
            {
                doorLines.push_back(line);
            }
        }

        mPoint point1 = border2.center();
        mPoint point2 = projPointOnLine(point1, border1);
        if (doorLines.size() >= 1)
        {
            Line doorLine = doorLines[0];
            int lineAngle = ((int)doorLine.angle() + 180) % 180;
            mPoint doorPoint = doorLine.center();
            if (lineAngle < 10 || lineAngle > 170)
            {
                point1 = doorPoint.add(mPoint(-10, 0));
                point2 = doorPoint.add(mPoint(10, 0));
            }
            else if (lineAngle > 80 && lineAngle < 100)
            {
                point1 = doorPoint.add(mPoint(0, -10));
                point2 = doorPoint.add(mPoint(0, 10));
            }
        }
        mPoint diff = point2.subtract(point1);
        mPoint dc = mPoint(diff.x / 10, diff.y / 10);
        Line cursor = prepareCursor(point1, cluster, contours);
        pair<mPoint, int> bestInfo = findBestCursorPoint(interMask, cursor, dc, sampleNum);
        mPoint bestPoint = bestInfo.first;
        int bestLoss = bestInfo.second;
        if (bestLoss > interLineWidthTh)
        {
            continue;
        }

        std::unordered_map<int, pair<int, int>> moveMap;
        bool moveLongOutLine = false;
        for (const int &nodeId : cluster)
        {
            pair<int, int> nodeInfo = AlignOptimizer::decodeNode(nodeId);
            int contourId = nodeInfo.first;
            int lineId = nodeInfo.second;
            Line line = contours[contourId].getLines()[lineId];
            mPoint moveDirection = projPointOnLine(bestPoint, line).subtract(bestPoint);

            moveMap.insert({nodeId, pair<int, int>(-moveDirection.x, -moveDirection.y)});
            if (checkLongBoundaryLine(outline, line, -moveDirection.x, -moveDirection.y))
            {
                moveLongOutLine = true;
                break;
            }
        }
        if (moveLongOutLine)
        {
            continue;
        }

        bool lossBig = false;
        vector<Contour> tentativeContours;
        for (int step = 0; step < 10; step++)
        {
            tentativeContours.clear();
            for (int k = 0; k < contours.size(); k++)
            {
                tentativeContours.push_back(contours[k].copy());
            }
            for (const int &nodeId : cluster)
            {
                pair<int, int> nodeInfo = AlignOptimizer::decodeNode(nodeId);
                int contourId = nodeInfo.first;
                int lineId = nodeInfo.second;
                vector<Line> lines = tentativeContours[contourId].getLines();
                Line &line = lines[lineId];
                int dx = moveMap[nodeId].first;
                int dy = moveMap[nodeId].second;
                line.move((int)round(dx * (step + 1) / 10.0), (int)round(dy * (step + 1) / 10.0));
                tentativeContours[contourId].setLines(lines);
            }
            vector<int> moveLosses = getClusterLosses(interMask, tentativeContours, cluster);
            for (int k = 0; k < moveLosses.size(); k++)
            {
                if (moveLosses[k] - currentLosses[k] > lossTh)
                {
                    lossBig = true;
                    break;
                }
            }
            if (lossBig)
            {
                break;
            }
        }
        if (lossBig)
        {
            continue;
        }
        if (!checkContourValid(tentativeContours))
        {
            continue;
        }
        else
        {
            int nowCoverArea = getContourCoverMaskArea(floormask, tentativeContours);
            if (nowCoverArea - currentCoverArea < maskAreaTh)
            {
                continue;
            }
        }
        for (int k = 0; k < contours.size(); k++)
        {
            contours[k] = tentativeContours[k];
        }
    }
    for (int k = 0; k < contours.size(); k++)
    {
        origContours[k] = contours[k];
    }
}