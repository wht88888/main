#include "walloptimizer/CenterPointStrategy.h"
using namespace std;
using namespace cv;
using namespace boost;
void CenterPointStrategy(Mat floormask, vector<Contour> &contours, Graph clusterGraph, bool byUniqueContour, int threshold)
{
    vector<int> cp(num_vertices(clusterGraph));
    int num = connected_components(clusterGraph, &cp[0]);
    vector<std::unordered_set<int>> tempCluster(num);
    vertex_iter nodeId, v_end;
    for (tie(nodeId, v_end) = vertices(clusterGraph); nodeId != v_end; ++nodeId)
    {
        tempCluster[cp[*nodeId]].insert(clusterGraph[*nodeId].index);
    }
    for (int i = 0; i < num; i++)
    {
        std::unordered_set<int> cluster = tempCluster[i];

        if (byUniqueContour && AlignOptimizer::checkConflictInCluster(cluster, contours))
        {
            continue;
        }
        int centerX = 0;
        int centerY = 0;
        for (const int &nodeId : cluster)
        {
            pair<int, int> nodeInfo = AlignOptimizer::decodeNode(nodeId);
            int contourId = nodeInfo.first;
            int lineId = nodeInfo.second;
            if (contourId == -1 || lineId == -1)
            {
            }
            Line line = contours[contourId].getLines()[lineId];
            mPoint lineCenter = line.center();
            centerX += lineCenter.x;
            centerY += lineCenter.y;
        }
        centerX = round(centerX / (float)cluster.size());
        centerY = round(centerY / (float)cluster.size());
        mPoint centerPoint = mPoint(centerX, centerY);
        for (const int &nodeId : cluster)
        {
            pair<int, int> nodeInfo = AlignOptimizer::decodeNode(nodeId);
            int contourId = nodeInfo.first;
            int lineId = nodeInfo.second;
            vector<Line> lines = contours[contourId].getLines();
            if (lines[lineId].length() < 2)
            {
                continue;
            }
            mPoint centerProj = projPointOnLine(centerPoint, lines[lineId]);
            mPoint dir = centerPoint.subtract(centerProj);
            if (getNorm(dir) > threshold)
            {
                continue;
            }
            lines[lineId].move(dir.x, dir.y);
            contours[contourId].setLines(lines);
        }
    }
}