#include "walloptimizer/ExternalWallOptimizer.h"
using namespace std;
using namespace cv;

void ExternalWallOptimizer::run(vector<Contour> &contours, int wallBuffer)
{
    externalWallBuffer = wallBuffer;
    vector<Line> extremes = getExtremes(contours);
    moveLineToExtreme(contours, extremes);
}

vector<Line> ExternalWallOptimizer::getExtremes(vector<Contour> contours)
{
    if (contours.size() == 0)
    {
        vector<Line> v;
        return v;
    }

    vector<Line> allLines;
    for (int i = 0; i < contours.size(); i++)
    {
        for(int j=0;j<contours[i].getLines().size();j++){
            allLines.push_back(contours[i].getLines()[j]);
        }
    }
    vector<Line> lines;
    for (int i = 0; i < allLines.size(); i++)
    {
        if (allLines[i].length() > 5)
        {
            if (((int)allLines[i].angle() + 180) % 90 < 10 || ((int)allLines[i].angle() + 180) % 90 > 80)
            {
                lines.push_back(allLines[i]);
            }
        }
    }

    if (lines.size() == 0)
    {
        vector<Line> v;
        return v;
    }
    int maxX = 0;
    int minX = 10000;
    int maxY = 0;
    int minY = 10000;
    int maxXid;
    int minXid;
    int maxYid;
    int minYid;
    for (int i = 0; i < lines.size(); i++)
    {
        if (lines[i].center().x > maxX)
        {
            maxX = lines[i].center().x;
            maxXid = i;
        }
        if (lines[i].center().x < minX)
        {
            minX = lines[i].center().x;
            minXid = i;
        }
        if (lines[i].center().y > maxY)
        {
            maxY = lines[i].center().y;
            maxYid = i;
        }
        if (lines[i].center().y < minY)
        {
            minY = lines[i].center().y;
            minYid = i;
        }
    }
    Line maxXLine = lines[maxXid];
    Line minXLine = lines[minXid];
    Line maxYLine = lines[maxYid];
    Line minYLine = lines[minYid];
    vector<Line> extremes;
    extremes.push_back(maxXLine);
    extremes.push_back(minXLine);
    extremes.push_back(maxYLine);
    extremes.push_back(minYLine);
    return extremes;
}

void ExternalWallOptimizer::moveLineToExtreme(vector<Contour> &contours, vector<Line> extremes)
{
    for (int i = 0; i < extremes.size(); i++)
    {
        Line extreme = extremes[i];
        for (int m = 0; m < contours.size(); m++)
        {
            Contour &contour = contours[m];
            vector<Line> lines = contour.getLines();
            double minDist = 1000000;
            bool flag = false;
            int minid=0;
            for (int n = 0; n < lines.size(); n++)
            {
                Line line = lines[n];
                if (((int)line.angle() + 180) % 90 < 10 || ((int)line.angle() + 180) % 90 > 80)
                {
                    double distance = point2LineDistance(line.center(), extreme);
                    if (distance < minDist)
                    {
                        minDist = distance;
                        minid = n;
                        flag = true;
                    }
                }
            }
            if (flag && minDist < externalWallBuffer)
            {
                mPoint moveDir = projPointOnLine(lines[minid].center(), extreme).subtract(lines[minid].center());
                lines[minid].move(moveDir.x, moveDir.y);
            }
            contour.setLines(lines);
        }
    }
}