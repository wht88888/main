#include "walloptimizer/AlignOptimizer.h"
using namespace std;
using namespace boost;

cv::Mat AlignOptimizer::getSemMask(SegmentInfo segmentInfo)
{
    return segmentInfo.getFloorMask().clone();
}

void AlignOptimizer::run(vector<Contour> &contours, cv::Mat floorMask, int supportLineClusterNum, int threshold, bool checkOverlap, bool checkIntersect, bool gapCheck, AlignStrategy strategy, bool byUniqueContour, bool checkLDK, bool checkSelf)
{
    // std::unordered_map<int, Graph<int, DefaultEdge>> graphDict = clusterFinder.run(contours, supportLineClusterNum, floorMask, threshold, checkOverlap, checkIntersect, gapCheck);

    std::unordered_map<int, Graph> graphDict = RoomClusterFinder(contours, supportLineClusterNum, floorMask, threshold, checkOverlap, checkIntersect, gapCheck, checkLDK, checkSelf);
    for (const auto& entry : graphDict)
    {
        Graph clusterGraph = entry.second;
        if (strategy == CENTER_POINT)
        {
            CenterPointStrategy(floorMask, contours, clusterGraph, byUniqueContour, threshold);
        }
        else if (strategy == MIN_MASK)
        {
            MinMaskStrategy(floorMask, contours, clusterGraph, byUniqueContour);
        }
    }
}

int AlignOptimizer::encodeNode(int contourId, int lineId)
{
    return ((contourId + 1) << 16) + lineId + 1;
}

pair<int, int> AlignOptimizer::decodeNode(int nodeId)
{
    int contourId = nodeId >> 16;
    int lineId = nodeId - (contourId << 16);
    return pair<int, int>(contourId - 1, lineId - 1);
}

bool AlignOptimizer::checkConflictInCluster(std::unordered_set<int> cluster, vector<Contour> contours)
{
    std::unordered_map<int, int> node2ContourCounter;
   for(const int& nodeId:cluster)
    {
        pair<int, int> nodeInfo = decodeNode(nodeId);
        int contourId = nodeInfo.first;
        if (node2ContourCounter.find(contourId)!=node2ContourCounter.end())
        {
            node2ContourCounter.insert({contourId, node2ContourCounter[contourId] + 1});
        }
        else
        {
            node2ContourCounter.insert({contourId, 1});
        }
    }
    vector<int> conflictContours;
    for (const auto& entry: node2ContourCounter)
    {
        if (entry.second > 1)
        {
            conflictContours.push_back(entry.first);
        }
    }

    for (int i = 0; i < conflictContours.size(); i++)
    {
        vector<pair<int, int>> conflictNodes;
        int conflictContourId = conflictContours[i];
        for(const int&nodeId : cluster){
            pair<int, int> nodeInfo = decodeNode(nodeId);
            int contourId = nodeInfo.first;
            if (contourId == conflictContourId)
            {
                conflictNodes.push_back(nodeInfo);
            }
        }

        for (int m = 0; m < conflictNodes.size(); m++)
        {
            pair<int, int> node1Info = conflictNodes[m];
            int contour1Id = node1Info.first;
            int line1Id = node1Info.second;
            Line line1 = contours[contour1Id].getLines()[line1Id];
            for (int n = m + 1; n < conflictNodes.size(); n++)
            {
                pair<int, int> node2Info = conflictNodes[n];
                int contour2Id = node2Info.first;
                int line2Id = node2Info.second;
                Line line2 = contours[contour2Id].getLines()[line2Id];
                mPoint line1Center = line1.center();
                bool isOverlap = isPointProjectOnInnerSegment(line1Center, line2, 5);
                if (isOverlap)
                {
                    return true;
                }
            }
        }
    }
    return false;
}

void AlignOptimizer::removeIncludedAngle(vector<Contour> &contours, double lenTH, double angle1, double angle2, bool isLdk, bool useCenter, cv::Mat mask)
{
    // if 2 angles between 3 lines satisfy the parameter angle1 and angle2, fix them
    int nc = contours.size();
    for (int m = 0; m < nc; m++)
    {
        if (isLdk)
        {
            if (contours[m].getLabel()!="LDK")
            {
                continue;
            }
        }
        vector<Line> lines = contours[m].getLines();
        for (int i = 0; i < lines.size(); i++)
        {
            Line &line1 = lines[i];
            if (line1.length() < lenTH)
            {
                int before = i - 1;
                if (before == -1)
                {
                    before = lines.size() - 1;
                }
                int after = i + 1;
                if (after == lines.size())
                {
                    after = 0;
                }
                if (line1.isHasDoor())
                {
                    continue;
                }
                Line &lineAfter = lines[after];
                Line &lineBefore = lines[before];
                double diff1 = lineIntersectionAngle(line1, lineAfter);
                double diff2 = lineIntersectionAngle(line1, lineBefore);
                if ((diff1 > angle1 - 10 && diff1 < angle1 + 10) && (diff2 > angle2 - 10 && diff2 < angle2 + 10))
                {
                    makeIntersection(line1, lineBefore, lineAfter, mask, useCenter);
                }
                else if ((diff2 > angle1 - 10 && diff2 < angle1 + 10) && (diff1 > angle2 - 10 && diff1 < angle2 + 10))
                {
                    makeIntersection(line1, lineBefore, lineAfter, mask, useCenter);
                }
            }
        }
        contours[m].setLines(lines);
    }
}

void AlignOptimizer::makeIntersection(Line &line1, Line &lineBefore, Line &lineAfter, cv::Mat mask, bool useCenter)
{
    // get the intersection of lineAfter and lineBefore, remove line1
    pair<mPoint, bool> p = getIntersection(lineAfter, lineBefore);
    mPoint point = p.first;

    //        if(!isPointProjectOnInnerSegment(point,lineBefore,0)&&!isPointProjectOnInnerSegment(point,lineAfter,0))
    //            return;
    bool flag = true;
    int choose = 0;
    if (p.second)
    {
        if (point2LineDistance(lineAfter.getU(), line1) > point2LineDistance(lineAfter.getV(), line1))
        {
            choose = 1;
            mPoint center = getCenter(point, lineAfter.getV());
            center = inMask(center, mask);
            if (useCenter && mask.at<uchar>((int)center.y, (int)center.x) > 0)
            {
                flag = false;
            }
        }
        else
        {
            choose = 2;
            mPoint center = getCenter(point, lineAfter.getU());
            center = inMask(center, mask);
            if (useCenter && mask.at<uchar>((int)center.y, (int)center.x) > 0)
            {
                flag = false;
            }
        }
        if (!flag)
            return;
        if (point2LineDistance(lineBefore.getU(), line1) > point2LineDistance(lineBefore.getV(), line1))
        {
            choose += 10;
            mPoint center = getCenter(point, lineBefore.getV());
            center = inMask(center, mask);
            if (useCenter && mask.at<uchar>((int)center.y, (int)center.x) > 0)
            {
                flag = false;
            }
        }
        else
        {
            choose += 20;
            mPoint center = getCenter(point, lineBefore.getU());
            center = inMask(center, mask);
            if (useCenter && mask.at<uchar>((int)center.y, (int)center.x) > 0)
            {
                flag = false;
            }
        }
        if (flag)
        {
            if (choose % 10 == 1)
                lineAfter.setV(point);
            else
                lineAfter.setU(point);
            if (choose / 10 == 1)
                lineBefore.setV(point);
            else
                lineBefore.setU(point);
        }
        line1.setU(point);
        line1.setV(point);
    }
}

mPoint AlignOptimizer::getCenter(mPoint p1, mPoint p2)
{
    mPoint p = mPoint((p1.x + p2.x) / 2, (p1.y + p2.y) / 2);
    return p;
}
mPoint AlignOptimizer::inMask(mPoint point, cv::Mat mask)
{
    // if point is out of mask, reset it
    if (point.x >= mask.cols)
        point.x = mask.cols - 1;
    else if (point.x < 0)
    {
        point.x = 0;
    }
    if (point.y >= mask.rows)
        point.y = mask.rows - 1;
    else if (point.y < 0)
    {
        point.y = 0;
    }
    return point;
}

void AlignOptimizer::fixRightAngle(vector<Contour> &contours)
{
    // if the angle between 2 lines is not 45 or 90 or 135 ... fix them
    int nc = contours.size();
    for (int m = 0; m < nc; m++)
    {
        vector<Line> lines = contours[m].getLines();
        for (int i = 0; i < lines.size(); i++)
        {
            int after = i + 1;
            if (after == lines.size())
            {
                after = 0;
            }
            double diff1 = lineIntersectionAngle(lines[i], lines[after]);
            if ((diff1 > 0 && diff1 < 30) || (diff1 > 60 && diff1 < 90) || (diff1 > 90 && diff1 < 120) || (diff1 > 150 && diff1 < 180))
            {
                double angle1 = lines[i].angle();
                double angle2 = lines[after].angle();
                double remainder1 = fabs(fmod(angle1,45.0)-22.5);
                double remainder2 = fabs(fmod(angle2,45.0)-22.5);
                bool is_changed=false;
                if (remainder1 < remainder2)
                {
                    Line temp = lines[i];
                    lines[i] = lines[after];
                    lines[after] = temp;
                    is_changed=true;
                }
                mPoint point;
                if (point2LineDistance(lines[after].getU(), lines[i]) > point2LineDistance(lines[after].getV(), lines[i]))
                {
                    point = projPointOnLine(lines[after].getU(), lines[i]);
                    lines[after].setV(point);
                }
                else
                {
                    point = projPointOnLine(lines[after].getV(), lines[i]);
                    lines[after].setU(point);
                }
                if (point2LineDistance(lines[i].getU(), lines[after]) > point2LineDistance(lines[i].getV(), lines[after]))
                {
                    lines[i].setV(point);
                }
                else
                {
                    lines[i].setU(point);
                }
                if(is_changed){
                    Line temp = lines[i];
                    lines[i] = lines[after];
                    lines[after] = temp;
                    is_changed=false;
                }
            }
        }
        contours[m].setLines(lines);
    }
}