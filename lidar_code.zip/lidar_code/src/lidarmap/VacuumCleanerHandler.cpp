#include "lidarmap/VacuumCleanerHandler.h"
#include "time.h"

using namespace std;
using namespace cv;
using json = nlohmann::json;

double angleTh = 30;

double HandlerMinDoorWidth = 20;

int externalWallTh = 40;

Line resizeDoor(Line door) {
        if (door.length() < HandlerMinDoorWidth) {
            double scaleCoeff = HandlerMinDoorWidth / door.length();
            mPoint doorCenter = door.center();
            mPoint u = door.getU();
            mPoint v = door.getV();
            u = u.subtract(door.center());
            v = v.subtract(door.center());
            u.scale(scaleCoeff, scaleCoeff);
            v.scale(scaleCoeff, scaleCoeff);
            door.setU(u.add(doorCenter));
            door.setV(v.add(doorCenter));
        }
        return door;
    }

vector<Line> convertDoor2Line(SegmentInfo segmentInfo) {
        vector<DoorLine> doorLines = segmentInfo.getDoors();
        vector<Line> lines;
        for(int i=0;i<doorLines.size();i++){
            mPoint u(doorLines[i].getStartNodeCoord().first,doorLines[i].getStartNodeCoord().second);
            mPoint v(doorLines[i].getEndNodeCoord().first,doorLines[i].getEndNodeCoord().second);
            Line l(NULL,-1,u,v,-1,-1);
            lines.push_back(l);
        }
        return lines;

    }

vector<Line> processOpenable(vector<Contour> contours, vector<Line> doors) {
        fitOpenables(contours, doors, false, 1);
        vector<Line> openableContours;
        for(int i=0;i<doors.size();i++){
            if(doors[i].length()>0.1){
                openableContours.push_back(doors[i]);
            }
        }
        vector<Line> result;
        for(int i=0;i<openableContours.size();i++){
            result.push_back(resizeDoor(openableContours[i]));
        }
        return result;
    }

void fitOpenables(vector<Contour> contours, vector<Line>& doors, bool updateLine,int threhold) {
        vector<Line> roomLines;
        for (int i = 0; i < contours.size(); i++) {
            vector<Line> tempLines=contours[i].getLines();
            for(int j=0;j<tempLines.size();j++){
                roomLines.push_back(tempLines[j]);
            }
        }
        if (updateLine) {
            for (int i = 0; i < roomLines.size(); i++) {
                roomLines[i].setHasDoor(false);
            }
        }
        for (int i = 0; i < doors.size(); i++) {
            Line& door = doors[i];
            double minDist = 100000;
            int minId = -1;
            vector<int> cnt;
            vector<double> dists;
            for (int j = 0; j < roomLines.size(); j++) {
                cnt.push_back(0);
                dists.push_back(-2.0);
            }
            for (int j = 0; j < roomLines.size(); j++) {
                Line roomLine = roomLines[j];
                double dist = point2LineDistance(door.center(), roomLine);
                if(isPointProjectOnInnerSegment(door.center(), roomLine, 0) && dist<50){
                    dists[j]=dist;
                }
            }
            for (int j = 0; j < roomLines.size(); j++) {
                if(dists[j]==-2)
                    continue;
                for (int k = 0; k < roomLines.size(); k++) {
                    if(dists[k]==-2)
                        continue;
                    if(fabs(dists[k]-dists[j])<3){
                        cnt[j]=cnt[j]+1;
                    }
                }
            }
            for (int j = 0; j < roomLines.size(); j++) {
                Line roomLine = roomLines[j];
                if(dists[j]>-1){
                }
                if (dists[j] < minDist && isPointProjectOnInnerSegment(door.center(), roomLine, 0) && cnt[j] >= threhold) {
                    minDist = dists[j];
                    minId = j;
                }
            }
            int minId2=-1;
            if(minId!=-1){
                for (int j = 0; j < roomLines.size()&&j!=minId; j++) {
                    if(fabs(dists[minId]-dists[j])<3){
                        minId2=j;
                    }
                }
            }
            if (minDist < 50) {
                Line projLine = roomLines[minId];
                if (updateLine) {
                    projLine.setHasDoor(true);
                }
                if(minId2!=-1){
                    Line projLine2=roomLines[minId2];
                    if (updateLine) {
                        projLine2.setHasDoor(true);
                    }
                }
                mPoint doorU = projPointOnLine(door.getU(), projLine);
                mPoint doorV = projPointOnLine(door.getV(), projLine);
                if(getPointDist(doorU,doorV)<2){
                    doorV.x=doorU.x;
                    doorV.y=doorU.y;
                }
                if(samePoint(doorU,doorV)){
                    double angle=projLine.angle();
                    if(angle<25){
                        doorU.x+=2;
                    }
                    else if (angle>=25&&angle<=65){
                        doorU.x+=2;
                        doorU.y+=2;
                    }
                    else if (angle>65&&angle<115){
                        doorU.y+=2;
                    }
                    else if (angle>=115&&angle<=155){
                        doorU.x-=2;
                        doorU.y+=2;
                    }
                    else if (angle>155){
                        doorU.x-=2;
                    }
                }
                door.setU(doorU);
                door.setV(doorV);
            }
        }
    }

pair<vector<Contour>,vector<Line>> fitFloorPlan(SegmentInfo segmentInfo, vector<Contour> contours, HoughSupportLine sl)
{
    AlignOptimizer wallOptimizer=AlignOptimizer();
    ExternalWallOptimizer ex = ExternalWallOptimizer();
    AlignOptimizer align = AlignOptimizer();
    removeNotContour(contours);
    ex.run(contours, 40);
    int lineClusterNum = sl.getClusterValues().size();
    for (int i = 0; i < contours.size(); i++)
    {
        contours[i].commit(lineClusterNum, contours[i].FIX_ANGLE, 5, 177, 3);
    }
    Mat floorMask = segmentInfo.getFloorMask();
    wallOptimizer.run(contours, floorMask, lineClusterNum, 10, true, true, false, AlignOptimizer::AlignStrategy::CENTER_POINT, false, false, false);
    for (int i = 0; i < contours.size(); i++)
    {
        contours[i].commit(lineClusterNum, contours[i].FIX_ANGLE, 5, 177, 3);
        classifyLines(contours[i], sl.getClusterValues(), angleTh);
    }

    removeNotContour(contours);
    contours = DoubleOverlapSolver(segmentInfo, contours);
    for (int i = 0; i < contours.size(); i++)
    {
        contours[i].updateLines();
        contours[i].commit(lineClusterNum, contours[i].FIX_ANGLE, 5, 177, 3);
        classifyLines(contours[i], sl.getClusterValues(), angleTh);
    }
    removeNotContour(contours);

    vector<Line> doors = convertDoor2Line(segmentInfo);

    vector<Line> openableContours = processOpenable(contours, doors);
    
    contours = SlopeLineCutter(contours, floorMask, sl, segmentInfo);
    for (int i = 0; i < contours.size(); i++)
    {
        contours[i].updateLines();
        contours[i].commit(lineClusterNum, contours[i].FIX_ANGLE, 5, 177, 3);
        classifyLines(contours[i], sl.getClusterValues(), angleTh);
    }
    removeNotContour(contours);
    contours=GroupMerger(contours);
    for (int i = 0; i < contours.size(); i++)
    {
        contours[i].updateLines();
        contours[i].commit(lineClusterNum, contours[i].FIX_ANGLE, 5, 177, 3);
        classifyLines(contours[i], sl.getClusterValues(), angleTh);
    }
    removeNotContour(contours);
    double time1=clock();

    wallOptimizer.run(contours, floorMask, lineClusterNum, 30, true, true, false, AlignOptimizer::AlignStrategy::MIN_MASK, true, false, false);
    classifyLinesAndCommit(contours,sl,lineClusterNum);
    double time2=clock();
    cout<<"wallOptimizer1:"<<(time2-time1)/CLOCKS_PER_SEC<<endl;

    contours = RoomCutterBywalls(contours, floorMask);
    double time3=clock();
    cout<<"RoomCutterBywalls:"<<(time3-time2)/CLOCKS_PER_SEC<<endl;

    contours=rectifyLDK(contours, sl);    
    for (int i = 0; i < contours.size(); i++)
    {
        contours[i].updateLines();
        contours[i].commit(lineClusterNum, contours[i].FIX_ANGLE, 5, 177, 3);
        classifyLines(contours[i], sl.getClusterValues(), angleTh);
    }
    removeNotContour(contours);
    double time4=clock();
    cout<<"rectifyLDK:"<<(time4-time3)/CLOCKS_PER_SEC<<endl;

    wallOptimizer.run(contours, floorMask, lineClusterNum, 10, true, true, false, AlignOptimizer::AlignStrategy::CENTER_POINT, true, false, false);
    classifyLinesAndCommit(contours,sl,lineClusterNum);
    double time5=clock();
    cout<<"wallOptimizer2:"<<(time5-time4)/CLOCKS_PER_SEC<<endl;

    wallOptimizer.run(contours, floorMask, lineClusterNum, 35, true, true, false, AlignOptimizer::AlignStrategy::MIN_MASK, true, false, false);
    classifyLinesAndCommit(contours,sl,lineClusterNum);
    double time6=clock();
    cout<<"wallOptimizer3:"<<(time6-time5)/CLOCKS_PER_SEC<<endl;

    contours = CornerCutter(contours, floorMask, sl);
    for (int i = 0; i < contours.size(); i++) {
            Contour contour = contours[i];
            vector<mPoint> points = contour.getContourPoints();
            Polygon* polygon = makePolygonCCW(points2Poly(points));
            CoordinateSequence* coords = polygon->getCoordinates().release();
            points.clear();
            for (int k = 0; k < coords->size() - 1; k++) {
                points.push_back(mPoint((int)round((*coords)[k].x), (int) round((*coords)[k].y)));
            }
            contour.setContourPoints(points);
            contours[i] = contour;
    }
    for (int i = 0; i < contours.size(); i++)
    {
        contours[i].updateLines();
        contours[i].commit(lineClusterNum, contours[i].FIX_ANGLE, 5, 177, 3);
        classifyLines(contours[i], sl.getClusterValues(), angleTh);
    }
    contours=rectifyLDK(contours, sl);
    double time7=clock();
    cout<<"CornerCutter:"<<(time7-time6)/CLOCKS_PER_SEC<<endl;

    wallOptimizer.run(contours, floorMask, lineClusterNum, 20, true, true, false, AlignOptimizer::AlignStrategy::MIN_MASK, true, true, false);
    classifyLinesAndCommit(contours,sl,lineClusterNum);
    double time8=clock();
    cout<<"wallOptimizer4:"<<(time8-time7)/CLOCKS_PER_SEC<<endl;

    wallOptimizer.run(contours, floorMask, lineClusterNum, 65, false, false, true, AlignOptimizer::AlignStrategy::MIN_MASK, true, false, false);
    classifyLinesAndCommit(contours,sl,lineClusterNum);
    double time9=clock();
    cout<<"wallOptimizer5:"<<(time9-time8)/CLOCKS_PER_SEC<<endl;

    removeNotContour(contours);
    contours = DoubleOverlapSolver(segmentInfo, contours);
    wallOptimizer.fixRightAngle(contours);
    classifyLinesAndCommit(contours,sl,lineClusterNum);

    removeNotContour(contours);
    double time10=clock();
    cout<<"DoubleOverlapSolver:"<<(time10-time9)/CLOCKS_PER_SEC<<endl;

    wallOptimizer.run(contours, floorMask, lineClusterNum, 30, true, true, false, AlignOptimizer::AlignStrategy::CENTER_POINT, false, false, true);
    classifyLinesAndCommit(contours,sl,lineClusterNum);
    double time11=clock();
    cout<<"wallOptimizer6:"<<(time11-time10)/CLOCKS_PER_SEC<<endl;

    removeNotContour(contours);
    contours = DoubleOverlapSolver(segmentInfo, contours);
    classifyLinesAndCommit(contours,sl,lineClusterNum);
    removeNotContour(contours);

    AlignOptimizer::removeIncludedAngle(contours,50,135,135,false,false,floorMask);
    classifyLinesAndCommit(contours,sl,lineClusterNum);

    AlignOptimizer::removeIncludedAngle(contours,75,45,90,true,false,floorMask);
    classifyLinesAndCommit(contours,sl,lineClusterNum);

    AlignOptimizer::removeIncludedAngle(contours,75,45,90,true,false,floorMask);
    classifyLinesAndCommit(contours,sl,lineClusterNum);

    AlignOptimizer::removeIncludedAngle(contours,30,135,90,false,false,floorMask);
    classifyLinesAndCommit(contours,sl,lineClusterNum);

    AlignOptimizer::removeIncludedAngle(contours,75,135,90,true,true,floorMask);
    classifyLinesAndCommit(contours,sl,lineClusterNum);

    AlignOptimizer::removeIncludedAngle(contours,40,135,45,false,false,floorMask);
    classifyLinesAndCommit(contours,sl,lineClusterNum);

    AlignOptimizer::removeIncludedAngle(contours,40,45,90,false,false,floorMask);
    classifyLinesAndCommit(contours,sl,lineClusterNum);

    removeNotContour(contours);
    contours = DoubleOverlapSolver(segmentInfo, contours);
    for (int i = 0; i < contours.size(); i++)
    {
        contours[i].updateLines();
        contours[i].commit(lineClusterNum, contours[i].FIX_ANGLE, 5, 177, 3);
        classifyLines(contours[i], sl.getClusterValues(), angleTh);
    }
    removeNotContour(contours);
    fitOpenables(contours, openableContours, true,2);
    return pair<vector<Contour>,vector<Line>>(contours,openableContours);
}

pair<pair<vector<vector<cv::Point>>,vector<Line>>,pair<Mat,string>> run(string model_name, Mat img)
{
    TopologicalSegmentation segmentor;
    segmentor.initSegmentModel(model_name);
    SegmentInfo si = segmentor.applySegmentation(model_name, img);
    vector<SegmentRoom> rooms = si.getRooms();
    Mat smoothMask = si.getFloorMask().clone();
    
    imwrite(model_name+"smoothMask_si_ios.png",smoothMask);
    
    vector<Contour> roomContours;
    FreeAngleBoxMaximizer boxMaximizer;
    HoughSupportLineFinder finder(5, 50, 10, 14, 1);
    HoughSupportLine sl = finder.run(smoothMask);
    double time1=clock();
    vector<vector<cv::Point>> boxContours = boxMaximizer.run(rooms, sl, smoothMask);
    
    int height = smoothMask.rows;
    int width = smoothMask.cols;
    //cv::Mat res = cv::Mat(height, width, CV_8UC1, cv::Scalar(0));
    
    Mat boxDebug = Mat(height, width, CV_8UC1, cv::Scalar(0));
    drawContours( boxDebug,  boxContours, -1, Scalar(0, 255, 0), 3);
    imwrite(model_name+"boxDebug_ios.png",  boxDebug);
    
    double time2=clock();
    cout<<"boxMaximizer:"<<(time2-time1)/CLOCKS_PER_SEC<<endl;
    vector<vector<cv::Point>> contourMask;
    pair<vector<Contour>,vector<Line>> fitFloorPlanResult;
    for (int i = 0; i < rooms.size(); i++)
    {
        SegmentRoom room = rooms[i];
        vector<cv::Point> box = boxContours[i];
        contourMask.push_back(room.getContours());
        Contour contour = Contour(contour.FIX_POINT, box, room.getRoomType(), room.getGroupId(), room.getShapeId());
        // Contour contour = Contour(contour.FIX_POINT, room.getContours(), room.getRoomType(), room.getGroupId(), room.getShapeId());
        roomContours.push_back(contour);
    }
    double time3=clock();
    fitFloorPlanResult = fitFloorPlan(si, roomContours, sl);
    vector<vector<cv::Point>> result;
    for (int i = 0; i < fitFloorPlanResult.first.size(); i++)
    {
        result.push_back(Contour::getContourFromPoints(fitFloorPlanResult.first[i].getContourPoints()));
    }
    
    // vector<Line> doors = convertDoor2Line(si);
    // vector<Line> openableContours = processOpenable(roomContours, doors);
    // vector<vector<cv::Point>> result1;
    // for (int i = 0; i < roomContours.size(); i++)
    // {
    //     result1.push_back(Contour::getContourFromPoints(roomContours[i].getContourPoints()));
    // }

    // result.first=result1;
    // result.second=openableContours;

    double time4=clock();
    cout<<"fitFloorPlan:"<<(time4-time3)/CLOCKS_PER_SEC<<endl;

    vector<vector<int>> openingWallIds = getOpeningsWallIds(fitFloorPlanResult.first, fitFloorPlanResult.second);
    string imdfString = getIMDFString(fitFloorPlanResult.first, fitFloorPlanResult.second, openingWallIds);

    pair<Mat,string> resultSecond = pair<Mat,string>(smoothMask,imdfString);
    pair<vector<vector<cv::Point>>,vector<Line>> resultFirst = pair<vector<vector<cv::Point>>,vector<Line>>(result,fitFloorPlanResult.second);

    return pair<pair<vector<vector<cv::Point>>,vector<Line>>,pair<Mat,string>>(resultFirst,resultSecond);
}

Mat cutBlack(Mat img)
{
    Mat newMat;
    int xmax = 0, xmin = 10000, ymax = 0, ymin = 10000;
    for (int i = 0; i < img.cols; i++)
    {
        for (int j = 0; j < img.rows; j++)
        {
            uchar temp = 0;
            temp = img.at<uchar>(j, i);
            if (temp != 0)
            {
                if (i > xmax)
                {
                    xmax = i;
                }
                else if (i < xmin)
                {
                    xmin = i;
                }
                if (j > ymax)
                {
                    ymax = j;
                }
                else if (j < ymin)
                {
                    ymin = j;
                }
            }
        }
    }
    newMat = img(Range(max(0, ymin - 50), min(img.rows, ymax + 50)), Range(max(0, xmin - 50), min(img.cols, xmax + 50)));
    return newMat;
}

void classifyLinesAndCommit(vector<Contour> &contours,HoughSupportLine sl,int lineClusterNum){
    for (int i = 0; i < contours.size(); i++)
    {
        classifyLines(contours[i], sl.getClusterValues(), angleTh);
        contours[i].commit(lineClusterNum, contours[i].FIX_ANGLE, 5, 177, 3);
    }
}

void removeNotContour(vector<Contour> &contours){
    for (int i = 0; i < contours.size(); i++) {
        Contour contour = contours[i];
        if (contour.getContourPoints().size() < 3) {
            contours.erase(contours.begin()+i);
            i--;
        }
    }
}

    bool isHorizontal(double angle) {
        return fabs(angle) < 10 || fabs(angle) > 170;
    }

    bool isVertical(double angle) {
        return fabs(angle) > 80 && fabs(angle) < 100;
    }

vector<Contour> rectifyLDK(vector<Contour> contours, HoughSupportLine sl) {
        double smallLineTh = 5;
        for (int i = 0; i < contours.size(); i++) {
            if (contours[i].getLabel()=="LDK") {
                vector<Line> ldkLinesTemp = contours[i].getLines();
                vector<Line> ldkLines;
                for(int j=0;j<ldkLinesTemp.size();j++){
                    if(ldkLinesTemp[j].length()>=smallLineTh){
                        ldkLines.push_back(ldkLinesTemp[j]);
                    }
                }
                vector<mPoint> ldkPoints;
                for(int j=0;j<ldkLines.size();j++){
                    ldkPoints.push_back(ldkLines[j].getU());
                }
                int startIdx = -1;
                for (int j = 0; j < ldkLines.size(); j++) {
                    double currentAngle = ((int)ldkLines[j].angle() + 180) % 180;
                    double prevAngle = (int)(ldkLines[(j - 1 + ldkLines.size()) % ldkLines.size()].angle() + 180) % 180;
                    double nextAngle = (int)(ldkLines[(j + 1) % ldkLines.size()].angle() + 180) % 180;
                    if ((isHorizontal(currentAngle) && isVertical(prevAngle) && isVertical(nextAngle)) || (isVertical(currentAngle) && isHorizontal(prevAngle) && isHorizontal(nextAngle))) {
                        startIdx = j;
                        break;
                    }
                }
                if (startIdx == -1) {
                    return contours;
                }
                for (int k = 0; k < ldkPoints.size(); k++) {
                    int currentIdx = (startIdx + k) % ldkPoints.size();
                    int nextIdx = (currentIdx + 1) % ldkPoints.size();
                    double dx = ldkPoints[nextIdx].x - ldkPoints[currentIdx].x;
                    double dy = ldkPoints[nextIdx].y - ldkPoints[currentIdx].y;
                    double angleDegree = (int)((atan2(dy, dx)*180/M_PI) + 180) % 180;
                    if (angleDegree < 20 || angleDegree > 160) {
                        ldkPoints[nextIdx].y = ldkPoints[currentIdx].y;
                    } else if (angleDegree > 80 && angleDegree < 100) {
                        ldkPoints[nextIdx].x = ldkPoints[currentIdx].x;
                    }
                }

                contours[i].setContourPoints(ldkPoints);
                contours[i].updateLines();
                return contours;
            }
        }
    vector<Contour> temp;
    return temp;
    }

vector<vector<int>> getOpeningsWallIds(vector<Contour> contours, vector<Line> doors){
        vector<vector<int>> wallIds;
        vector<Line> roomLines;
        for (int i = 0; i < contours.size(); i++) {
            vector<Line> tempLine = contours[i].getLines();
            for(int j=0;j<tempLine.size();j++){
                roomLines.push_back(tempLine[j]);
            }
        }

        for (int i = 0; i < doors.size(); i++) {
            Line door = doors[i];
            double minDist = 100000;
            int minId = -1;
            for (int j = 0; j < roomLines.size(); j++) {
                Line roomLine = roomLines[j];
                double dist = point2LineDistance(door.center(), roomLine);
                if (dist < minDist && isPointProjectOnInnerSegment(door.center(), roomLine, 2)) {
                    minDist = dist;
                    minId = j;
                }
            }

            if (minDist < 10) {
                Line wall = roomLines[minId];
                mPoint pointU = door.getU();
                mPoint pointV = door.getV();
                if (!isPointProjectOnInnerSegment(pointU, wall, 2)) {
                    if (getPointDist(pointU, wall.getU()) < getPointDist(pointU, wall.getV())) {
                        door.setU(wall.getU());
                    } else {
                        door.setU(wall.getV());
                    }
                }

                if (!isPointProjectOnInnerSegment(pointV, wall, 2)) {
                    if (getPointDist(pointV, wall.getU()) < getPointDist(pointV, wall.getV())) {
                        door.setV(wall.getU());
                    } else {
                        door.setV(wall.getV());
                    }
                }
                double wallTh = 3;

                vector<int> selectWallIds;
                selectWallIds.push_back(minId);
                for (int k = 0; k < roomLines.size(); k++) {
                    if (k == minId) {
                        continue;
                    }
                    if (point2LineDistance(wall.center(), roomLines[k]) < wallTh) {
                        if (isPointProjectOnInnerSegment(pointU, roomLines[k], 0) && isPointProjectOnInnerSegment(pointV, roomLines[k], 0)) {
                            selectWallIds.push_back(k);
                        }
                    }
                }

                wallIds.push_back(selectWallIds);

            } else {
                vector<int> temp;
                wallIds.push_back(temp);
            }

        }
        return wallIds;
    }

double getWallLength(mPoint p1,mPoint p2){
        return sqrt((p1.x-p2.x)*(p1.x-p2.x)+(p1.y-p2.y)*(p1.y-p2.y));
    }

string addLeadingZeros(int number,int width){
    ostringstream tempStream;
    tempStream << std::internal << setfill('0') << setw(width) << number;
    return tempStream.str();
}

string getIMDFString(vector<Contour> contours, vector<Line> openableContours, vector<vector<int>> openingWallIds){
        double scale=0.04;
        json imdfObj;
        json rooms = json::array();
        json building;

        try {
            building["id"]= "938281811";
            building["push_backressId"]="93kdkdk";
            json push_backress;
            push_backress["fullpush_backress"]= "test push_backress";
            push_backress["roadpush_backress"]= "an de men";
            building["push_backress"]= push_backress;
            building["type"]= "Lidar";
            building["size"]= 105.8;
            json floorNames= json::array();
            floorNames.push_back("1");
            building["floors"]= floorNames;
            json floorImages= json::array();
            json floorImage;
            floorImage["floor"]= "1";
            floorImage["width"]= 512;
            floorImage["height"]= 512;
            floorImages.push_back(floorImage);
            building["images"]= floorImages;

            json floors= json::array();
            json floor;
            floor["name"]= "1";

            int wallId = 0;
            for (int i = 0; i < contours.size(); i++) {
                json walls= json::array();
                json roomObj;
                roomObj["id"]= "room_" + addLeadingZeros(i,5);
                double area=contourArea(Contour::getContourFromPoints(contours[i].getContourPoints()))*scale*scale;
                roomObj["area"]=((double)round(area*100))/100;
                json roomProp;
                roomProp["category"]= "BEDROOM";
                roomProp["name"]="room";
                roomProp["visible"]= true;
                roomObj["properties"]= roomProp;

                json roomPlane;
                roomPlane["id"]= "plane_" + addLeadingZeros(i,5);
                vector<mPoint> points = contours[i].getContourPoints();
                json coords= json::array();
                for (int k = 0; k < points.size(); k++) {
                    json coord= json::array();
                    coord.push_back(points[k].x);
                    coord.push_back(0);
                    coord.push_back(points[k].y);
                    coords.push_back(coord);

                    json wallObj;
                    wallObj["id"]="wall_" + addLeadingZeros(wallId,5);
                    double templenth=getWallLength(points[k],points[(k+1)%points.size()])*scale;
                    wallObj["size"]=((double)round(templenth*100))/100;
                    wallId++;
                    json wallCoords= json::array();
                    json wallCoord1= json::array();
                    json wallCoord2= json::array();
                    wallCoord1.push_back(points[k].x);
                    wallCoord1.push_back(50);
                    wallCoord1.push_back(points[k].y);
                    wallCoords.push_back(wallCoord1);

                    int nextK = (k + 1) % points.size();
                    wallCoord2.push_back(points[nextK].x);
                    wallCoord2.push_back(50);
                    wallCoord2.push_back(points[nextK].y);
                    wallCoords.push_back(wallCoord2);

                    wallObj["coordinates"]= wallCoords;
                    walls.push_back(wallObj);
                }

                roomPlane["coordinates"]= coords;
                roomObj["plane"]= roomPlane;
                roomObj["walls"]= walls;
                rooms.push_back(roomObj);
            }
            floor["rooms"]=rooms;

            json openings= json::array();
            for (int i = 0; i < openableContours.size(); i++) {
                json openObj;
                openObj["id"]= "opening_" + addLeadingZeros(i,5);
                json openProp;
                openProp["category"]="DOOR";
                openProp["visible"]= true;
                json wallGroup= json::array();
                vector<int> wallIds = openingWallIds[i];
                if (wallIds.size() != 0) {
                    for (int k = 0; k < wallIds.size(); k++) {
                        wallGroup.push_back("wall_" + addLeadingZeros(wallIds[k],5));
                    }
                    openProp["groups"]=wallGroup;
                }

                openObj["properties"]= openProp;

                json coords= json::array();
                Line openLine = openableContours[i];

                json coordU= json::array();
                coordU.push_back(openLine.getU().x);
                coordU.push_back(0);
                coordU.push_back(openLine.getU().y);
                coords.push_back(coordU);

                json coordV= json::array();
                coordV.push_back(openLine.getV().x);
                coordV.push_back(0);
                coordV.push_back(openLine.getV().y);
                coords.push_back(coordV);

                openObj["coordinates"]= coords;
                openObj["name"]= "DOOR";
                openObj["type"]="casement";

                openings.push_back(openObj);
            }

            floor["openings"]= openings;
            floors.push_back(floor);
            imdfObj["building"]= building;
            imdfObj["floors"]= floors;
            return imdfObj.dump();

        } catch (exception e) {
            return "";
        }
    }
