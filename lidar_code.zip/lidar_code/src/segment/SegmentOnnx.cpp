#include "segment/SegmentOnnx.h"
#include"geom/Utils.h"
using namespace std;
using namespace cv;
using namespace Ort;
#include <fstream>
#include <iostream>
#include <numeric>

SegmentOnnx::SegmentOnnx() {
        session = Session(nullptr);
        top_pad = bottom_pad = left_pad = right_pad = 0;
    }


    bool SegmentOnnx::loadModel( string modelName, ModelType modelType) {
        return loadModel( modelName, modelType, 0.0f);
    }

    bool SegmentOnnx::loadModel( string modelName, ModelType modelType, float padding_value) {
        padding_scalar = Scalar(padding_value, padding_value, padding_value, padding_value);
        this->modelType = modelType;
        if (modelType == ModelType::RTMDET_INS) {
            normMeanRGB = vector<float>{103.53f, 116.28f, 123.675f};
            normStdRGB = vector<float>{57.375f, 57.12f, 58.395f};
        } else {
            return false;
        }

        try {
            const char* path = modelName.c_str();
            opts = SessionOptions();
            session = Session(env, path, opts);

        } catch (exception e) {
            return false;
        }

        return true;
    }

    vector<Value> SegmentOnnx::forward_rtmdet_ins(Mat input,string tmppath) {
        Mat inputMat = preProcess(input, padding_scalar);
        imwrite(tmppath+"inputMat_ios.png",inputMat);
        vector<float> floatBuffer;
        vector<Value> inputTensors = matToTensor(inputMat, true, floatBuffer);
        // 保存为二进制文件
            //saveTensorToBinary(inputTensors, tmppath+"tensor_data.bin");
        // 打印数据
            //printTensorData(inputTensors);
        return session.Run(RunOptions{nullptr}, input_node_names.data(), inputTensors.data(), 1, output_node_names.data(), output_node_names.size());
    }

//void printTensorData(const std::vector<Value>& inputTensors) {
//    for (const auto& tensor : inputTensors) {
//        // 获取张量信息
//        auto tensor_info = tensor.GetTensorTypeAndShapeInfo();
//        auto shape = tensor_info.GetShape();  // 形状，如{1,3,640,640}
//        auto data_type = tensor_info.GetElementType(); // 数据类型，如ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT
//        
//        // 检查数据类型是否为float（常见情况）
//        if (data_type != ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT) {
//            std::cerr << "Unsupported data type!" << std::endl;
//            return;
//        }
//
//        // 获取数据指针
//        const float* data = tensor.GetTensorData<float>();
//        
//        // 计算总元素数量
//        size_t total_elements = tensor_info.GetElementCount();
//        
//        // 打印数据（示例仅打印前10个元素）
//        std::cout << "Tensor shape: [";
//        for (auto dim : shape) std::cout << dim << " ";
//        std::cout << "]\nFirst 10 elements: ";
//        for (size_t i = 0; i < std::min<size_t>(10, total_elements); ++i) {
//            std::cout << data[i] << " ";
//        }
//        std::cout << "\n\n";
//    }
//}

    Mat SegmentOnnx::forward(Mat ori_input, string modelName, ModelType modelType) {
        if (session == NULL) {
            this->modelType = modelType;
            if (modelType != ModelType::RTMDET_INS) {
                return ori_input;
            }
            try {
                loadModel( modelName, ModelType::RTMDET_INS, 114);
            } catch (exception e) {
                return ori_input;
            }
        }

        Mat input = Mat();
        // Resize the input image to make the longer side of the picture equal to INPUT_DIM
        int height = INPUT_DIM, width = INPUT_DIM;
        if (ori_input.rows >= ori_input.cols) {
            width = round((float) ori_input.cols * height / ori_input.rows);
        } else {
            height = round((float) ori_input.rows * width / ori_input.cols);
        }
        resize(ori_input, input, Size(width, height), 0, 0, INTER_LINEAR);
        vector<Value> output;
        
        string model = "rtmdet_int8.ort";
        string modelNameCopy = modelName;
        string tmppath = modelNameCopy.erase(modelNameCopy.length()-model.length());
        
        try {
            if (modelType == ModelType::RTMDET_INS) {
                
                imwrite(tmppath+"input_ios.png",input);
                output = forward_rtmdet_ins(input,tmppath);
            } else {
                return Mat();
            }
        } catch (Ort::Exception e) {
            return Mat();
        }
        Mat outputMat = postProcess(input, &output);
        
        imwrite(tmppath+"outputMat_ios.png",outputMat);
        
        for (int i = 0; i < output.size(); i++) {
            output[i].release();
        }
        resize(outputMat, outputMat, ori_input.size(), 0, 0, INTER_NEAREST);
        return outputMat;
    }

    Mat SegmentOnnx::preProcess(Mat input, Scalar scalar) {
        int h = input.rows, w = input.cols;
        top_pad = 0;
        bottom_pad = INPUT_DIM - h - top_pad;
        left_pad = 0;
        right_pad = INPUT_DIM - w - left_pad;
        Mat padded_image = Mat();
        copyMakeBorder(input, padded_image, top_pad, bottom_pad, left_pad, right_pad, BORDER_CONSTANT, scalar);
        return padded_image;
    }

    vector<Value> SegmentOnnx::matToTensor(Mat input, bool RGB2BGR, vector<float>& floatBuffer) {
        int height = input.rows, width = input.cols;
        floatBuffer.resize(3 * width * height);
        int pixelsCount = height * width;
        int offset_g = pixelsCount;
        int offset_b = 2 * pixelsCount;
        int index = 0;
        if (!RGB2BGR) {
            for (int i = 0; i < height; i++) {
                for (int j = 0; j < width; j++) {
                    uchar value = input.at<uchar>(i,j);
                    float r = (float) value, g = (float) value, b = (float) value;
                    floatBuffer[index]=(r - normMeanRGB[0]) / normStdRGB[0];
                    floatBuffer[offset_g + index] = (g - normMeanRGB[1]) / normStdRGB[1];
                    floatBuffer[offset_b + index] = (b - normMeanRGB[2]) / normStdRGB[2];
                    index++;
                }
            }
        } else {
            for (int i = 0; i < height; i++) {
                for (int j = 0; j < width; j++) {
                    uchar value = input.at<uchar>(i,j);
                    float r = (float) value, g = (float) value, b = (float) value;
                    floatBuffer[index] = (b - normMeanRGB[2]) / normStdRGB[2];
                    floatBuffer[offset_g + index] = (g - normMeanRGB[1]) / normStdRGB[1];
                    floatBuffer[offset_b + index] = (r - normMeanRGB[0]) / normStdRGB[0];
                    index++;
                }
            }
        }
        TypeInfo type_info = session.GetInputTypeInfo(0);
        auto tensor_info = type_info.GetTensorTypeAndShapeInfo();
        auto input_shape_ = tensor_info.GetShape();
        auto ele_count = tensor_info.GetElementCount();
        
        vector<Value> inputTensors;
        inputTensors.emplace_back(std::move(
            Value::CreateTensor<float>(memory_info, floatBuffer.data(), ele_count, input_shape_.data(), input_shape_.size())));
        
        return inputTensors;
    }

//void saveTensorToBinary(const std::vector<Value> inputTensors, const std::string filename) {
//    std::ofstream file(filename, std::ios::binary);
//    if (!file.is_open()) {
//        std::cerr << "Failed to open file!" << std::endl;
//        return;
//    }
//    
//    for (const auto& tensor : inputTensors) {
//        auto tensor_info = tensor.GetTensorTypeAndShapeInfo();
//        const float* data = tensor.GetTensorData<float>();
//        size_t total_elements = tensor_info.GetElementCount();
//        
//        // 写入形状信息（维度数 + 各维度值）
//        auto shape = tensor_info.GetShape();
//        int64_t rank = shape.size();
//        file.write(reinterpret_cast<const char*>(&rank), sizeof(int64_t));
//        file.write(reinterpret_cast<const char*>(shape.data()), sizeof(int64_t) * rank);
//        
//        // 写入数据
//        file.write(reinterpret_cast<const char*>(data), sizeof(float) * total_elements);
//    }
//    file.close();
//}

    vector<int> SegmentOnnx::select(vector<vector<int>> boxes, vector<float> scores, vector<Mat> masks) {
        int N = masks.size();
        int sums[N];
        int overlaps[N][N];
        vector<int> select;
        for (int i = 0; i < N; i++) {
            sums[i] = 0;
            select.push_back(1);
            for (int j = 0; j < N; j++) {
                overlaps[i][j] = 0;
            }
        }
        for (int i = 0; i < N; i++) {
            if (select[i] == 0) continue;
            Mat prev_mask = masks[i];
            vector<int> prev_box = boxes[i];
            int prev_y1 = prev_box[0], prev_x1 = prev_box[1], prev_y2 = prev_box[2], prev_x2 = prev_box[3];
            for (int j = i + 1; j < N; j++) {
                if (select[j] == 0) continue;
                Mat mask = masks[j];
                vector<int> box = boxes[j];
                int y1 = box[0], x1 = box[1], y2 = box[2], x2 = box[3];

                if (((prev_x1 >= x1 && prev_x1 < x2) || (x1 >= prev_x1 && x1 < prev_x2)) &&
                        ((prev_y1 >= y1 && prev_y1 < y2) || (y1 >= prev_y1 && y1 < prev_y2))) {
                    y1 = min(y1, prev_y1);
                    x1 = min(x1, prev_x1);
                    y2 = max(y2, prev_y2);
                    x2 = max(x2, prev_x2);
                    int prev_sum = 0, sum = 0, overlap = 0;
                    for (int y = y1; y < y2; y++) {
                        uchar prev[x2 - x1];
                        uchar curr[x2 - x1];
                        uchar *prevData = prev_mask.ptr<uchar>(y,x1);
                        uchar *currData = mask.ptr<uchar>(y,x1);
                        for(int x=x1;x<x2;x++){
                            prev[x-x1]=prevData[x-x1];
                            curr[x-x1]=currData[x-x1];
                        }

                        for (int x = x1; x < x2; x++) {
                            int pVal = prev[x - x1] & 0xff;
                            int cVal = curr[x - x1] & 0xff;
                            prev_sum += pVal == 1 ? 1 : 0;
                            sum += cVal == 1 ? 1 : 0;
                            if (pVal == 1 && cVal == 1) overlap++;
                        }
                    }
                    sums[i] = prev_sum;
                    sums[j] = sum;
                    overlaps[i][j] = overlap;
                    overlaps[j][i] = overlap;

                    if (scores[i] < SCORE_THRESHOLD_L2 || scores[j] < SCORE_THRESHOLD_L2) {
                        if (overlap > prev_sum * OVERLAP_THRESHOLD_L2 || overlap > sum * OVERLAP_THRESHOLD_L2) {
                            select[j] = 0;
                        }
                    } else if (overlap > prev_sum * OVERLAP_THRESHOLD || overlap > sum * OVERLAP_THRESHOLD) {
                        if (prev_sum >= sum) select[j] = 0;
                        else {
                            select[i] = 0;
                            break;
                        }
                    }
                }
            }
        }

        for (int i = 0; i < N; i++) {
            if (select[i] == 0) continue;
            int total_overlap = 0;
            for (int j = 0; j < N; j++) {
                if (i == j) continue;
                if (select[j] == 0) continue;
                total_overlap += overlaps[i][j];
            }
            if (total_overlap > sums[i] * OVERLAP_THRESHOLD) select[i] = 0;
        }
        
        return select;
    }

    Mat SegmentOnnx::mask(Mat output, vector<vector<int>> boxes, vector<int> class_ids, vector<Mat> masks, vector<int> select, vector<Mat> float_masks) {
        int N = masks.size();
        int room_mask = 1, corridor_mask = 200, ldk_mask = 100;

        bool noLdk = true;
        int maxRoomId = -1;
        int maxRoomArea = 0;
        for (int i = N - 1; i >= 0; i--) {
            if (select[i] == 0) continue;
            int class_id = class_ids[i];
            if (class_id == 1) {
                noLdk = false;
                break;
            } else if (class_id > 2) {
                int area = countNonZero(masks[i]);
                if (area > maxRoomArea) {
                    maxRoomArea = area;
                    maxRoomId = i;
                }
            }
        }
        if (noLdk && maxRoomId != -1) {
            class_ids[maxRoomId]= 1;
        }

//        int mask_num_map[N]={0};
        int mask_num_map[N];
        for(int i=0;i<N;i++){
            mask_num_map[N]=0;
        }
        for (int i = N - 1; i >= 0; i--) {
            if (select[i] == 0) continue;
            Mat mask = masks[i];
            int class_id = class_ids[i];
            int mask_num = 0;
            if (class_id == 1) mask_num = ldk_mask;
            else if (class_id == 2) {
                mask_num = corridor_mask;
                corridor_mask++;
            } else {
                mask_num = room_mask;
                room_mask++;
            }
            mask_num_map[i] = mask_num;

            vector<int> box = boxes[i];
            int y1 = box[0], x1 = box[1], y2 = box[2], x2 = box[3];
            for (int y = y1; y < y2; y++) {
                uchar values[x2 - x1];
                uchar outputs[x2 - x1];
                uchar *valuesData = mask.ptr<uchar>(y,x1);
                uchar *outputsData = output.ptr<uchar>(y,x1);
                for(int x=x1;x<x2;x++){
                    values[x-x1]=valuesData[x-x1];
                    outputs[x-x1]=outputsData[x-x1];
                }
                for (int x = x1; x < x2; x++) {
                    int val = values[x - x1] & 0xff;
                    if (val == 1) {
                        outputs[x - x1] = (uchar) mask_num;
                    }
                }
                for (int x = x1; x < x2; x++) {
                    outputsData[x-x1]=outputs[x-x1];
                }
            }
        }
        for (int i = 0; i < output.rows; i++) {
            float mask_val[N][output.cols];
            for (int j = 0; j < N; j++) {
                float *float_masksData = float_masks[j].ptr<float>(i,0);
                for(int x=0;x<output.cols;x++){
                    mask_val[j][x]=float_masksData[x];
                }
            }
            uchar outputs[output.cols];
            uchar *outputData = output.ptr<uchar>(i,0);
            for(int x=0;x<output.cols;x++){
                outputs[x]=outputData[x];
            }
            for (int j = 0; j < output.cols; j++) {
                int currVal = outputs[j] & 0xff;
                if (currVal == 0) {
                    int mask_num = 0;
                    float max_mask_val = 0.1f;
                    for (int k = 0; k < N; k++) {
                        if (mask_val[k][j] > max_mask_val) {
                            max_mask_val = mask_val[k][j];
                            mask_num = mask_num_map[k];
                        }
                    }
                    if (max_mask_val > 0.1f) {
                        outputs[j] = (uchar) mask_num;
                    }
                }
            }
            for(int x=0;x<output.cols;x++){
                outputData[x]=outputs[x];
            }
        }
        return output;
    }

    Mat SegmentOnnx::postProcess(Mat input, vector<Value>* output) {
        if (modelType == ModelType::RTMDET_INS) {
            return postProcess_rtmdet_ins(input, output);
        }
        return Mat();
    }

    int clamp(int x,int min,int max){
        if(x<min)
        {
            return min;
        }
        else if (x>max)
        {
            return max;
        }
        else{
            return x;
        }
    }

    Mat SegmentOnnx::postProcess_rtmdet_ins(Mat input, vector<Value>* output) {
            Value &output_dets_value = (*output)[0];
            vector<int64_t> dets_dims = output_dets_value.GetTypeInfo().GetTensorTypeAndShapeInfo().GetShape();
            float* output_dets_ptr = output_dets_value.GetTensorMutableData<float>();
            float output_dets[dets_dims[0]][dets_dims[1]][dets_dims[2]];
            for(int a=0;a<dets_dims[0];a++){
                for(int b=0;b<dets_dims[1];b++){
                    for(int c=0;c<dets_dims[2];c++){
                        output_dets[a][b][c]=output_dets_ptr[a*dets_dims[1]*dets_dims[2]+b*dets_dims[2]+c];
                    }
                }
            }
            Value &output_class_ids_value = (*output)[1];
            vector<int64_t> output_class_ids_dims = output_class_ids_value.GetTypeInfo().GetTensorTypeAndShapeInfo().GetShape();
            long* output_class_ids_ptr = output_class_ids_value.GetTensorMutableData<long>();
            long output_class_ids[output_class_ids_dims[0]][output_class_ids_dims[1]];
            for(int a=0;a<output_class_ids_dims[0];a++){
                for(int b=0;b<output_class_ids_dims[1];b++){
                        output_class_ids[a][b]=output_class_ids_ptr[a*output_class_ids_dims[1]+b];
                }
            }

            int cnt=0;
            for(int i=0;i<dets_dims[1];i++){
                if(output_dets[0][i][4]< SCORE_THRESHOLD)
                    break;
                cnt++;
            }
            Value &output_masks_value = (*output)[2];
            vector<int64_t> masks_dims = output_masks_value.GetTypeInfo().GetTensorTypeAndShapeInfo().GetShape();
            float* output_masks_ptr = output_masks_value.GetTensorMutableData<float>();
//            float output_masks[masks_dims[0]][cnt][masks_dims[2]][masks_dims[3]];
//            for(int a=0;a<masks_dims[0];a++){
//                for(int b=0;b<cnt;b++){
//                    for(int c=0;c<masks_dims[2];c++){
//                        for(int d=0;d<masks_dims[3];d++){
//                            output_masks[a][b][c][d]=output_masks_ptr[a*masks_dims[1]*masks_dims[2]*masks_dims[3]+b*masks_dims[2]*masks_dims[3]+c*masks_dims[3]+d];                           
//                        }
//                    }
//                }
//            }
        float ****output_masks;
            output_masks = (float ****)malloc(masks_dims[0]*sizeof(float ***));
                 for(int a=0;a<masks_dims[0];a++){
                    output_masks[a]=(float ***)malloc(cnt * sizeof(float **));
                    for(int b=0;b<cnt;b++){
                        output_masks[a][b]=(float **)malloc(masks_dims[2] * sizeof(float *));
                        for(int c=0;c<masks_dims[2];c++){
                            output_masks[a][b][c]=(float *)malloc(masks_dims[3] * sizeof(float));
                            for(int d=0;d<masks_dims[3];d++){
                                output_masks[a][b][c][d]=output_masks_ptr[a*masks_dims[1]*masks_dims[2]*masks_dims[3]+b*masks_dims[2]*masks_dims[3]+c*masks_dims[3]+d];
                            }
                        }
                    }
                }
        int N = dets_dims[1];
        vector<vector<int>> boxes;
        vector<int> class_ids;
        vector<float> scores;
        vector<Mat> masks;
        vector<Mat> float_masks;

        bool ldk_flag = false;
        for (int i = 0; i < N; i++) {
            int class_id = (int) output_class_ids[0][i];
            float score = output_dets[0][i][4];
            if (score < SCORE_THRESHOLD) break;

            if (class_id == 0) continue;
            if (class_id == 1) {
                if (!ldk_flag) ldk_flag = true;
                else class_id = 3;
            }

            int y1, x1, y2, x2;
            x1 = (int) floor(output_dets[0][i][0]) - 1 - left_pad;
            y1 = (int) floor(output_dets[0][i][1]) - 1 - top_pad;
            x2 = (int) ceil(output_dets[0][i][2]) + 1 - left_pad;
            y2 = (int) ceil(output_dets[0][i][3]) + 1 - top_pad;

            if ((y2 - y1) <= 0 || (x2 - x1) <= 0) continue;
            x1 = clamp(x1, 0, INPUT_DIM);
            y1 = clamp(y1, 0, INPUT_DIM);
            x2 = clamp(x2, 0, INPUT_DIM + 1);
            y2 = clamp(y2, 0, INPUT_DIM + 1);
            vector<int> box = vector<int>{y1, x1, y2, x2};
            Mat float_mask = Mat(input.rows, input.cols, CV_32FC1);
            Mat full_mask = Mat(input.rows, input.cols, CV_32FC1);
            for (int row = 0; row < INPUT_DIM - bottom_pad; row++) {
                float *float_masksData = float_mask.ptr<float>(row,0);
                for(int x=0;x<INPUT_DIM - right_pad;x++){
                    float_masksData[x]=output_masks[0][i][row][x];
                }
            }
            float_masks.push_back(float_mask);
            threshold(float_mask, full_mask, 0.5, 1, THRESH_BINARY);
            full_mask.convertTo(full_mask, CV_8UC1);

            boxes.push_back(box);
            class_ids.push_back(class_id);
            scores.push_back(score);
            masks.push_back(full_mask);
        }
        Mat outputMat = Mat::zeros(input.size(), CV_8UC1);
        vector<int> selected = select(boxes, scores, masks);
        for(int a=0;a<masks_dims[0];a++){
                   for(int b=0;b<cnt;b++){
                       for(int c=0;c<masks_dims[2];c++){
                           free(output_masks[a][b][c]);
                       }
                       free(output_masks[a][b]);
                   }
                   free(output_masks[a]);
               }
        return mask(outputMat, boxes, class_ids, masks, selected, float_masks);
    }
