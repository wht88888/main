#include <opencv2/opencv.hpp>
#include <vector>
#include <string>
#include <sstream>
#include "readmap/MapData.h"
#include "voronoi/Util.h"

using namespace std;
using namespace cv;

cv::Mat dealPgmMat(const cv::Mat& input, int freeThreshold) {
    cv::Mat output = input.clone();
    for (int row = 0; row < input.rows; ++row) {
        const uchar* input_ptr = input.ptr<uchar>(row);
        uchar* output_ptr = output.ptr<uchar>(row);
        for (int col = 0; col < input.cols; ++col) {
            uchar value = input_ptr[col];
            int temp = value & 0xff;
            if (temp >= 1 && temp <= freeThreshold) output_ptr[col] = static_cast<uchar>(-1);
            else if (temp > freeThreshold) output_ptr[col] = 0;
        }
    }
    return output;
}

Mat MapData::generMapData(string& lidarMapPath, bool useBase64) {
    if (!useBase64) {
        Mat img = imread(lidarMapPath, cv::IMREAD_UNCHANGED);
        if(img.empty()){
            cout << "img is empty !!!"<<endl;
        }
        string ext = lidarMapPath.substr(lidarMapPath.find_last_of(".")+1);
        if (ext == ".pgm") {
            map = dealPgmMat(img, 120);
        }else{
            if(img.channels() == 3){
                cout << "###" <<endl;
                cvtColor(img, img, COLOR_BGR2GRAY);
            }
            map = iPhoneGetBinaryImage(img);
        }
    } else {
        Mat img = Base2Mat(lidarMapPath);
        map = dealPgmMat(img, 120);
    }
    return map;
}

Mat MapData::Base2Mat(std::string &base64_data)
{
    cv::Mat img;
    std::string s_mat;
    s_mat = base64Decode(base64_data.data(), base64_data.size());
    std::vector<char> base64_img(s_mat.begin(), s_mat.end());
    img = cv::imdecode(base64_img, IMREAD_UNCHANGED);
    return img;
}

string MapData::base64Decode(const char* Data, int DataByte)
{
    const char DecodeTable[] =
    {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        62, // '+'
        0, 0, 0,
        63, // '/'
        52, 53, 54, 55, 56, 57, 58, 59, 60, 61, // '0'-'9'
        0, 0, 0, 0, 0, 0, 0,
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,
        13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, // 'A'-'Z'
        0, 0, 0, 0, 0, 0,
        26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38,
        39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, // 'a'-'z'
    };
    std::string strDecode;
    int nValue;
    int i = 0;
    while (i < DataByte)
    {
        if (*Data != '\r' && *Data != '\n')
        {
            nValue = DecodeTable[*Data++] << 18;
            nValue += DecodeTable[*Data++] << 12;
            strDecode += (nValue & 0x00FF0000) >> 16;
            if (*Data != '=')
            {
                nValue += DecodeTable[*Data++] << 6;
                strDecode += (nValue & 0x0000FF00) >> 8;
                if (*Data != '=')
                {
                    nValue += DecodeTable[*Data++];
                    strDecode += nValue & 0x000000FF;
                }
            }
            i += 4;
        }
        else
        {
            Data++;
            i++;
        }
    }
    return strDecode;
}
