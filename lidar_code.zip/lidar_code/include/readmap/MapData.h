#ifndef MAPDATA_H
#define MAPDATA_H

#include <opencv2/opencv.hpp>
#include <vector>
#include <string>

using namespace std;
using namespace cv;

class MapData {
public:
    Mat generMapData(string& lidarMapPath, bool useBase64);
    
    Mat Base2Mat(string &base64_data);
    
    string base64Decode(const char* Data, int DataByte);
private:
    Mat map;
    
};

#endif // MAPDATA_H
