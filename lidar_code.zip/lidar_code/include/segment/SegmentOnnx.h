#ifndef SEGMENTONNX_H
#define SEGMENTONNX_H
#include "onnxruntime/onnxruntime_cxx_api.h"
#include <iostream>
#include <opencv2/opencv.hpp>
class SegmentOnnx {
    private:

    std::vector<float> normMeanRGB;
    std::vector<float> normStdRGB;
    cv::Scalar padding_scalar;
    const int INPUT_DIM = 256;
    const float SCORE_THRESHOLD = 0.2f;
    const float SCORE_THRESHOLD_L2 = 0.45f;
    const float OVERLAP_THRESHOLD = 0.5f;
    const float OVERLAP_THRESHOLD_L2 = 0.3f;

    // image preprocess information
    int top_pad, bottom_pad, left_pad, right_pad;

    public: enum ModelType {
        RTMDET_INS
    };
    private:
    ModelType modelType;

    Ort::Env env;
    Ort::Session session{nullptr};
    Ort::SessionOptions opts;
    Ort::MemoryInfo memory_info = Ort::MemoryInfo::CreateCpu(OrtAllocatorType::OrtArenaAllocator,OrtMemType::OrtMemTypeDefault);
    std::vector<const char*>input_node_names={"input"};
    std::vector<const char*>output_node_names={"dets","labels","masks"};
public:
    SegmentOnnx() ;

    // static std::string assetFilePath( std::string assetName) ;

    bool loadModel( std::string modelName, ModelType modelType) ;

    bool loadModel( std::string modelName, ModelType modelType, float padding_value) ;

    // vector<uchar> readModelToByteArray( std::string modelName);

    // void release() ;

    std::vector<Ort::Value> forward_rtmdet_ins(cv::Mat input,std::string tmppath);

    cv::Mat forward(cv::Mat ori_input,  std::string modelName, ModelType modelType) ;


    cv::Mat preProcess(cv::Mat input, cv::Scalar scalar) ;

    std::vector<Ort::Value> matToTensor(const cv::Mat input, const bool RGB2BGR, std::vector<float>& floatBuffer);

//    void saveTensorToBinary(const std::vector<Ort::Value>& inputTensors, const std::string filename);
    
    //void printTensorData(const std::vector<Ort::Value>& inputTensors);
    
    std::vector<int> select(std::vector<std::vector<int>> boxes, std::vector<float> scores, std::vector<cv::Mat> masks);

    cv::Mat mask(cv::Mat output, std::vector<std::vector<int>> boxes, std::vector<int> class_ids, std::vector<cv::Mat> masks, std::vector<int> select, std::vector<cv::Mat> float_masks);

    cv::Mat postProcess(cv::Mat input, std::vector<Ort::Value>* output) ;

    cv::Mat postProcess_rtmdet_ins(cv::Mat input, std::vector<Ort::Value>* output) ;
    
};
#endif
