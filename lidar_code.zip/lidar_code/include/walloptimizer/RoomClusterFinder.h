#ifndef ROOMCLUSTERFINDER_H
#define ROOMCLUSTERFINDER_H
#include"geom/Utils.h"
#include"walloptimizer/AlignOptimizer.h"

    std::unordered_map<int, Graph> RoomClusterFinder(std::vector<Contour> contours, int supportLineClusterNum, cv::Mat floormask, int lineDistance, bool checkOverlap, bool checkIntersect, bool checkBigGap, bool checkLDK, bool checkSelf);

    Graph buildLDKClusterGraph(std::vector<Contour> contours, bool checkOverlap, bool checkIntersect, bool checkBig, int lineClusterId, cv::Mat floormask);

    Graph buildClusterGraph(std::vector<Contour> contours, bool checkOverlap, bool checkIntersect, bool checkBig, int lineClusterId, cv::Mat floormask);


    Graph buildBigGapGraph(std::vector<Contour> contours, int lineClusterId, cv::Mat floormask);

    Graph buildSelfGraph(std::vector<Contour> contours, cv::Mat floormask, int lineDistance);

    std::pair<bool, double> checkDistanceBtwLines(Line line1, Line line2, int distanceGap, bool checkOverlap, bool checkIntersect);


    bool checkGapOK(Line line1, Line line2, cv::Mat floorMask);


#endif