#ifndef ALIGNOPTIMIZER_H
#define ALIGNOPTIMIZER_H
#include <opencv2/opencv.hpp>
#include <boost/graph/adjacency_list.hpp>
#include "walloptimizer/RoomClusterFinder.h"
#include "walloptimizer/CenterPointStrategy.h"
#include "walloptimizer/MinMaskStrategy.h"
#include "voronoi/SegmentInfo.h"
#include "geom/Contour.h"
#include "geom/Line.h"
#include "geom/mPoint.h"
#include "geom/Utils.h"
#include <vector>
#include <map>
#include <set>
#include <iostream>
#include<cmath>
class AlignOptimizer
{

public:
    enum AlignStrategy
    {
        CENTER_POINT,
        MIN_MASK
    };

    cv::Mat getSemMask(SegmentInfo segmentInfo);

    void run(std::vector<Contour> &contours, cv::Mat floorMask, int supportLineClusterNum, int threshold, bool checkOverlap, bool checkIntersect, bool gapCheck, AlignStrategy strategy, bool byUniqueContour, bool checkLDK, bool checkSelf);

    static int encodeNode(int contourId, int lineId);

    static std::pair<int, int> decodeNode(int nodeId);

    static bool checkConflictInCluster(std::unordered_set<int> cluster, std::vector<Contour> contours);

    static void removeIncludedAngle(std::vector<Contour> &contours, double lenTH, double angle1, double angle2, bool isLdk, bool useCenter, cv::Mat mask);

    static void makeIntersection(Line &line1, Line &lineBefore, Line &lineAfter, cv::Mat mask, bool useCenter);

    static mPoint getCenter(mPoint p1, mPoint p2);

    static mPoint inMask(mPoint mPoint, cv::Mat mask);
    
    static void fixRightAngle(std::vector<Contour> &contours);
};

#endif
