#ifndef CENTERPOINTSTRATEGY_H
#define CENTERPOINTSTRATEGY_H
#include"geom/Utils.h"
#include"walloptimizer/AlignOptimizer.h"

void CenterPointStrategy(cv::Mat floormask, std::vector<Contour> &contours, Graph clusterGraph, bool byUniqueContour,int threshold);

#endif