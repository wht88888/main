#ifndef MINMASKSTRATEGY_H
#define MINMASKSTRATEGY_H
#include"geom/Utils.h"
#include"walloptimizer/AlignOptimizer.h"
#include"geos/operation/union/UnaryUnionOp.h"

bool checkContourValid(std::vector<Contour> contours);

    cv::Mat prepareInterMask(cv::Mat floormask, std::unordered_set<int> cluster, std::vector<Contour> contours);

    std::pair<double, std::pair<Line, Line>> getIntersectionBorder(std::unordered_set<int> cluster, std::vector<Contour> contours);

    Geometry *buildOutlinePoly(std::vector<Contour> contours);

    cv::Mat drawCursor(cv::Mat cursorMask, Line cursor);

    Line prepareCursor(mPoint startPoint, std::unordered_set<int> cluster, std::vector<Contour> contours);

    std::pair<mPoint, int> findBestCursorPoint(cv::Mat interMask, Line cursor, mPoint step, int sampleNum);

    int getLineLoss(cv::Mat interMask, Line line);

    std::vector<int> getClusterLosses(cv::Mat interMask, std::vector<Contour> contours, std::unordered_set<int> cluster);

    int getContourCoverMaskArea(cv::Mat floorMask, std::vector<Contour> contours);

    bool checkLongBoundaryLine(Geometry* outline, Line line, int dx, int dy);


void MinMaskStrategy(cv::Mat floormask, std::vector<Contour>& origContours, Graph clusterGraph, bool byUniqueContour);

#endif