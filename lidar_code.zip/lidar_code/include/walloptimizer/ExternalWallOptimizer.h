#ifndef EXTERNALWALLOPTIMIZER_H
#define EXTERNALWALLOPTIMIZER_H
#include "geom/Utils.h"

class ExternalWallOptimizer
{
private:
    int externalWallBuffer = 30;

public:
    void run(std::vector<Contour> &contours, int wallBuffer);

private:
    std::vector<Line> getExtremes(std::vector<Contour> contours);

    void moveLineToExtreme(std::vector<Contour> &contours, std::vector<Line> extremes);
};

#endif