#ifndef ROOMCUTTERBYWALLS_H
#define ROOMCUTTERBYWALLS_H
#include"geom/Utils.h"
#include"geom/PolyUtils.h"
#include"cutter/CutterUtils.h"
#include"cutter/BaseRoomCutter.h"

    std::vector<Contour> RoomCutterBywalls(std::vector<Contour> contours, cv::Mat floor_mask);

    void get_global_cut_lines(std::vector<Polygon*> polygons);

    std::pair<bool, Polygon*> cut_main_room(std::vector<Polygon*> polygons, Polygon* raw_poly, Polygon* ldk_poly);

    Polygon* cut_by_walls_strategy(Polygon* poly, Polygon* raw_poly, std::vector<LineString*> cut_lines, std::vector<Polygon*> ext_wall_lines);

    std::vector<Geometry*> filter_removed_parts(std::vector<Geometry*> parts);

    bool filter_room_part(Polygon* part_poly, Polygon* raw_poly, std::vector<Polygon*> ext_wall_lines);

    std::vector<LineString*> check_line_len_l1(std::vector<LineString*> lines);

    double compute_lines_angle(LineString* line);

    std::vector<double> get_ldk_wall_angles(Polygon* poly);

    std::vector<LineString*> filter_cut_line(std::vector<LineString*> cut_lines, std::vector<double> cut_line_angles, std::vector<double> ldk_wall_angles);


#endif