#ifndef BASEROOMCUTTER_H
#define BASEROOMCUTTER_H
#include"geom/Utils.h"
#include"geom/PolyUtils.h"



std::vector<Polygon*> build_raw_polygon(std::vector<cv::Point> cnt, cv::Mat floor_mask);

    std::vector<Polygon*> build_external_lines(std::vector<Polygon*> polygons);

    std::unique_ptr<LineString> affinity_scale(LineString* line);

    Polygon* approximate(Polygon* polygon);


#endif