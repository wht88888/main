#ifndef CORNERCUTTER_H
#define CORNERCUTTER_H
#include"geom/Utils.h"
#include"geom/PolyUtils.h"
#include"geom/HoughSupportLine.h"
#include"cutter/CutterUtils.h"


    std::vector<Contour> CornerCutter(std::vector<Contour> contours, cv::Mat floorMask, HoughSupportLine sl);

    std::vector<int> getCornerIdxs(Polygon* ldkFitPoly, Polygon* ldkRawPoly, std::vector<Polygon*> otherPolys);

    bool isRectOverlapWithRawLidar(CoordinateSequence* rectCoords, cv::Mat floorMask);

    Geometry* getRectFromCorner(gPoint* cornerPoint, Polygon* ldkPoly, Polygon* ldkRawPoly, cv::Mat floorMask, Polygon* floorPoly);

    Polygon* cutRectFromCorner(Polygon* ldkPoly, Polygon* ldkRawPoly, std::vector<int> targetCornerIdxs, cv::Mat floorMask, HoughSupportLine sl, Polygon* floorPoly);



#endif