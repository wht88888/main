#ifndef SLOPELINECUTTER_H
#define SLOPELINECUTTER_H
#include"geom/Utils.h"
#include"geom/PolyUtils.h"
#include"geom/HoughSupportLine.h"
#include"cutter/CutterUtils.h"
#include"geos/operation/buffer/OffsetCurve.h"

    std::vector<Contour> SlopeLineCutter(std::vector<Contour> contours, cv::Mat floorMask, HoughSupportLine sl, SegmentInfo segmentInfo);

    LineString* adjustLine(LineString* line, Polygon* ldkPoly);

#endif