#ifndef CUTTERUTILS_H
#define CUTTERUTILS_H
#include"geom/Utils.h"
#include"geom/HoughSupportLine.h"

bool checkLDKOrthogonal(Contour ldkContour, HoughSupportLine sl);

#endif