#ifndef VACUUMCLEANERHANDLER_H
#define VACUUMCLEANERHANDLER_H
#include<iostream>
#include<sstream>
#include<string>
#include<vector>
#include <boost/graph/adjacency_list.hpp>
#include "onnxruntime/onnxruntime_cxx_api.h"
#include <opencv2/opencv.hpp>
#include "voronoi/TopologicalSegmentation.h"
#include "geom/HoughSupportLineFinder.h"
#include "geom/FreeAngleBoxMaximizer.h"
#include "geom/Utils.h"
#include "walloptimizer/ExternalWallOptimizer.h"
#include "walloptimizer/AlignOptimizer.h"
#include "overlap/DoubleOverlapSolver.h"
#include "graphmerger/GroupMerger.h"
#include "cutter/CornerCutter.h"
#include "cutter/RoomCutterByWalls.h"
#include "cutter/SlopeLineCutter.h"
#include "nlohmann/json.hpp"

Line resizeDoor(Line door);

std::vector<Line> convertDoor2Line(SegmentInfo segmentInfo);

std::vector<Line> processOpenable(std::vector<Contour> contours, std::vector<Line> doors);

void fitOpenables(std::vector<Contour> contours, std::vector<Line>& doors, bool updateLine,int threhold);

std::pair<std::vector<Contour>,std::vector<Line>> fitFloorPlan(SegmentInfo segmentInfo, std::vector<Contour> contours, HoughSupportLine sl);

std::pair<std::pair<std::vector<std::vector<cv::Point>>,std::vector<Line>>,std::pair<cv::Mat,std::string>> run(std::string model_name,cv::Mat img);

cv::Mat cutBlack(cv::Mat img);

void classifyLinesAndCommit(std::vector<Contour> &contours,HoughSupportLine sl,int lineClusterNum);

void removeNotContour(std::vector<Contour> &contours);

bool isHorizontal(double angle);

bool isVertical(double angle);

std::vector<Contour> rectifyLDK(std::vector<Contour> contours, HoughSupportLine sl);

double getWallLength(mPoint p1,mPoint p2);

std::string addLeadingZeros(int number,int width);

std::vector<std::vector<int>> getOpeningsWallIds(std::vector<Contour> contours, std::vector<Line> doors);

std::string getIMDFString(std::vector<Contour> contours, std::vector<Line> openableContours, std::vector<std::vector<int>> openingWallIds);

#endif