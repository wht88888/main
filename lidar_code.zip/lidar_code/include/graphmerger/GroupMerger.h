#ifndef GROUPMERGER_H
#define GROUPMERGER_H
#include"geom/Utils.h"
#include"geom/PolyUtils.h"


std::vector<Contour> GroupMerger(std::vector<Contour> contours);

#endif