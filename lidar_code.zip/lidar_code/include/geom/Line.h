#ifndef LINE_H
#define LINE_H
#include <iostream>
#include <utility>
#include "geom/Utils.h"
#include "geom/mPoint.h"
#include "geom/Contour.h"
class Contour;
class Line
{
private:
    Contour *contour;
    int id;
    mPoint pointU;
    mPoint pointV;
    int pointUId;
    int pointVId;
    int cluster = -1;
    bool hasDoor = false;
    bool changed = false;
    bool selected = false;

public:
    int getCluster();

    void setId(int id);

    int getId();

    void setCluster(int cluster);

    bool isChanged();

    void setChanged(bool changed);

    bool isSelected();

    void setSelected(bool selected);

    bool isHasDoor();

    void setHasDoor(bool hasDoor);

    Line(Contour *contour, int id, mPoint u, mPoint v, int uId, int vId);

    Line();

    void move(int dx, int dy);

    void rotate(double angle);

    mPoint center();

    double angle();

    mPoint getU();

    void setU(mPoint point);

    mPoint getV();

    void setV(mPoint point);

    int getUid();

    void setUid(int pointId);

    int getVid();

    void setVid(int pointId);

    double length();

    Line copy();

    std::string toString();
};
#endif