#ifndef LINECLUSTERDBSCAN_H
#define LINECLUSTERDBSCAN_H
#include <algorithm>
#include <deque>
#include <iostream>
#include <vector>
#include <unordered_map>
#include <cmath>
#include"geom/ClusterItem.h"

using std::deque;
using std::vector;

struct Point2d
{
    float x = 0.0f;
    float y = 0.0f;
};

template <class T> class DBScan
{
  private:
    int _min_num;

    double _eps;

    vector<int> _labels;

    vector<vector<double>> _distance_mat;

    inline double GetDistanceAngle(ClusterItem c1,ClusterItem c2){
        vector<double> a = c1.getPoint();
        vector<double> b = c2.getPoint();
        double lhs = a[0]*M_PI/180.0;
        double rhs = b[0]*M_PI/180.0;
        double diff1 = cos(lhs - rhs);
        if(diff1<0)
            diff1*=-1;
        double diff2 = cos(lhs - rhs + M_PI);
        if(diff2<0)
            diff2*=-1;
        if (diff1 > diff2) {
            diff1 = diff2;
        }
        double d = acos(diff1)*180.0/M_PI;
        return d;
    }
    inline double GetDistance(ClusterItem c1,ClusterItem c2){
        vector<double> a = c1.getPoint();
        vector<double> b = c2.getPoint();
        double dis=sqrt(pow((a[0]-b[0]),2)+pow((a[1]-b[1]),2));
        return dis;
    }

    int Run(const vector<T> &all_pts,bool is_angle);

    bool ExpandCluster(int pt_idx, int &cluster_idx);

  public:

    DBScan(float eps, int min_num) : _eps(eps), _min_num(min_num){}

    ~DBScan(){}

    vector<vector<T>> GetClusters(std::vector<T> all_pts,bool is_angle);

    vector<int> GetLabels(){ return _labels;}
};

template <typename T> int DBScan<T>::Run(const vector<T> &all_pts,bool is_angle)
{
    int size = all_pts.size();
    int cluster_idx = 1;

    _labels.resize(size, 0);

    _distance_mat.clear();
    for (int i = 0; i < size; ++i){
        vector<double> vec(size,0);
        _distance_mat.push_back(vec);
    }

    for (int i = 0; i < size; ++i)
    {
        for (int j = i; j < size; ++j)
        {
            if (i != j)
            {
                if(is_angle){
                    _distance_mat[i][j] = GetDistanceAngle(all_pts.data()[i], all_pts.data()[j]);
                }
                else{
                    _distance_mat[i][j] = GetDistance(all_pts.data()[i], all_pts.data()[j]);
                }
                _distance_mat[j][i] = _distance_mat[i][j];
            }
        }
    }

    for (size_t i = 0; i < size; i++)
    {
        if (_labels[i] != 0)
            continue;
        ExpandCluster(i, cluster_idx);
    }

    return cluster_idx - 1;
}

template <typename T> bool DBScan<T>::ExpandCluster(int pt_idx, int &cluster_idx)
{
    deque<int> seeds_idx;
    seeds_idx.emplace_back(pt_idx);
    for (size_t col = 0; col < _distance_mat.size(); col++)
    {
        if (col == pt_idx) continue;
        if (_distance_mat[pt_idx][col] < _eps)
        {
            seeds_idx.emplace_back(col);
        }
    }

    if (seeds_idx.size() <= _min_num)
    {
        _labels[pt_idx] = -1;
        return false;
    }
    for (size_t i = 0; i < seeds_idx.size(); i++)
    {
        _labels[seeds_idx[i]] = cluster_idx;
    }

    seeds_idx.pop_front();
    while (!seeds_idx.empty())
    {
        auto &row = seeds_idx.front();
        vector<int> temp_idx;
        temp_idx.reserve(_distance_mat.size());
        for (size_t col = 0; col < _distance_mat.size(); col++)
        {
            if (_distance_mat[row][col] <= _eps)
                temp_idx.emplace_back(col);
        }
        if (temp_idx.size() > _min_num)
        {
            for (size_t i = 0; i < temp_idx.size(); i++)
            {
                if (_labels[temp_idx[i]] >= 1)
                    continue;
                if (_labels[temp_idx[i]] == 0)
                    seeds_idx.emplace_back(temp_idx[i]);
                _labels[temp_idx[i]] = cluster_idx;
            }
        }

        seeds_idx.pop_front();
    }

    cluster_idx++;
    return true;
}
template <typename T> vector<vector<T>> DBScan<T>::GetClusters(std::vector<T> all_pts,bool is_angle)
{
    int clusters_num = this->Run(all_pts,is_angle);
    vector<vector<T>> result(clusters_num);

    for (size_t i = 0; i < _labels.size(); i++)
    {
        auto &label = _labels[i];
        if(label == -1)
        {
            continue;
        }

        result[label-1].emplace_back(all_pts[i]);
    }
    return result;
}
    const int UNCLUSTER_LABEL = -1;

    vector<ClusterItem> buildPointFromLineAngle(vector<double> lineAngles);

    double getClusterMedia(vector<double> lineAngles, vector<int> lineWeights);

    vector<double> getClusterMedians(vector<int> clusterLabels, vector<double> lineAngles, vector<int> lineWeights);

    std::pair<vector<int>, vector<double>> cluster(vector<double> lineAngles, vector<int> lineWeights,float eps,int min_num);

#endif