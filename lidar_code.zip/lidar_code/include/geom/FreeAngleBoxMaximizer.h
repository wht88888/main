#ifndef FREEANGLEBOXMAXIMIZER_H
#define FREEANGLEBOXMAXIMIZER_H
#include<vector>
#include<unordered_set>
//#include"geos_c.h"
#include<geos/operation/buffer/OffsetCurve.h>
#include"geom/PolyUtils.h"
#include"geom/Utils.h"
#include"geom/HoughSupportLine.h"
#include"geom/HoughSupportLineFinder.h"

class FreeAngleBoxMaximizer {

private:
    int maxLine2PointDist = 10;
    int minLineWeightTh = 10;
    double angleEps = 20;

    static double angleCluster(double angle);

   std::vector<int> calcAngleClustersConnectionMatrix(std::vector<double> clusterValues);

    void normClusterWeights(std::vector<double> clusterValues,std::vector<int> &clusterWeights,std::vector<int> &clusterNums);

    double getRectAngle(std::vector<cv::Point> contour, HoughSupportLine sl);

    std::vector<mPoint> getMinimalRect(std::vector<cv::Point> contour, double angle);
public:
   std::vector<std::vector<cv::Point>> run(std::vector<SegmentRoom> rooms, HoughSupportLine sl, cv::Mat floorMask);
private:
    bool isInnerLine(LineString* line, cv::Mat floorMask);

    LineString* shrinkLine(LineString* line, Polygon* rawPoly);
};

#endif
