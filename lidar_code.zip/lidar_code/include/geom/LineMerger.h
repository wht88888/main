#ifndef LINEMERGER_H
#define LINEMERGER_H
#include<vector>
#include<unordered_set>
#include<opencv2/opencv.hpp>
#include"geom/ClusterItem.h"
#include"geom/LineClusterDBSCAN.h"
#include"geom/Utils.h"
#include"geom/Line.h"
#include"geom/HoughSupportLine.h"

    std::vector<ClusterItem> buildClusterLines(std::vector<Line> lines, double angle);

    std::pair<std::vector<std::vector<ClusterItem>>, std::unordered_set<int>> clusterCloseLines(std::vector<Line> lines, double angle, double eps);

    Line getMedianLine(std::vector<Line> lines, double angle, std::vector<int> lineWeights);

    void mergeCluster(HoughSupportLine sl, int clusterId, std::vector<std::vector<cv::Point>> contours, std::vector<Line>& resLines, std::vector<double>& resAngles, std::vector<int>& resWeights, std::vector<int>& resClusterIds);

    HoughSupportLine mergeSupportLine(HoughSupportLine supportLine, std::vector<std::vector<cv::Point>> contours);

#endif
