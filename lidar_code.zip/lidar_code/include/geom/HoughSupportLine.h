#ifndef HOUGHSUPPORTLINE_H
#define HOUGHSUPPORTLINE_H
#include<iostream>
#include<vector>
#include"geom/Line.h"
class HoughSupportLine {

private:
    std::vector<Line> lineCoords;
    std::vector<int> lineWeights;
    std::vector<int> clusterId;
    std::vector<double> lineAngles;
    std::vector<double> clusterValues;

public:
    std::vector<Line> getLineCoords() ;

    std::vector<int> getLineWeights() ;

    std::vector<int> getClusterId() ;

    std::vector<double> getLineAngles() ;

    std::vector<double> getClusterValues() ;

    HoughSupportLine(std::vector<Line> lineCoords, std::vector<int> lineWeights, std::vector<int> clusterId, std::vector<double> lineAngles, std::vector<double> clusterValues);
};


#endif