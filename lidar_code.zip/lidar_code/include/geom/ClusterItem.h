#ifndef CLUSTERITEM_H
#define CLUSTERITEM_H
#include <vector>
class ClusterItem{

private:
    std::vector<double> point;
    int idx;

public:

    ClusterItem(std::vector<double> point, int idx);

    int getIdx();

    std::vector<double> getPoint();

    bool equals(ClusterItem other);

};
#endif