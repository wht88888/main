#ifndef CONTOUR_H
#define CONTOUR_H
#include <iostream>
#include <string>
#include <vector>
#include <unordered_set>
#include <map>
#include<geos/geom/Polygon.h>
#include <opencv2/opencv.hpp>
#include "geom/Line.h"
#include "geom/mPoint.h"
#include "geom/Utils.h"
#include "geom/PolyUtils.h"
class Line;
class Contour
{
public:
    std::string FIX_POINT = "fix_points";
    std::string FIX_ANGLE = "fix_angles";

private:
    std::string connection = FIX_POINT;
    std::vector<mPoint> contourPoints;
    std::vector<Line> lines;
    std::unordered_map<int, std::vector<int>> pointId2LineIdDict;
    std::string label = "BedRoom";
    int groupId;
    int shapeId;

public:
    Contour(std::string connection, std::vector<cv::Point> contour, std::string label, int groupId, int shapeId);

    Contour();

    std::string getLabel();

    int getGroupId();

    int getShapeId();

    void setLabel(std::string label);

    void setConnection(std::string connection);

    void setPointId2LineIdDict(std::unordered_map<int, std::vector<int>> pointId2LineIdDict);

    void setGroupId(int groupId);

    void setShapeId(int shapeId);

    Contour copy();

    std::vector<Line> getLines();

    void setLines(std::vector<Line> lines);

    std::vector<mPoint> getContourPoints();

    void setContourPoints(std::vector<mPoint> points);

    static std::vector<mPoint> getPointList(std::vector<cv::Point> contour);

    static std::vector<cv::Point> getContourFromPoints(std::vector<mPoint> pointList);

    void buildLines(std::vector<mPoint> contourPoints);

    void updateIndex();

    void updateLines();

    void updateByFixPoints(Line line);

    void updateByFixPoint(mPoint point, int pointId);

    void updateByFixAngles(Line line);

    void updateByFixAngle(mPoint point, int pointId, Line line);

    void update(Line line);

    double angle(Line line);

    double norm(double x);

    void commit(int clusterNum, std::string connection, int minAngle, int maxAngle, int quantization);

    geos::geom::Polygon* getPoly();
};
#endif