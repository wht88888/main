#ifndef HUNGARIANALGORITHM_H
#define HUNGARIANALGORITHM_H
#include<vector>
#include<cmath>
#include<iostream>
#include<float.h>

class HungarianAlgorithm {
private:
    std::vector<std::vector<double>> costMatrix;
    int rows, cols, dim;
    std::vector<double> labelByWorker, labelByJob;
    std::vector<int> minSlackWorkerByJob;
    std::vector<double> minSlackValueByJob;
    std::vector<int> matchJobByWorker, matchWorkerByJob;
    std::vector<int> parentWorkerByCommittedJob;
    std::vector<bool> committedWorkers;

public:
    HungarianAlgorithm(std::vector<std::vector<double>> costMatrix);

    void computeInitialFeasibleSolution();

    std::vector<int> execute();

    void executePhase();

    int fetchUnmatchedWorker();

    void greedyMatch();

    void initializePhase(int w);

    void match(int w, int j);
    
    void reduce();

    void updateLabeling(double slack);
};


#endif