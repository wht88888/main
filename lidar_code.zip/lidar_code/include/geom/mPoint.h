#ifndef MPOINT_H
#define MPOINT_H
#include <iostream>
#include <string>
#include <cmath>

class mPoint
{
public:
        int x;
        int y;

        mPoint();

        mPoint(int x, int y);

        void move(int dx, int dy);

        void scale(double sx, double sy);

        mPoint subtract(mPoint pt);

        mPoint add(mPoint pt);

        std::string toString();
};
#endif