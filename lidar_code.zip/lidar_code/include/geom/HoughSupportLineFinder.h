#ifndef HOUGHSUPPORTLINEFINDER_H
#define HOUGHSUPPORTLINEFINDER_H
#include<vector>
#include<opencv2/opencv.hpp>
#include"geom/Line.h"
#include"geom/LineMerger.h"
#include"geom/LineClusterDBSCAN.h"
#include"geom/HoughSupportLine.h"
#include"geom/Utils.h"
#include"voronoi/Util.h"

class HoughSupportLineFinder {
private:
    int maxPoint2LineDist;
    int minLineLength;
    int maxLineGap;
    float eps;
    int min_num;

public:
    HoughSupportLineFinder(int maxPoint2LineDist, int minLineLength, int maxLineGap,float eps,int min_num) ;

    HoughSupportLine run(cv::Mat floormask) ;

    std::vector<Line> getLinesByMask(cv::Mat maskMat, int minLineLength, int maxLineGap) ;

    std::vector<double> computeLineAngle(std::vector<Line> lines) ;

    Line transformLine(Line line, double angle) ;

    std::vector<int> filterLinesIdxByWeight(std::vector<Line> lines, std::vector<int> weights, std::vector<std::vector<cv::Point>> contours, int maxDist, int thresh) ;

    static std::pair<cv::Mat, cv::Mat> getDebugImage(HoughSupportLine sl, cv::Mat floorMask);
};



#endif