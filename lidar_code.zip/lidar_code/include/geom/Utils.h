#ifndef UTILS_H
#define UTILS_H
#include <vector>
#include <algorithm>
#include <opencv2/opencv.hpp>
#include<geos/geom/Geometry.h>
#include<geos/geom/Coordinate.h>
#include<geos/geom/Polygon.h>
#include <geos/simplify/TopologyPreservingSimplifier.h>
#include <boost/variant.hpp>
#include "geom/mPoint.h"
#include "geom/Line.h"
#include "geom/Contour.h"
#include "geom/PolyUtils.h"
class Line;
class Contour;

double getNorm(int x, int y);

double getNorm(double x, double y);

double getNorm(mPoint point);

double det(double x1, double y1, double x2, double y2);

double det(mPoint p1, mPoint p2);

double getPointDist(mPoint p1, mPoint p2);

double getPointDist(std::pair<double, double> p1, std::pair<double, double> p2);

double pointDot(mPoint p1, mPoint p2);

double pointDot(std::pair<double, double> p1, std::pair<double, double> p2);

std::pair<double, double> normPoint(std::pair<double, double> pt);

bool samePoint(mPoint p1, mPoint p2);

double lineIntersectionAngle(Line line1, Line line2);

std::pair<mPoint, bool> getIntersection(Line line1, Line line2);

mPoint projPointOnLine(int px, int py, int p1x, int p1y, int p2x, int p2y);

mPoint projPointOnLine(mPoint point, mPoint p1, mPoint p2);

mPoint projPointOnLine(mPoint point, Line line);

bool isPointProjectOnInnerSegment(mPoint point, Line line, int boundaryTh);

double point2LineDistance(mPoint point, Line line);

bool isPointProjectOnInnerSegment(mPoint point, mPoint p1, mPoint p2, int boundaryTh);

bool isLineBoundaryIntersect(Line line1, Line line2, int boundaryTh);

Line shrinkLine(Line line, double shrinkPercent);

Line getPerpendicularLine(double x0, double y0, double vx, double vy, int distance);

Line vector2PointLine(double vx, double vy, double x, double y, int ww, int hh);

double getBboxDiagonal(std::vector<Line> lines);

std::vector<mPoint> getBoundingRect(std::vector<mPoint> points);

mPoint getWeightedPoint(std::vector<mPoint> points, std::vector<int> weights);

std::vector<int> computeLineWeight(std::vector<Line> lines, std::vector<std::vector<cv::Point>> contours, double distTh);

int computeLineWeight(Line line, std::vector<cv::Point> contour, double distTh);

int computeLineWeight_box(Line line, std::vector<cv::Point> contour, double distTh);

int computeLineWeight(int h, int w, Line line, geos::geom::Polygon* poly, double distTh);

mPoint computeCenterOfContour(std::vector<cv::Point> contour);

mPoint rotatePoint(mPoint point, mPoint center, double angle);

std::vector<mPoint> mergeContourPoints(std::vector<mPoint> points, double minDistance);

void classifyLines(Contour &contour, std::vector<double> clusterAngles, double angelTh);

std::vector<double> angleDistance(std::vector<double> angle1s, double angle2);

std::vector<Contour> buildResolvedContours(std::vector<geos::geom::Geometry*> geometries, std::vector<Contour> contours);

Contour buildResolvedContour(geos::geom::Geometry *geometry, Contour contour);

#endif