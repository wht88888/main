#ifndef POLYUTILS_H
#define POLYUTILS_H
#include<geom/Utils.h>
#include<voronoi/Util.h>
#include"voronoi/SegmentInfo.h"
#include<geos/geom/GeometryFactory.h>
#include<geos/simplify/TopologyPreservingSimplifier.h>
#include<geos/geom/util/GeometryFixer.h>
#include<geos/algorithm/Orientation.h>
#include<memory>
typedef geos::geom::Geometry Geometry;
typedef geos::geom::Polygon Polygon;
typedef geos::geom::MultiPolygon MultiPolygon;
typedef geos::geom::Coordinate Coordinate;
typedef geos::geom::CoordinateSequence CoordinateSequence;
typedef geos::geom::LineString LineString;
typedef geos::geom::MultiLineString MultiLineString;
typedef geos::geom::GeometryFactory GeometryFactory;
typedef geos::geom::GeometryCollection GeometryCollection;
typedef geos::geom::LinearRing LinearRing;
typedef geos::geom::Point gPoint;

class Line;
class Contour;

    Polygon *createEmptyPolygon();

    LineString *createEmptyLineString();

    gPoint * createEmptyPoint();

    Polygon *createPolygon(CoordinateSequence coords);

    Polygon *createPolygon(std::vector<mPoint> points);

    std::unique_ptr<LineString> createLineStringUnique(CoordinateSequence coords);

    LineString *createLineString(CoordinateSequence coords);

    LineString *createLineString(mPoint p1, mPoint p2);

    gPoint *createPoint(Coordinate coord);


    gPoint *createPoint(mPoint point);

    std::vector<Polygon*> geometryCollection2Polygons(GeometryCollection* collection);

    MultiLineString *createMultiLineString(std::vector<std::unique_ptr<LineString>> lines);

    std::pair<bool, Polygon*> makeValidRoom(Geometry *poly);

    Polygon *points2Poly(std::vector<mPoint> points);

    Polygon *points2Poly(std::vector<cv::Point> contour);


    std::vector<Polygon*> buildRawPolygons(SegmentInfo segmentInfo);

    Polygon* makePolygonCCW(Polygon* poly);

    std::vector<LineString*> polygon2Lines(Polygon* poly);

    std::vector<LineString*> geometryCollection2Lines(Geometry* geometry);

    std::vector<LineString*> getRoomsLines(std::vector<Polygon*> polygons);

    Polygon* buildRawPolygon(Contour contour, cv::Mat floorMask);

    Polygon* buildRawPolygon(std::vector<mPoint> contourPoints, cv::Mat floorMask);

    std::vector<std::pair<Polygon*, Contour>> getRoomPolygons(std::vector<Contour> contours);


    LineString* extendLine(int h, int w, Line line) ;

#endif
