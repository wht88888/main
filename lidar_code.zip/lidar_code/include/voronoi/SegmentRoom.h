#ifndef SEGMENTROOM_H
#define SEGMENTROOM_H
#include<opencv2/opencv.hpp>
#include<iostream>

class SegmentRoom {
    private:
     std::vector<cv::Point> contours;
     int groupId;
     int shapeId;
     std::string roomType;

     public:

     SegmentRoom(std::vector<cv::Point> contours, int groupId, int shapeId, std::string roomType) ;

     std::vector<cv::Point> getContours();

     int getGroupId() ;

     int getShapeId() ;

     std::string getRoomType() ;

     void setRoomType(std::string roomType);
};

#endif
