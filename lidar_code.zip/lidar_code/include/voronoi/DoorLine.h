#ifndef DOORLINE_H
#define DOORLINE_H
#include<iostream>

class DoorLine {
    private:
    double doorLen;
    double doorAngle;
    std::pair<int, int> startNodeCoord;
    std::pair<int, int> endNodeCoord;
    int nodeId;

    public:
    //  bool equals(Object o) ;

    
    //  int hashCode() ;

    DoorLine(double doorLen, double doorAngle, std::pair<int, int> startNodeCoord, std::pair<int, int> endNodeCoord, int nodeId);

    std::pair<int, int> getStartNodeCoord();

    std::pair<int, int> getEndNodeCoord() ;
};

#endif