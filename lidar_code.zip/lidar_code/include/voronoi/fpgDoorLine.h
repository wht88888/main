
#ifndef VACCUMMAP_FPGDoorLine_H
#define VACCUMMAP_FPGDoorLine_H

class fpgDoorLine {
public:
    double doorCosAngle;
    double doorLen;
    int nodeID;

    fpgDoorLine(double len, double angle, int id):
            doorCosAngle(angle), doorLen(len), nodeID(id) {

    }
};

#endif