#ifndef TOPOLOGICALSEGMENTATION_H
#define TOPOLOGICALSEGMENTATION_H
#include<opencv2/opencv.hpp>
#include<opencv2/ximgproc.hpp>
#include<vector>
#include<unordered_map>
#include<unordered_set>
#include<map>
#include<unordered_map>
#include<boost/graph/adjacency_list.hpp>
#include"voronoi/DoorLine.h"
#include"voronoi/ArtifactFilter.h"
#include"voronoi/SegmentInfo.h"
#include"voronoi/Util.h"
#include"segment/SegmentOnnx.h"
// struct VertexProperty{
//     int index;
// };
// typedef boost::adjacency_list<boost::vecS, boost::vecS, boost::undirectedS,VertexProperty> Graph;

class TopologicalSegmentation {
private:
    ArtifactFilter artifactFilter = ArtifactFilter(15625, 1300, 70, 3.5);

    SegmentOnnx segmentor = SegmentOnnx();
    // MapData mapData = null;


public:

    void initSegmentModel(std::string modelName);

    SegmentInfo applySegmentation(cv::Mat binaryMask) ;

    SegmentInfo applySegmentation(std::string modelName, cv::Mat binaryMask);
};

#endif
