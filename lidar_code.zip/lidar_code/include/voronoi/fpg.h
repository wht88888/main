#ifndef FPG_H
#define FPG_H
#include <opencv2/opencv.hpp>
#include <utility>
#include <algorithm>
#include <iterator>
#include <boost/graph/graph_traits.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/dijkstra_shortest_paths.hpp>
#include <cmath>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <boost/graph/kruskal_min_spanning_tree.hpp>
#include <boost/graph/connected_components.hpp>
#include "voronoi/fpgDoorLine.h"

typedef std::pair<int, int> E;
typedef boost::adjacency_list<boost::vecS, boost::vecS, boost::undirectedS, boost::no_property, boost::property<boost::edge_weight_t, int>> Graphfpg;
typedef boost::graph_traits<Graphfpg>::edge_descriptor Edge;
typedef boost::graph_traits<Graphfpg>::vertex_descriptor Vertex;

double getL2Dist(int x1, int y1, int x2, int y2);

double getCosin(int u1, int v1, int u2, int v2);

 void getNeighbours(unsigned char *data, int width, int i, int j, std::vector<int> &neighborVec);

 std::vector<int> getCandidateNode(std::unordered_set<int> roomNodes, Graphfpg graph, int distTh, std::vector<int> coords,bool isMinDist) ;

 std::vector<int>
getCandidateNode(std::unordered_set<int> roomNodes, Graphfpg graph, int distTh, std::vector<int> coords,
                 bool isMinDist, std::unordered_map<int, std::vector<int>> &backpaths,
                 int backlen);

std::vector<fpgDoorLine>
getCriticalLine(std::vector<int> contourCoords, int contourPointNum, std::vector<int> doorNodes,
                std::vector<int> coords) ;

std::pair<std::unordered_set<int>, std::unordered_map<int, std::pair<int, int>>>
getDoorFromPairCluster(std::vector<int> contourCoords, int contourPointNum,
                       Graphfpg graph, std::vector<int> candidate1,
                       std::vector<int> candidate2,
                       std::unordered_map<int, std::vector<int>> backpaths,
                       std::unordered_set<int> whiteNodes, int searchDistTh,
                       std::unordered_map<int, int> distMap,
                       std::vector<int> coords, bool strictMode);

uchar * getMinDistNative(std::vector<int> coords,
                int width, int height,
                uchar * skeleton_ptr,
                uchar * distMat_ptr);

std::tuple<std::vector<int>,std::vector<int>,std::unordered_map<int,int>> nativeSkeletonAnalysis(uchar* skeleton_ptr,
                        int width,
                        int height);

std::tuple<std::vector<int>,std::vector<int>,std::vector<int>> nativeGetDoorPos(
                    std::vector<int> floor_coutours_array,
                    std::vector<int> ldk_length_array,
                    std::vector<int> ldk_flat_array,
                    std::vector<int> room_length_array,
                    std::vector<int> room_flat_array,
                    std::vector<int> corridor_length_array,
                    std::vector<int> corridor_flat_array,
                    std::vector<int> white_flat,
                    int vertext_num,
                    std::vector<int> flat_edges,
                    std::vector<int> flat_dist_map,
                    std::vector<int> flat_coords_array,
                    std::vector<int> new_roomid_array);

#endif
