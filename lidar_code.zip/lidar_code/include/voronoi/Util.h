#ifndef UTIL_H
#define UTIL_H
#include <opencv2/opencv.hpp>
#include <vector>
#include <set>
#include <unordered_set>
#include <map>
#include <unordered_map>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/connected_components.hpp>
#include <boost/graph/graph_utility.hpp>
#include <boost/graph/dijkstra_shortest_paths.hpp>
#include <boost/graph/breadth_first_search.hpp>
#include "voronoi/DoorLine.h"
struct VertexProperty
{
    int index;
};
typedef boost::adjacency_list<boost::vecS, boost::vecS, boost::undirectedS, VertexProperty> Graph;
typedef boost::graph_traits<Graph>::vertex_iterator vertex_iter;
typedef boost::graph_traits<Graph>::edge_iterator edge_iter;
typedef boost::graph_traits<Graph>::adjacency_iterator adjacency_iter;
typedef boost::graph_traits<Graph>::vertex_descriptor Vertex;
typedef boost::graph_traits<Graph>::edge_descriptor Edge;

cv::Mat distTransform(cv::Mat binary_image);

cv::Mat iPhoneGetBinaryImage(cv::Mat image);

cv::Mat getBinaryImage(cv::Mat image);

cv::Mat binary2Show(cv::Mat binaryMat);

cv::Mat binary2ShowGray(cv::Mat binaryMat);

std::pair<std::vector<std::vector<cv::Point>>, cv::Mat> getContourTree(cv::Mat mask);

double getL2Dist(int x, int y, cv::Point point2);

double getL2Dist(std::pair<int, int> p1, std::pair<int, int> p2);

double getL2Dist(double x, double y, cv::Point point2);

double getL2Dist(cv::Point point1, cv::Point point2);

double getCosin(double u1, double v1, double u2, double v2);

std::vector<std::pair<int, int>> peakLocalMax(cv::Mat mask, cv::Mat distMat, int minDistance, double distTh);

cv::Mat segment2Color(cv::Mat segmentMat);

Graph removeIsolatedCycle(Graph &baseGraph);

Graph removeNoneCriticalNodes(Graph &baseGraph, std::unordered_set<int> criticalNodes, std::vector<std::pair<int, int>> coords);

inline std::vector<Vertex> neighborList(Graph &baseGraph, Vertex nodeId);

void removeEdge(Graph &baseGraph, Vertex sourceID, Vertex targetID);

Graph removeSingle(Graph &baseGraph, std::unordered_set<int> criticalNodes);

Graph removepair(Graph &baseGraph, std::unordered_set<int> criticalNodes);

Vertex getMinDistNeighbor(Graph &baseGraph, int nodeId, std::vector<std::pair<int, int>> coords);

Graph copySimpleGraph(Graph &simpleGraph);

Graph removeTriplet(Graph &baseGraph, std::unordered_set<int> criticalNodes, std::vector<std::pair<int, int>> coords);

cv::Mat roomMergeDebug(cv::Mat floormask, std::vector<std::unordered_set<int>> ldkList, std::vector<std::unordered_set<int>> corridorList, std::vector<std::unordered_set<int>> roomList, std::unordered_set<int> whiteNodes, std::vector<std::pair<int, int>> coords);

std::unordered_set<int> getShortestPath(Graph &baseGraph, Graph &searchGraph);

std::unordered_set<int> getNeighbor3(Graph &baseGraph, cv::Mat distMat, std::vector<std::pair<int, int>> coords);

std::unordered_set<int> correctNodeSet(Graph &graph, std::unordered_set<int> nodeSet, cv::Mat distMat, std::vector<std::pair<int, int>> coords);

std::pair<std::unordered_set<int>, std::tuple<std::vector<std::unordered_set<int>>, std::vector<std::unordered_set<int>>, std::vector<std::unordered_set<int>>>> convertSegmentToGraph(cv::Mat maskrcnnMat, std::unordered_set<int> nodeSet, std::vector<std::pair<int, int>> coords);

Graph getSubGraph(Graph &baseGraph, std::unordered_set<int> nodeSet);

std::pair<std::unordered_set<int>, std::tuple<std::vector<std::unordered_set<int>>, std::vector<std::unordered_set<int>>, std::vector<std::unordered_set<int>>>> fixConnectivity(double scaleBoost, int height, int width, Graph &baseGraph,
                                                                                                                                                                                 std::vector<std::unordered_set<int>> ldkNodes, std::vector<std::unordered_set<int>> roomNodes, std::vector<std::unordered_set<int>> corridorNodes, std::unordered_set<int> whiteNodes, std::vector<std::pair<int, int>> coords);

std::vector<std::unordered_set<int>> filterSmallAreaAndMerge(int roomNodeTh, Graph &baseGraph, std::vector<std::unordered_set<int>> roomList,
                                                             std::unordered_set<int> whiteNodes);

std::vector<DoorLine> getCriticalLine(std::vector<std::vector<cv::Point>> contours, std::vector<int> doorList, std::vector<std::pair<int, int>> coords, std::unordered_map<int, float> distMap);

std::unordered_map<int, float> convertToDistMap(cv::Mat distMat, std::unordered_set<int> nodeSet, std::vector<std::pair<int, int>> coords);

void getDoorPostionDebug(cv::Mat debugMat, std::vector<DoorLine> corridorDoors, std::vector<DoorLine> corridorCorridorDoors, std::vector<DoorLine> doors);

#endif
