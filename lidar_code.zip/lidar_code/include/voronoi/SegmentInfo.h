#ifndef SEGMENTINFO_H
#define SEGMENTINFO_H
#include<opencv2/opencv.hpp>
#include"voronoi/SegmentRoom.h"
#include"voronoi/DoorLine.h"
#include<set>
#include<cstddef>
#include<iostream>



class SegmentInfo {
    private:
    int LDK_LABEL = 100;
    cv::Mat floorMask;
    std::vector<SegmentRoom> rooms;

    std::vector<DoorLine> doors;
    public:

    cv::Mat getFloorMask() ;

    std::vector<SegmentRoom> getRooms();

    std::vector<DoorLine> getDoors() ;

    std::vector<std::vector<cv::Point>> getRoomsByDoors(cv::Mat floormask, std::vector<DoorLine> doors) ;

    SegmentInfo(std::vector<DoorLine> doors, std::vector<DoorLine> corridors, std::vector<DoorLine> corridorCorridors, cv::Mat floorMask, cv::Mat instanceMask, int areaTh) ;
};

#endif
