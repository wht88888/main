#ifndef ARTIFACTFILTER_H
#define ARTIFACTFILTER_H
#include<opencv2/opencv.hpp>
#include<opencv2/ximgproc.hpp>
#include<boost/graph/adjacency_list.hpp>
#include<vector>
#include<set>
#include<unordered_set>
#include<map>
#include<unordered_map>
#include"geom/Contour.h"
#include"voronoi/Util.h"
#include"voronoi/NativeUtils.h"

class ArtifactFilter {
private:
    int room_area_lower_bound;
    int hole_area_bound;
    int graph_diameter_th;
    double wall_width_th;
    int width;
    int height;
    // MapData mapData = null;

public:
    ArtifactFilter(int room_area_lower_bound, int hole_area_bound, int graph_diameter_th, double wall_width_th);

    // Mat run(Mat floormask, boolean outputBinary, MapData mapData);

    cv::Mat run(cv::Mat floormask, bool outputBinary);


    std::vector<std::vector<cv::Point>> filterRoom(std::vector<std::vector<cv::Point>> floorContours);

    std::vector<std::vector<cv::Point>> filterHole(std::vector<std::vector<cv::Point>> holeContours);
};

#endif
