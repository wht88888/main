#ifndef NATIVEUTIL_H
#define NATIVEUTIL_H
#include<opencv2/opencv.hpp>
#include<boost/graph/adjacency_list.hpp>
#include<vector>
#include<set>
#include<unordered_set>
#include<map>
#include<unordered_map>
#include"voronoi/DoorLine.h"
#include"voronoi/fpg.h"
#include"voronoi/Util.h"

cv::Mat getMinDistMaskByP2(std::vector<std::vector<cv::Point>> contours, cv::Mat skeleton);

std::tuple<Graph, std::vector<std::pair<int, int>>, std::unordered_map<int, int>> skeletonAnalysis(cv::Mat skeleton);

std::tuple<std::vector<DoorLine>, std::vector<DoorLine>, std::vector<DoorLine>> getDoorPos(cv::Mat mergeDebugMat, 
                                                                std::vector<std::vector<cv::Point>> floorContours, 
                                                                std::vector<std::unordered_set<int>> ldkvector, 
                                                                std::vector<std::unordered_set<int>> roomvector,
                                                                std::vector<std::unordered_set<int>> corridorvector, 
                                                                std::unordered_set<int>  whiteNodes, 
                                                                Graph graph, 
                                                                std::unordered_map<int, float> distMap,
                                                                std::unordered_set<int> newRoomIdset, 
                                                                std::vector<std::pair<int, int>> coords);

#endif
