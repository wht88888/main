#include "lidarmap/VacuumCleanerHandler.h"
#include <cstring>
#include <cmath>
#include <algorithm>

