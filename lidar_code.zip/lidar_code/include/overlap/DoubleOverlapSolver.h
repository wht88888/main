#ifndef DOUBLEOVERLAPSOLVER_H
#define DOUBLEOVERLAPSOLVER_H
#include"geom/Utils.h"
#include"voronoi/Util.h"
#include"geom/PolyUtils.h"
#include"geom/HungarianAlgorithm.h"
#include"voronoi/DoorLine.h"
#include"voronoi/SegmentInfo.h"

    std::vector<int> roomMatch(std::vector<Polygon*> rawPolys, std::vector<Polygon*> fitPolys);

    bool overlapByMaxAreaStrategy(std::vector<Polygon*> &polygons, Geometry* intersect, int i, int j, std::vector<Polygon*> rawPolys, std::vector<int> matchData);

    std::vector<Contour> DoubleOverlapSolver(SegmentInfo segmentInfo, std::vector<Contour> contours);

#endif